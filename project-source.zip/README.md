# СДВИГ / SHIFT

Browser prototype of a deterministic 1v1 tactical robot duel, intended for https://plairpro.github.io/shift/.

## Run

Node.js 22.12+ or 24.

```sh
npm ci
npm run dev
npm test
npm run build
```

In restricted containers use `npm run dev -- --host 127.0.0.1`.
The `dist/` directory is a standalone static build. Serve over HTTP(S), not file://.
All robot models ship locally. No CDN is required for game code or models.

## Modes

- Bot: alpha-beta search, three levels — Новичок (1 ply + noise), Боец (2 ply), Мастер (3 ply). No hidden bonuses.
- Local: two people on one screen.
- Online: invite link / code using PeerJS public signaling and WebRTC data channel. Host validates actions and move numbers. No backend account, matchmaking, authoritative anti-cheat, persistence, reconnection, or guaranteed TURN relay. Some networks cannot establish a connection. This mode is a prototype, not tournament infrastructure.

## Rules v0.1

5×5 board with a collapsing cross-shaped center (5 cells); identical four-robot teams in a T formation (Ram, Anchor, Magnet in a row, Jumper behind the Anchor on the back edge). Each turn is up to two actions by different robots; a player may end the turn after one action. All information is public.

- Setup, left to right from each player's side: Jumper, Ram, Anchor, Magnet (second row from the edge, mirrored).
- Rock–paper–scissors (until one wins) decides who moves first.
- Every robot moves 1 empty cell orthogonally.
- Every robot pushes an adjacent robot and the contiguous chain beyond it one cell. The Ram pushes two steps; the entire action must be legal. Friendly robots can be pushed. Robots crossing the boundary are removed.
- Magnet pulls the first robot on an unobstructed orthogonal ray at distance 2–5 two cells toward itself (one if the distance is 2); a hole on the way swallows it.
- Anchor can brace: until its owner's next turn starts it cannot be pulled and can be pushed only by an Anchor; a chain pushed into it moves only as far as it can. Bracing must be renewed every turn.
- Jumper can also step 1 cell diagonally, or jump exactly two cells orthogonally or diagonally to an empty cell.
- Center collapse: whenever all intact central cells are occupied (4, then 3, 2, 1), the one held longest is marked and becomes a hole at the end of the next turn. A robot on it falls. Holes cannot be entered by moving or jumping, but robots can be pushed or pulled into them.
- Outer ring: after turn 30 all 20 edge cells collapse at once (they turn pink one turn before).
- Center points: at the end of every turn the team with more robots in the center gets +1. After 60 turns, or on threefold repetition, the higher center score wins (equal = draw).
- Eliminate three of four opposing robots to win. Both teams down to one or zero = draw.
- No clocks in this first prototype. First-player advantage and strategic depth are not yet established through playtesting.

Click a robot: every legal target appears on the board at once, colour-coded (green move, blue jump, amber push, violet pull, yellow brace, red = knocks someone out). Click a target to preview, then confirm (button, Enter, or a second click on the same target).. The preview warns if your move exposes a robot. Hint (master-level suggestion) and Undo are available vs bot and on one screen. Keys: 1–4 select, Enter confirm, Esc cancel, Z undo. Camera button toggles oblique/overhead; online guests see the board from their own side.

## GitHub Pages

Create/access `plairpro/shift`, push this project to `main`, and in Settings → Pages select GitHub Actions. The included `.github/workflows/pages.yml` runs tests/build and deploys `dist/`.

## Assets

See ASSETS.md. Four animated Quaternius mechs, CC0.
