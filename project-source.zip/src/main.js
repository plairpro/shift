import '@fontsource/manrope/400.css';
import '@fontsource/manrope/600.css';
import '@fontsource/manrope/700.css';
import '@fontsource/manrope/800.css';
import './style.css';
import{initial,legal,apply,simulate,describe,knocked,displaced,threatsAgainst,ROLES,ACTIONS,LEVELS,at,bot,sameAction,central,CENTER,RING,RING_TURN,TURN_LIMIT,PER_TURN,SETUP}from'./engine.js';
import{Arena}from'./scene.js';
import{Relay}from'./relay.js';
import{icon}from'./icons.js';
import{T,EN,LANG,setLang,applyLanguage}from'./i18n.js';
applyLanguage();

const $=id=>document.getElementById(id);
const store={get(k,d){try{return localStorage.getItem('shift.'+k)??d;}catch{return d;}},set(k,v){try{localStorage.setItem('shift.'+k,v);}catch{}}};
const TEAM_NAME=[T('Голубые','Blue'),T('Розовые','Pink')];
let state=initial(),selected=null,pending=null,mode='bot',level=store.get('level','normal'),busy=false,thinking=false,ready=false,started=false,generation=0,muted=store.get('muted','0')==='1',audio,past=[];
let peer=null,connection=null,host=false,onlineTeam=0,connected=false,networkGeneration=0;
if(!LEVELS[level])level='normal';

// Значки в статичной разметке
document.querySelectorAll('[data-icon]').forEach(el=>el.insertAdjacentHTML('afterbegin',icon(el.dataset.icon)));
$('rolesGrid').innerHTML=Object.entries(ROLES).map(([k,r])=>`<div class="role-rule"><span class="role-ico">${icon(r.icon)}</span><div><b>${r.name}</b><p>${r.tip}</p></div></div>`).join('');

const arena=new Arena($('viewport'),pick);
arena.selectable=u=>myTurn()&&u.team===state.turn&&!state.acted.includes(u.id);

function toast(t){$('toast').textContent=t;$('toast').classList.add('visible');clearTimeout(toast.timer);toast.timer=setTimeout(()=>$('toast').classList.remove('visible'),3200);}
// Сухие деревянные «щелчки», как у фигур на доске: короткий шумовой удар + глухой низкий корпус, без тянущихся тонов.
let noiseBuf=null;
function knock(t,{vol=.5,freq=1800,q=1.2,body=190,bodyVol=.5,len=.06}={}){
 const a=audio;if(!noiseBuf){noiseBuf=a.createBuffer(1,a.sampleRate*.12|0,a.sampleRate);const d=noiseBuf.getChannelData(0);for(let i=0;i<d.length;i++)d[i]=(Math.random()*2-1)*Math.pow(1-i/d.length,3);}
 const n=a.createBufferSource(),bp=a.createBiquadFilter(),ng=a.createGain();n.buffer=noiseBuf;bp.type='bandpass';bp.frequency.value=freq;bp.Q.value=q;
 ng.gain.setValueAtTime(vol*.45,t);ng.gain.exponentialRampToValueAtTime(.0001,t+len*.7);n.connect(bp).connect(ng).connect(a.destination);n.start(t);n.stop(t+len);
 const o=a.createOscillator(),og=a.createGain();o.type='sine';o.frequency.setValueAtTime(body,t);o.frequency.exponentialRampToValueAtTime(body*.8,t+len);
 og.gain.setValueAtTime(.0001,t);og.gain.exponentialRampToValueAtTime(bodyVol*.45,t+.003);og.gain.exponentialRampToValueAtTime(.0001,t+len*1.4);o.connect(og).connect(a.destination);o.start(t);o.stop(t+len*1.5);}
// Мобильные браузеры (особенно iOS) запускают звук только из жеста пользователя:
// создаём и «разблокируем» аудио на первом касании, а на iOS просим играть даже при беззвучном режиме.
function audioCtx(){if(!audio){audio=new(window.AudioContext||window.webkitAudioContext)();try{if(navigator.audioSession)navigator.audioSession.type='playback';}catch{}}return audio;}
function unlockAudio(){try{const a=audioCtx();if(a.state!=='running')a.resume();const b=a.createBuffer(1,1,22050),src=a.createBufferSource();src.buffer=b;src.connect(a.destination);src.start(0);}catch{}}
for(const ev of ['pointerdown','touchend','keydown'])window.addEventListener(ev,unlockAudio,{capture:true,passive:true});
function sound(type='move'){if(muted)return;try{audioCtx();if(audio.state!=='running'){audio.resume().then(()=>{if(audio.state==='running')sound(type);}).catch(()=>{});return;}const t=audio.currentTime+.005;
 if(type==='select')knock(t,{vol:.12,freq:2600,q:2,body:320,bodyVol:.06,len:.03});
 else if(type==='push')knock(t,{vol:.45,freq:1100,q:1,body:140,bodyVol:.55,len:.08});
 else if(type==='ko'){knock(t,{vol:.5,freq:1000,q:1,body:130,bodyVol:.6,len:.08});knock(t+.11,{vol:.3,freq:700,q:.8,body:85,bodyVol:.55,len:.12});}
 else knock(t,{vol:.35,freq:1700,q:1.3,body:210,bodyVol:.35,len:.055});
 }catch{}}

const ended=()=>state.winner!==null||state.draw;
const myTurn=()=>started&&ready&&!busy&&!ended()&&(mode==='local'||mode==='bot'&&state.turn===0||mode==='online'&&connected&&state.turn===onlineTeam);
/** Чью сторону показывает интерфейс: в локальной игре — того, кто ходит. */
const viewTeam=()=>mode==='online'?onlineTeam:mode==='bot'?0:state.turn;
const choices=()=>myTurn()?legal(state):[];
/** Роботы команды в порядке расстановки (слева направо). */
const squadOf=t=>state.units.filter(u=>u.team===t).sort((a,b)=>SETUP.indexOf(a.role)-SETUP.indexOf(b.role));
const YOU=T('Вы','You'),BOT=T('Бот','Bot');
const teamName=t=>mode==='bot'?(t?BOT:YOU):mode==='online'?(t===onlineTeam?YOU:T('Соперник','Opponent')):TEAM_NAME[t];

/** Цели выбранного робота: ход и прыжок в одну клетку дают одно и то же — оставляем ход. */
function targetsFor(id){const list=choices().filter(a=>a.id===id);const out=[];for(const a of list){if(a.type==='jump'&&list.some(b=>b.type==='move'&&b.x===a.x&&b.y===a.y))continue;const lost=displaced(state,a);out.push({...a,kill:lost.some(u=>u.team!==state.turn),selfKill:lost.some(u=>u.team===state.turn)});}return out;}
// Подсветка угроз отключена: игрок сам читает позицию. Предупреждение остаётся только в предпросмотре хода.
function currentThreats(){return new Map();const t=threatsAgainst(state,state.turn);
 // Робот на клетке, которая провалится после этого хода, тоже в опасности
 const c=state.cracks?.[0];if(c){const u=at(state,...c.split(',').map(Number));if(u&&u.team===state.turn&&!t.has(u.id))t.set(u.id,[]);}
 if(state.ring==='warn')for(const u of state.units)if(u.alive&&u.team===state.turn&&RING.includes(u.x+','+u.y)&&!t.has(u.id))t.set(u.id,[]);return t;}
/** Что соперник сможет выбить сразу после этого действия. */
function exposureAfter(a){const n=simulate(state,a);if(!n)return[];const next={...n,turn:1-state.turn,winner:null,draw:false};return[...threatsAgainst(next,state.turn).keys()].map(id=>n.units.find(u=>u.id===id));}

function render(){
 const team=state.turn,mine=myTurn(),view=viewTeam(),threats=currentThreats();
 document.body.dataset.turn=team;const me=mode==='online'?onlineTeam:0;document.body.dataset.me=me;arena.setMe(me);
 $('modePill').textContent=mode==='bot'?`${T('Против бота','Vs bot')} · ${LEVELS[level].name}`:mode==='local'?T('Вдвоём на одном экране','Two players, one screen'):`${T('Онлайн','Online')} · ${connected?T('на связи','connected'):T('нет связи','offline')}`;
 const per=PER_TURN;$('round').textContent=ended()?T('Конец','Game over'):per>1?`${T('Ход','Turn')} ${state.turnNo} · ${Math.min(state.acted.length+1,per)}/${per}`:`${T('Ход','Turn')} ${state.turnNo}`;
 $('centerScore').textContent=`${T('очки центра','center points')} ${state.score[0]} : ${state.score[1]}`;
 for(const t of [0,1]){$('name'+t).textContent=teamName(t);$('pips'+t).innerHTML=squadOf(t).map(u=>`<span class="pip${u.alive?'':' out'}${threats.has(u.id)?' danger':''}" title="${ROLES[u.role].name}${u.alive?'':T(' — выбит',' — out')}">${icon(ROLES[u.role].icon)}</span>`).join('');document.querySelector('.side-'+t).classList.toggle('active',!ended()&&team===t);}
 // Заголовок и подсказка-шаг
 const title=state.winner!==null?`${teamName(state.winner)===YOU?T('Победа!','Victory!'):teamName(state.winner)===BOT?T('Бот победил','The bot wins'):`${T('Победа','Winner')}: ${teamName(state.winner)}`}`:state.draw?T('Ничья','Draw'):!started?T('Сдвиг','Shift'):mode==='online'&&!connected?T('Нет соединения','No connection'):busy?'…':mine?(mode==='local'?`${T('Ход','Turn')}: ${TEAM_NAME[team]}`:T('Ваш ход','Your turn')):mode==='bot'?T('Ход бота','Bot’s turn'):T('Ход соперника','Opponent’s turn');
 $('turnTitle').textContent=title;
 const tsel=selected&&targetsFor(selected);
 $('turnHint').textContent=ended()?T('Начните новую партию или посмотрите на поле','Start a new game or look over the board'):!started?T('Выберите режим, чтобы начать','Choose a mode to start'):!mine?(mode==='bot'?T('Бот выбирает действие…','The bot is choosing…'):T('Следите за позицией','Watch the position')):pending?T('Проверьте результат и подтвердите ход','Check the result and confirm'):selected?(tsel.length?T('Нажмите на метку на поле','Tap a marker on the board'):T('У этого робота нет ходов — выберите другого','This robot has no moves — pick another')):state.acted.length?T('Второе действие — другим роботом. Или завершите ход.','Second action — with another robot. Or end the turn.'):threats.size?`${T('Под угрозой','In danger')}: ${[...threats.keys()].map(id=>ROLES[state.units.find(u=>u.id===id).role].name).join(', ')} — ${T('защитите или атакуйте первым','defend or strike first')}`:T('Выберите робота на поле или в списке','Pick a robot on the board or in the list');
 $('turnHint').classList.toggle('alert',mine&&!selected&&!pending&&threats.size>0);
 $('thinking').classList.toggle('hidden',!thinking);
 // Отряд
 $('squadLabel').textContent=mode==='local'?`${T('Отряд','Squad')}: ${TEAM_NAME[view]}`:T('Ваш отряд','Your squad');
 const squad=squadOf(view);
 $('squad').replaceChildren(...squad.map((u,i)=>{const b=document.createElement('button');b.className='unit t'+u.team;b.classList.toggle('active',selected===u.id);const done=state.acted.includes(u.id)&&u.team===state.turn;b.disabled=!u.alive||!mine||done;b.classList.toggle('done',done);
  const tags=[!u.alive&&`<span class="tag out">${T('выбит','out')}</span>`,u.alive&&threats.has(u.id)&&`<span class="tag danger">${T('под угрозой','in danger')}</span>`,done&&`<span class="tag out">${T('сделал ход','moved')}</span>`,u.braced&&`<span class="tag lock">${T('закреплён','braced')}</span>`].filter(Boolean).join('');
  b.innerHTML=`<span class="unit-ico">${icon(ROLES[u.role].icon)}</span><span class="unit-txt"><b>${ROLES[u.role].name}</b><small>${ROLES[u.role].short}</small></span><span class="unit-tags">${tags}<kbd>${i+1}</kbd></span>`;b.onclick=()=>select(u);return b;}));
 // Детали выбранного
 const u=state.units.find(u=>u.id===selected);$('detail').classList.toggle('hidden',!u);
 if(u){const types=['move','jump','push','pull','brace'].filter(t=>tsel.some(a=>a.type===t));const kills=tsel.filter(a=>a.kill).length;
  $('detail').innerHTML=`<p>${ROLES[u.role].tip}</p><div class="chips">${types.map(t=>`<span class="chip ${t}">${ACTIONS[t]} · ${tsel.filter(a=>a.type===t).length}</span>`).join('')}${kills?`<span class="chip kill">${T('Выбивает','Knockouts')} · ${kills}</span>`:''}${types.length?'':`<span class="chip none">${T('нет доступных действий','no available actions')}</span>`}</div>`;}
 // Кнопка закрепления — прямо под выбранным якорем на поле
 {const br=u&&mine&&!busy&&tsel.find(a=>a.type==='brace'),fb=$('braceFloat');fb.classList.toggle('hidden',!br);
  if(br){const on=pending?.type==='brace';fb.classList.toggle('on',on);fb.innerHTML=`${icon('lock')}<span>${on?T('Подтвердить','Confirm'):T('Закрепиться','Brace')}</span>`;fb.onclick=e=>{e.stopPropagation();on?confirm():stage(br);};arena.pin(fb,u.id);}else arena.pin(null);}
 // Платформа
 // Центр: состояние обрушения
 const cHoles=CENTER.filter(c=>state.holes.includes(c)).length;
 const cr=state.cracks,cells=[...document.querySelectorAll('#centerMini i')];
 CENTER.forEach(c=>{const [x,y]=c.split(',').map(Number);const u=at(state,x,y);const el=cells[(y-1)*3+(x-1)];el.className=state.holes.includes(c)?'hole':cr?.[0]===c?'next':u?'t'+u.team:'';});
 const nextCell=cr?.[0],victim=nextCell&&at(state,...nextCell.split(',').map(Number));
 $('centerTag').textContent=cHoles===CENTER.length?T('обрушен','collapsed'):cr?T('рушится','collapsing'):`${CENTER.filter(c=>!state.holes.includes(c)&&at(state,...c.split(',').map(Number))).length}/${CENTER.filter(c=>!state.holes.includes(c)).length}`;
 $('centerTag').className='tag'+(cr&&cHoles<CENTER.length?' danger':'');
 const intact=CENTER.filter(c=>!state.holes.includes(c)).length;
 $('centerHint').textContent=cHoles===CENTER.length?T('Центр провалился целиком. Сталкивайте туда соперников.','The whole center has fallen. Push opponents into it.'):cr?(victim?(EN?`At the end of the next turn the pink cell falls with a robot on it: ${ROLES[victim.role].name}${victim.team===viewTeam()?' (yours!) — move it away':''}.`:`В конце следующего хода провалится розовая клетка с роботом: ${ROLES[victim.role].name}${victim.team===viewTeam()?' (ваш!) — уводите его':''}.`):T('В конце следующего хода провалится розовая клетка.','The pink cell falls at the end of the next turn.')):EN?`When all ${intact===1?'remaining cell is':intact===CENTER.length?intact+' cells are':'remaining '+intact+' cells are'} occupied, the first one taken falls.`:`Займут все ${intact===CENTER.length?intact+' клеток':intact===1?'оставшуюся клетку':'оставшиеся '+intact+(intact<5?' клетки':' клеток')} — первая занятая провалится.`;
 $('ringHint').textContent=state.ring==='gone'?T('Края поля обрушились.','The board edges have collapsed.'):state.ring==='warn'?'':(RING_TURN-state.turnNo+1<=5?(EN?`The edges are fading: they collapse in ${RING_TURN-state.turnNo+1} ${RING_TURN-state.turnNo+1===1?'turn':'turns'} — move your robots inward.`:`Края поля бледнеют: обрушатся через ${RING_TURN-state.turnNo+1} ${(n=>n===1?'ход':n<5?'хода':'ходов')(RING_TURN-state.turnNo+1)} — уводите роботов внутрь.`):(EN?`The board edges collapse after turn ${RING_TURN} — ${RING_TURN-state.turnNo+1} left.`:`Края поля обрушатся после ${RING_TURN}-го хода — осталось ${RING_TURN-state.turnNo+1}.`));
 if(state.ring==='warn')$('centerHint').textContent=T('Края поля рушатся! В конце этого хода всё внешнее кольцо обрушится — уводите роботов внутрь.','The edges are crumbling! At the end of this turn the whole outer ring collapses — move your robots inward.');
 $('centerTag').textContent=state.ring==='warn'?T('края рушатся','edges collapsing'):$('centerTag').textContent;if(state.ring==='warn')$('centerTag').className='tag danger';
 // Предпросмотр
 $('preview').classList.toggle('hidden',!pending);$('confirm').disabled=!mine;
 if(pending){const lost=knocked(state,pending);$('previewText').textContent=describe(state,pending);const exposed=exposureAfter(pending).filter(v=>v.alive);
  const n2=simulate(state,pending),fell=lost.filter(v=>v.team===state.turn),pushed=fell.filter(v=>{const b=state.units.find(t=>t.id===v.id);const c=n2.units.find(t=>t.id===v.id);return b.x!==c.x||b.y!==c.y;}),sunk=fell.filter(v=>!pushed.includes(v));
  const warn=[pushed.length&&T('Вы выталкиваете своего робота!','You are pushing out your own robot!'),sunk.length&&`${sunk.map(v=>ROLES[v.role].name).join(', ')} ${T('провалится в центре — этим ходом вы его не спасаете','will fall in the center — this move doesn’t save it')}`,exposed.length&&`${T('После хода соперник сможет выбить','After this move the opponent can knock out')}: ${exposed.map(v=>ROLES[v.role].name).join(', ')}`].filter(Boolean);
  $('previewWarn').innerHTML=warn.length?icon('warn')+warn.join('. '):'';$('previewWarn').classList.toggle('hidden',!warn.length);
  $('preview').classList.toggle('good',lost.some(v=>v.team!==state.turn));}
 // Инструменты
 $('hintBtn').disabled=!mine||mode==='online';
 $('endTurn').classList.toggle('hidden',!mine||!state.acted.length||!!pending);
 $('undoBtn').disabled=busy||thinking||mode==='online'||!past.length||!started;
 // Журнал
 const hist=state.history.slice(-6).reverse();
 $('history').innerHTML=hist.length?hist.map(h=>`<li><span class="team-dot t${h.team}"></span>${h.text}</li>`).join(''):`<li class="empty">${T('Здесь появятся ходы партии.','Moves will appear here.')}</li>`;
 // Баннер на поле
 const ringLeft=RING_TURN-state.turnNo+1,plural=n=>EN?(n===1?'turn':'turns'):n===1?'ход':n<5?'хода':'ходов';
 const banner=!ended()&&state.ring==='warn'&&!thinking?T('Края рушатся в конце этого хода!','The edges collapse at the end of this turn!'):!ended()&&!state.ring&&ringLeft>=2&&ringLeft<=5&&!thinking?`${T('Края обрушатся через','Edges collapse in')} ${ringLeft} ${plural(ringLeft)}`:ended()?(state.draw?T('Ничья','Draw'):`${teamName(state.winner)===YOU?T('Вы победили','You win'):teamName(state.winner)+T(' — победа',' win')}`):thinking?T('Бот думает…','The bot is thinking…'):(mode==='online'&&started&&!mine&&!busy&&connected)?T('Ход соперника','Opponent’s turn'):'';
 $('banner').textContent=banner;$('banner').classList.toggle('visible',!!banner);
 arena.highlight(selected,pending?[]:(tsel||[]));
 arena.setThreats(pending?[]:[...threats.keys()]);
}

function select(u){if(!myTurn()||u.team!==state.turn||!u.alive||state.acted.includes(u.id))return;if(selected===u.id&&!pending){selected=null;render();return;}selected=u.id;pending=null;arena.clearPreview();render();sound('select');}
function deselect(){selected=null;pending=null;arena.clearPreview();render();}
function pick(x,y){if(!myTurn())return;
 const t=selected&&targetsFor(selected).find(a=>a.x===x&&a.y===y);
 if(t){if(pending&&sameAction(pending,t))confirm();else stage(t);return;}
 const u=at(state,x,y);
 if(u&&u.team===state.turn){if(state.acted.includes(u.id)){toast(T('Этот робот уже действовал в этом ходу.','This robot has already acted this turn.'));return;}select(u);return;}
 if(pending||selected){deselect();return;}
 if(u)toast(T('Это робот соперника. Выберите своего, затем его толчок.','That’s an enemy robot. Pick yours, then its push.'));}
function stage(a){if(!a||!myTurn())return;if(a.id)selected=a.id;pending=a;arena.preview(state,simulate(state,a));render();sound('select');}
function confirm(){if(!myTurn()||!pending)return;const a=pending;if(mode==='online'&&!host){connection.send({type:'request',ply:state.ply,action:a});pending=null;busy=true;arena.clearPreview();render();}else commit(a);}
function endTurn(){if(!myTurn()||!state.acted.length)return;pending={type:'end'};confirm();}
function cancel(){if(pending){pending=null;arena.clearPreview();render();}else if(selected)deselect();}

// PLAIR (лента plair.pro): итоговые очки партии — один раз за партию, только когда есть «свой» игрок (бот или онлайн).
// Больше — лучше: победа 1000 + 10 за каждый ход, оставшийся до лимита; 150 за каждого выбитого врага; 100 за каждого своего уцелевшего;
// 5 за очко центра; ничья +300. Против бота множитель силы: Новичок ×1, Боец ×1.5, Мастер ×2.
let scored=false;
function finalScore(){if(mode!=='bot'&&mode!=='online')return null;const me=mode==='bot'?0:onlineTeam;
 const enemiesOut=state.units.filter(u=>u.team!==me&&!u.alive).length,mine=state.units.filter(u=>u.team===me&&u.alive).length;
 let p=150*enemiesOut+100*mine+5*state.score[me];
 if(state.winner===me)p+=1000+10*Math.max(0,TURN_LIMIT-(state.turnNo-1));else if(state.draw)p+=300;
 if(mode==='bot')p*={easy:1,normal:1.5,hard:2}[level]||1;
 return Math.round(p);}
function submitScore(){const p=finalScore();if(p===null)return null;if(!scored){scored=true;try{if(window.PLAIR)PLAIR.score(p);}catch(e){console.warn(e);}}return p;}
// Вызов от друга: «побей мой рекорд».
try{if(window.PLAIR)PLAIR.onChallenge(c=>{if(!c||c.score==null)return;const el=$('challenge');el.textContent=EN?`Beat ${c.score}${c.name?` — ${c.name}’s record`:''}`:`Побей ${c.score}${c.name?` — рекорд ${c.name}`:''}`;el.classList.remove('hidden');});}catch(e){console.warn(e);}
async function commit(a,remote=false){if(busy||!ready)return;const n=apply(state,a);if(!n)return;const before=state,oldGeneration=generation;if(mode!=='online')past.push(before);state=n;busy=true;selected=null;pending=null;render();const ko=knocked(before,a).length;sound(ko?'ko':a.type==='push'||a.type==='pull'?'push':a.type);
 if(mode==='online'&&host&&!remote)connection?.send({type:'action',ply:before.ply,action:a});
 await arena.animate(before,n,a);if(oldGeneration!==generation)return;busy=false;render();
 if(ended()){const w=state.winner;$('endTitle').textContent=state.draw?T('Ничья.','Draw.'):mode==='bot'?(w===0?T('Победа!','Victory!'):T('Бот победил.','The bot wins.')):mode==='online'?(w===onlineTeam?T('Победа!','Victory!'):T('Поражение.','Defeat.')):`${TEAM_NAME[w]} ${T('побеждают.','win.')}`;
  const sc=`${state.score[0]} : ${state.score[1]}`;
  $('endText').textContent=state.byScore?(state.draw?(EN?`Center points are tied (${sc}) — draw.`:`Очки центра равны (${sc}) — ничья.`):(EN?`Decided by center points: ${sc}. ${state.turnNo>TURN_LIMIT?`${TURN_LIMIT} turns have passed.`:'The position repeated three times.'}`:`Решили очки центра: ${sc}. ${state.turnNo>TURN_LIMIT?`Прошло ${TURN_LIMIT} ходов.`:'Позиция повторилась трижды.'}`)):state.draw?T('Осталось по одному роботу.','Each side has one robot left.'):(EN?`Three robots knocked out. The game took ${state.turnNo-1} turns.`:`Три робота выбиты. Партия заняла ${state.turnNo-1} ходов.`)+(mode==='bot'&&w===1?T(' Попробуйте вернуть ход и найти другой путь.',' Try undoing a move and finding another way.'):'');
  $('rematch').textContent=mode==='online'?T('Новая комната','New room'):T('Ещё партия','Play again');
  const pts=submitScore();if(pts!==null)$('endText').textContent+=` ${T('Очки','Score')}: ${pts}.`;
  setTimeout(()=>$('endDialog').showModal(),500);}
 else scheduleBot();}
function scheduleBot(){if(mode!=='bot'||state.turn!==1||busy||!started||ended())return;const epoch=generation;thinking=true;render();
 setTimeout(()=>{if(epoch!==generation||mode!=='bot'||state.turn!==1||busy){return;}const a=bot(state,level);thinking=false;if(a)commit(a);else render();},550);}
function undo(){if(mode==='online'||busy||!past.length)return;generation++;thinking=false;let s=past.pop();while(mode==='bot'&&s.turn===1&&past.length)s=past.pop();state=s;selected=null;pending=null;arena.clearPreview();arena.setState(state);$('endDialog').close();render();sound('select');scheduleBot();}
function hint(){if(!myTurn()||mode==='online')return;const a=bot(state,'hard');if(!a)return;stage(a);toast(T('Совет мастера — можно подтвердить или выбрать своё.','Master’s tip — confirm it or choose your own.'));}

// ── Камень, ножницы, бумага: кто ходит первым ──
const RPS={rock:['✊',T('Камень','Rock')],scissors:['✌️',T('Ножницы','Scissors')],paper:['✋',T('Бумага','Paper')]};
const beats=(a,b)=>a==='rock'&&b==='scissors'||a==='scissors'&&b==='paper'||a==='paper'&&b==='rock';
let rps=null;
$('rpsDialog').addEventListener('cancel',e=>e.preventDefault());
function rpsOpen(){rps={picks:[null,null],step:0,epoch:generation};$('rpsReveal').classList.add('hidden');$('rpsGo').classList.add('hidden');$('rpsPicks').classList.remove('hidden');rpsPrompt();if(!$('rpsDialog').open)$('rpsDialog').showModal();}
function rpsPrompt(){const t=$('rpsText');document.querySelectorAll('#rpsPicks button').forEach(b=>b.disabled=false);
 if(mode==='bot')t.textContent=T('Победитель ходит первым. Ничья — переигрываем.','The winner moves first. A tie — play again.');
 else if(mode==='local')t.textContent=rps.step===0?T('Голубые выбирают тайно — розовые, не смотрите!','Blue picks in secret — Pink, don’t look!'):T('Розовые выбирают тайно — голубые, не смотрите!','Pink picks in secret — Blue, don’t look!');
 else t.textContent=rps.mine?T('Ждём выбор соперника…','Waiting for the opponent…'):T('Выберите — соперник выбирает одновременно.','Pick — your opponent picks at the same time.');
 $('rpsTitle').textContent=mode==='local'?(rps.step===0?T('Ход голубых','Blue’s pick'):T('Ход розовых','Pink’s pick')):T('Камень, ножницы, бумага','Rock, paper, scissors');}
function rpsPick(pick){if(!rps)return;
 if(mode==='bot'){const opts=Object.keys(RPS);rps.picks=[pick,opts[crypto.getRandomValues(new Uint8Array(1))[0]%3]];rpsReveal();}
 else if(mode==='local'){rps.picks[rps.step]=pick;if(rps.step===0){rps.step=1;rpsPrompt();}else rpsReveal();}
 else{rps.mine=pick;document.querySelectorAll('#rpsPicks button').forEach(b=>b.disabled=true);rpsPrompt();
  if(host){rps.picks[0]=pick;rpsHostCheck();}else connection?.send({type:'rps',pick});}}
function rpsHostCheck(){if(!host||!rps||!rps.picks[0]||!rps.picks[1])return;const p=rps.picks;const first=p[0]===p[1]?null:beats(p[0],p[1])?0:1;connection?.send({type:'rps-result',picks:p,first});rpsReveal(first);}
function rpsReveal(first){const p=rps.picks;if(first===undefined)first=p[0]===p[1]?null:beats(p[0],p[1])?0:1;
 const name=t=>teamName(t);$('rpsPicks').classList.add('hidden');
 $('rpsReveal').innerHTML=[0,1].map(t=>`<div class="side t${t}${first===t?' win':''}"><i>${RPS[p[t]][0]}</i><span>${RPS[p[t]][1]}</span><b>${name(t)}</b></div>`).join('<span class="vs">vs</span>');
 $('rpsReveal').innerHTML=$('rpsReveal').innerHTML.replace('<span class="vs">vs</span>',`<span class="vs">${T('против','vs')}</span>`);
 $('rpsReveal').classList.remove('hidden');
 if(first===null){$('rpsTitle').textContent=T('Ничья — ещё раз','Tie — again');$('rpsText').textContent=T('Одинаковый выбор. Переигрываем.','Same pick. Play again.');const ep=rps.epoch;setTimeout(()=>{if(rps&&rps.epoch===ep&&generation===ep){rps={picks:[null,null],step:0,epoch:ep};$('rpsReveal').classList.add('hidden');$('rpsPicks').classList.remove('hidden');rpsPrompt();}},1600);return;}
 const who=name(first);$('rpsTitle').textContent=who===YOU?T('Вы ходите первым','You go first'):who===BOT?T('Бот ходит первым','The bot goes first'):EN?`${who} goes first`:`Первыми ходят: ${who}`;$('rpsText').textContent=`${RPS[p[first]][1]} ${T('бьёт','beats')} ${RPS[p[1-first]][1].toLowerCase()}.`;
 rps.first=first;$('rpsGo').classList.remove('hidden');$('rpsGo').focus();}
$('rpsPicks').addEventListener('click',e=>{const b=e.target.closest('button[data-pick]');if(b)rpsPick(b.dataset.pick);});
$('rpsGo').onclick=()=>{if(!rps||rps.first==null)return;const f=rps.first;rps=null;$('rpsDialog').close();begin(f);};
function begin(first){state=initial(first);past=[];selected=null;pending=null;started=true;arena.clearPreview();arena.setState(state);render();sound();scheduleBot();}

function start(m,keepNetwork=false){scored=false;if(busy){toast(T('Дождитесь завершения хода.','Wait for the move to finish.'));return;}if(!keepNetwork)cleanNetwork();generation++;thinking=false;mode=m;state=initial();past=[];selected=null;pending=null;started=false;arena.clearPreview();arena.setView({team:mode==='online'?onlineTeam:0});arena.setState(state);['startDialog','endDialog','onlineDialog'].forEach(id=>$(id).close());render();rpsOpen();}

// ── Обработчики ─────────────────────────────────
$('confirm').onclick=confirm;$('cancel').onclick=cancel;

$('hintBtn').onclick=hint;$('endTurn').onclick=endTurn;$('undoBtn').onclick=undo;
const levelButtons=[...document.querySelectorAll('#levelSeg button')];const paintLevel=()=>levelButtons.forEach(b=>b.classList.toggle('active',b.dataset.level===level));paintLevel();
levelButtons.forEach(b=>b.onclick=()=>{level=b.dataset.level;store.set('level',level);paintLevel();});
$('startBot').onclick=()=>start('bot');$('startLocal').onclick=()=>start('local');$('startOnline').onclick=()=>{$('startDialog').close();$('onlineDialog').showModal();};
$('lang').textContent=EN?'RU':'EN';$('lang').title=EN?'Русский':'English';$('lang').onclick=()=>{if(busy)return;setLang(EN?'ru':'en');};
$('menu').onclick=()=>{if(!busy)$('startDialog').showModal();else toast(T('Дождитесь завершения хода.','Wait for the move to finish.'));};
$('closeStart').onclick=()=>{$('startDialog').close();if(!started&&ready)start('bot');};
$('help').onclick=()=>$('helpDialog').showModal();
const paintSound=()=>{$('sound').innerHTML=icon(muted?'mute':'sound');$('sound').setAttribute('aria-label',muted?T('Включить звук','Sound on'):T('Выключить звук','Sound off'));};paintSound();
$('sound').onclick=()=>{muted=!muted;store.set('muted',muted?'1':'0');paintSound();if(!muted)sound();};
$('camera').onclick=()=>{const top=arena.toggleCamera();$('camera').querySelector('span').textContent=top?T('Наклон','Tilted'):T('Сверху','Top');};
$('rematch').onclick=()=>{if(mode==='online'){$('endDialog').close();cleanNetwork();$('onlineDialog').showModal();$('inviteBox').classList.add('hidden');$('onlineStatus').textContent=T('Создайте новую комнату для реванша.','Create a new room for a rematch.');}else start(mode);};
document.querySelectorAll('[data-close]').forEach(b=>b.onclick=()=>$(b.dataset.close).close());
document.addEventListener('keydown',e=>{if(document.querySelector('dialog[open]')||e.target.tagName==='INPUT')return;
 if(e.key==='Escape')cancel();
 else if(e.key==='Enter'&&pending){e.preventDefault();confirm();}
 else if((e.key==='e'||e.key==='у'||e.key==='E')&&!pending)endTurn();
 else if(/^[1-4]$/.test(e.key)){const u=squadOf(viewTeam())[+e.key-1];if(u)select(u);}
 else if((e.key==='z'||e.key==='я'||e.key==='Z')&&!e.metaKey)undo();
 else if((e.ctrlKey||e.metaKey)&&e.code==='KeyZ'){e.preventDefault();undo();}});

// ── Онлайн ──────────────────────────────────────
let relay=null;
function cleanNetwork(){networkGeneration++;connected=false;connection?.close();peer?.destroy();relay?.close();connection=null;peer=null;relay=null;}
function onlineStatus(t){$('onlineStatus').textContent=t;}
const PROTO=17;
async function openPeer(id){const {Peer}=await import('peerjs');return new Promise((resolve,reject)=>{const p=id?new Peer(id):new Peer();peer=p;const timer=setTimeout(()=>{reject(new Error('timeout'));},12000);p.once('open',()=>{clearTimeout(timer);resolve(p);});p.on('error',e=>{clearTimeout(timer);reject(e);});});}
/** Первый открывшийся канал (прямой или через ретранслятор) становится соединением, остальные закрываются. */
function offer(c,isHost,epoch){c.on('open',()=>{if(epoch!==networkGeneration||connection){if(connection!==c)c.close();return;}
  connection=c;if(c!==relay)relay?.close();if(c===relay)peer?.destroy();attach(c,isHost,epoch);});}
function attach(c,isHost,epoch){host=isHost;onlineTeam=isHost?0:1;
 connected=true;onlineStatus(T('Соединение установлено.','Connected.'));if(isHost){start('online',true);c.send({type:'hello',version:PROTO});}
 c.on('data',async msg=>{if(epoch!==networkGeneration||!msg||typeof msg!=='object')return;
  if(msg.type==='hello'&&!isHost){if(msg.version!==PROTO){onlineStatus(T('Версии игры различаются. Обновите страницы.','Game versions differ. Reload both pages.'));c.close();return;}start('online',true);}
  if(msg.type==='request'&&isHost&&mode==='online'){if(msg.ply!==state.ply||state.turn!==1||busy||!legal(state).some(a=>sameAction(a,msg.action))){c.send({type:'reject'});return;}await commit(msg.action);}
  if(msg.type==='action'&&!isHost&&mode==='online'){if(msg.ply!==state.ply||!legal(state).some(a=>sameAction(a,msg.action))){toast(T('Партии рассинхронизировались. Создайте новую комнату.','The games went out of sync. Create a new room.'));connected=false;busy=false;render();return;}busy=false;await commit(msg.action,true);}
  if(msg.type==='rps'&&isHost&&rps&&['rock','paper','scissors'].includes(msg.pick)){rps.picks[1]=msg.pick;rpsHostCheck();}
  if(msg.type==='rps-result'&&!isHost&&rps){rps.picks=msg.picks;rpsReveal(msg.first);}
  if(msg.type==='reject'){busy=false;render();toast(T('Ход отклонён. Выберите действие ещё раз.','Move rejected. Choose an action again.'));}});
 c.on('close',()=>{if(epoch!==networkGeneration||connection!==c)return;connected=false;busy=!!arena.anim;render();onlineStatus(T('Соединение прервано. Создайте новую комнату.','Connection lost. Create a new room.'));if(mode==='online')toast(T('Соперник отключился. Создайте новую комнату.','Your opponent disconnected. Create a new room.'));});}
$('host').onclick=async()=>{if(!ready||busy)return;cleanNetwork();$('inviteBox').classList.add('hidden');onlineStatus(T('Создаём комнату…','Creating a room…'));$('host').disabled=true;const epoch=networkGeneration;
 const code=Array.from(crypto.getRandomValues(new Uint8Array(5)),b=>b.toString(16).padStart(2,'0')).join('');
 // Канал 1: ретранслятор по HTTPS — работает почти в любой сети
 relay=new Relay(code,true);offer(relay,true,epoch);
 const url=new URL(location.href);url.hash=`room=${code}`;$('invite').value=url.href;$('inviteBox').classList.remove('hidden');onlineStatus(EN?`Code ${code}. Waiting for the second player…`:`Код ${code}. Ожидаем второго игрока…`);$('host').disabled=false;
 // Канал 2: прямое соединение PeerJS — если сеть позволяет
 try{const p=await openPeer(`shift-v${PROTO}-${code}`);if(epoch!==networkGeneration){p.destroy();return;}p.on('connection',c=>{offer(c,true,epoch);});}catch{}};
$('join').onclick=async()=>{if(!ready||busy)return;const code=$('roomCode').value.trim().replace(/^.*room=/,'').toLowerCase();if(!/^[a-z0-9-]{4,32}$/.test(code)){onlineStatus(T('Введите код из приглашения.','Enter the code from the invite.'));return;}cleanNetwork();onlineStatus(T('Подключаемся к сопернику…','Connecting to your opponent…'));$('join').disabled=true;const epoch=networkGeneration;
 relay=new Relay(code,false);offer(relay,false,epoch);
 $('join').disabled=false;
 // Если ретранслятор не ответил за 8 секунд — пробуем прямое соединение
 const tryPeer=async()=>{if(epoch!==networkGeneration||connected)return;const r=relay;relay=null;r?.close();onlineStatus(T('Пробуем прямое соединение…','Trying a direct connection…'));
  try{const p=await openPeer();if(epoch!==networkGeneration||connected){p.destroy();return;}const c=p.connect(`shift-v${PROTO}-${code}`,{reliable:true});offer(c,false,epoch);}catch{}
  setTimeout(()=>{if(epoch===networkGeneration&&!connected)onlineStatus(T('Не удалось подключиться. Проверьте код; вкладка создателя комнаты должна оставаться открытой.','Couldn’t connect. Check the code; the room creator’s tab must stay open.'));},12000);};
 relay.on('error',tryPeer);setTimeout(tryPeer,8000);};
$('copyInvite').onclick=async()=>{try{await navigator.clipboard.writeText($('invite').value);toast(T('Ссылка скопирована.','Link copied.'));}catch{$('invite').select();toast(T('Скопируйте выделенную ссылку.','Copy the selected link.'));}};

render();
arena.load(state,n=>{$('loadText').textContent=`${T('Подготовка роботов','Preparing robots')} · ${n}/4`;}).then(()=>{ready=true;$('loading').classList.add('hidden');render();const room=new URLSearchParams(location.hash.slice(1)).get('room');if(room){$('roomCode').value=room;$('onlineDialog').showModal();}else $('startDialog').showModal();}).catch(e=>{console.error(e);$('loadText').textContent=T('Не удалось загрузить роботов. Обновите страницу.','Couldn’t load the robots. Reload the page.');});
// Для смоук-тестов в браузере: чтение состояния и «касание» клетки.
window.shiftDebug={getState:()=>structuredClone(state),get ready(){return ready},get busy(){return busy},get connected(){return connected},get mode(){return mode},get selected(){return selected},get pending(){return pending},tap:(x,y)=>pick(x,y),arena,load:s=>{state=s;started=true;selected=null;pending=null;arena.setState(state);render();}};
