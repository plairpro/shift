// СДВИГ — игровая логика. Чистые функции, без DOM.
export const ROLES={
 ram:{name:'Таран',icon:'ram',model:'George',short:'Толкает на 2 клетки',tip:'Толкает соседнего робота и всю цепочку за ним сразу на две клетки. Самый опасный у края.'},
 magnet:{name:'Магнит',icon:'magnet',model:'Leela',short:'Тянет на 2 клетки',tip:'Притягивает первого робота на линии с расстояния 2–5 клеток на две клетки к себе (на одну, если между ними одна клетка). Тянет через провалы — если провал на пути, робот в него падает. Через фигуры и закреплённых не тянет.'},
 anchor:{name:'Якорь',icon:'anchor',model:'Mike',short:'Щит на ход соперника',tip:'Закрепляется до начала вашего следующего хода: в ход соперника его нельзя притянуть, а толкнуть может только другой Якорь. Цепочку, которую толкают в него, он останавливает. Потом фиксация снимается — чтобы стоять дальше, закрепитесь снова. От провала не спасает.'},
 jumper:{name:'Прыгун',icon:'jumper',model:'Stan',short:'Ходит и по диагонали',tip:'Ходит на одну клетку в любую сторону, включая диагонали. Прыгает ровно на две клетки только по прямой — через любые фигуры.'}
};
export const ACTIONS={move:'Ход',push:'Толчок',pull:'Притянуть',brace:'Закрепиться',jump:'Прыжок',repel:'Оттолкнуть',end:'Завершить ход'};
/** Действий за ход: игроки ходят по очереди, по одному действию. */
export const PER_TURN=1;
/** После этого хода обрушивается внешний край поля. */
export const RING_TURN=30;
/** После этого хода партия заканчивается по очкам центра. */
export const TURN_LIMIT=60;
/** Варианты правил (для проверок баланса). */
export const OPT={repel:false,comeback:false};
export const DIRS=[[1,0],[-1,0],[0,1],[0,-1]];
/** Размер поля и центр. configure() — для проверок баланса. */
export let N=5;
export const inside=(x,y)=>x>=0&&x<N&&y>=0&&y<N;
export const central=(u)=>CENTER.includes(u.x+','+u.y);
export const at=(s,x,y)=>s.units.find(u=>u.alive&&u.x===x&&u.y===y);
/** Центр — крест из 5 клеток: лучи по часовой стрелке (как видит голубой игрок), потом середина. */
export let CENTER=['2,1','3,2','2,3','1,2','2,2'];
/** Внешнее кольцо поля. */
export let RING=[];
const ringOf=n=>{const r=[];for(let x=0;x<n;x++)for(let y=0;y<n;y++)if(x===0||y===0||x===n-1||y===n-1)r.push(x+','+y);return r;};
export const isHole=(s,x,y)=>s.holes.includes(x+','+y);
export const nextCrack=s=>s.cracks?.[0]??null;
const cell=c=>c.split(',').map(Number);
const copyUnits=s=>({...s,units:s.units.map(u=>({...u})),acted:s.acted.slice(),score:s.score.slice(),lost:s.lost.slice()});
export const clone=s=>({...copyUnits(s),history:s.history.slice(),seen:{...s.seen}});
export function key(s){return JSON.stringify([s.turn,s.holes,s.cracks,s.ring,s.units.map(u=>[u.id,u.x,u.y,u.alive,u.braced])]);}
/** Порядок роботов в отряде (клавиши 1–4). */
export let SETUP=['ram','anchor','magnet','jumper'];
export const setSetup=a=>{SETUP=a;};
/** Расстановка «Т» для голубых (снизу): Таран, Якорь, Магнит в ряд, Прыгун за Якорем на крайней линии. Розовые — зеркально. */
export let FORMATION={};
export function configure({n=N,center=CENTER}={}){N=n;CENTER=center;RING=ringOf(n);const m=(n-1)/2;FORMATION={ram:[m-1,n-2],anchor:[m,n-2],magnet:[m+1,n-2],jumper:[m,n-1]};}
configure();
/** first — команда, которая ходит первой (по итогам «камень, ножницы, бумага»). */
export function initial(first=0){let units=[];[0,1].forEach(team=>Object.keys(ROLES).forEach(role=>{const [fx,fy]=FORMATION[role];units.push({id:`${team}-${role}`,role,team,x:team?N-1-fx:fx,y:team?N-1-fy:fy,alive:true,braced:false,since:0});}));
 let s={units,turn:first,first,ply:0,turnNo:1,left:PER_TURN,acted:[],score:[0,0],lost:[0,0],bonus:false,winner:null,draw:false,byScore:false,holes:[],cracks:null,ring:null,history:[],seen:{}};s.seen[key(s)]=1;return s;}
/** Сколько своих роботов команда держит на целых клетках центра. */
export const centerCount=(s,team)=>CENTER.filter(c=>!s.holes.includes(c)&&at(s,...cell(c))?.team===team).length;
/** Сдвиг цепочки. heavy — толкает Якорь: только он сдвигает закреплённых. Если цепочка упирается в закреплённого — она сдвигается до упора. */
function shifted(s,target,dx,dy,steps,heavy=false){if(target.braced&&!heavy)return null;const n=copyUnits(s);const id=target.id;for(let i=0;i<steps;i++){let t=n.units.find(u=>u.id===id);if(!t.alive)break;let chain=[],cur=t,blocked=false;while(cur){if(cur.braced&&!heavy){blocked=true;break;}chain.push(cur);cur=at(n,cur.x+dx,cur.y+dy);}
  // Цепочка упёрлась в закреплённого — сдвигаем, сколько можно (то есть дальше не двигаемся)
  if(blocked)break;for(const v of chain.reverse()){v.x+=dx;v.y+=dy;if(!inside(v.x,v.y)||isHole(n,v.x,v.y))v.alive=false;}}return n;}
const free=(s,x,y)=>inside(x,y)&&!at(s,x,y)&&!isHole(s,x,y);
export function legal(s){if(s.winner!==null||s.draw)return [];let list=[];for(const u of s.units){if(!u.alive||u.team!==s.turn||s.acted.includes(u.id))continue;
 for(const [dx,dy] of DIRS){if(free(s,u.x+dx,u.y+dy))list.push({type:'move',id:u.id,x:u.x+dx,y:u.y+dy});
  const t=at(s,u.x+dx,u.y+dy);if(t&&shifted(s,t,dx,dy,u.role==='ram'?2:1,u.role==='anchor'))list.push({type:'push',id:u.id,x:t.x,y:t.y});
  if(u.role==='magnet'){for(let d=1;d<=5;d++){const t=at(s,u.x+dx*d,u.y+dy*d);if(t){if(d>=2&&!t.braced)list.push({type:'pull',id:u.id,x:t.x,y:t.y});
    // Отталкивание: первый робот на линии с расстояния 2–3 отлетает на клетку вместе с цепочкой
    if(OPT.repel&&d>=2&&d<=3&&shifted(s,t,dx,dy,1))list.push({type:'repel',id:u.id,x:t.x,y:t.y});break;}}}
 }
 if(u.role==='anchor'&&!u.braced)list.push({type:'brace',id:u.id,x:u.x,y:u.y});
 if(u.role==='jumper'){for(const dx of [-1,1])for(const dy of [-1,1])if(free(s,u.x+dx,u.y+dy))list.push({type:'move',id:u.id,x:u.x+dx,y:u.y+dy});
  for(const [dx,dy] of DIRS)if(free(s,u.x+2*dx,u.y+2*dy))list.push({type:'jump',id:u.id,x:u.x+2*dx,y:u.y+2*dy});}
 }
 if(s.acted.length)list.push({type:'end'});
 return list;
}
export const sameAction=(a,b)=>!!a&&!!b&&a.type===b.type&&a.id===b.id&&a.x===b.x&&a.y===b.y;
/** Полный переход: действие + (если ход закончился) события конца хода. */
export function simulate(s,a){let n=copyUnits(s);
 if(a.type!=='end'){const u=n.units.find(u=>u.id===a.id);
  if(a.type==='move'||a.type==='jump'){u.x=a.x;u.y=a.y;u.braced=false;}
  if(a.type==='brace')u.braced=true;
  if(a.type==='push'){const dx=Math.sign(a.x-u.x),dy=Math.sign(a.y-u.y);n=shifted(n,at(n,a.x,a.y),dx,dy,u.role==='ram'?2:1,u.role==='anchor');if(!n)return null;}
  if(a.type==='repel'){const dx=Math.sign(a.x-u.x),dy=Math.sign(a.y-u.y);n=shifted(n,at(n,a.x,a.y),dx,dy,1);if(!n)return null;}
  if(a.type==='pull'){let t=at(n,a.x,a.y);const dx=Math.sign(u.x-t.x),dy=Math.sign(u.y-t.y),dist=Math.abs(u.x-t.x)+Math.abs(u.y-t.y);
   // Магнит тянет на 2 клетки (на 1, если между ними одна клетка); провал по пути — падение
   for(let k=0;k<Math.min(2,dist-1);k++){t.x+=dx;t.y+=dy;if(isHole(n,t.x,t.y)){t.alive=false;break;}}}
  n.units.forEach((v,i)=>{const p=s.units[i];if(v.x!==p.x||v.y!==p.y)v.since=s.ply+1;if(v.alive&&isHole(n,v.x,v.y))v.alive=false;});
  n.lost=n.lost.slice();n.units.forEach((v,i)=>{if(s.units[i].alive&&!v.alive)n.lost[v.team]++;});
  n.acted=[...n.acted,a.id];n.left=s.left-1;}
 n.ply=s.ply+1;
 const canAct=n.units.some(u=>u.alive&&u.team===n.turn&&!n.acted.includes(u.id));
 if(a.type==='end'||n.left<=0||!canAct)endTurn(n);
 return n;
}
/**
 * Конец хода:
 * • центр — отмеченная (розовая) клетка проваливается; если все целые клетки центра заняты,
 *   отмечается та, что занята дольше всех (провалится в конце следующего хода);
 * • край — после хода RING_TURN-1 краснеет, после хода RING_TURN обрушивается целиком;
 * • очки центра — +1 той команде, у которой в центре больше роботов;
 * • ход переходит сопернику, его Якоря снимают фиксацию.
 */
function endTurn(n){n.endedTurn=true;const aliveBefore=n.units.map(u=>u.alive);
 if(n.cracks?.length){const c=n.cracks[0];n.holes=[...n.holes,c];const v=at(n,...cell(c));if(v)v.alive=false;}
 n.cracks=null;
 {const left=CENTER.filter(c=>!n.holes.includes(c)),occ=left.map(c=>at(n,...cell(c)));
  if(left.length&&occ.every(Boolean)){let first=0;occ.forEach((u,i)=>{if(u.since<occ[first].since)first=i;});n.cracks=[left[first]];}}
 if(n.ring==='warn'){n.holes=[...n.holes,...RING];n.ring='gone';for(const u of n.units)if(u.alive&&RING.includes(u.x+','+u.y))u.alive=false;}
 else if(!n.ring&&n.turnNo+1>=RING_TURN)n.ring='warn';
 const c0=centerCount(n,0),c1=centerCount(n,1);if(c0!==c1)n.score[c0>c1?0:1]++;
 n.units.forEach((u,i)=>{if(aliveBefore[i]&&!u.alive)n.lost[u.team]++;});
 n.turn=1-n.turn;n.turnNo++;
 // Камбэк: если в прошлом ходу команда потеряла робота — у неё на одно действие больше
 n.bonus=OPT.comeback&&n.lost[n.turn]>0;n.left=PER_TURN+(n.bonus?1:0);n.lost=[0,0];n.acted=[];
 for(const u of n.units)if(u.team===n.turn)u.braced=false;
}
/** Роботы, выбывшие в результате действия. */
export function knocked(s,a,n=simulate(s,a)){return n?n.units.filter((u,i)=>!u.alive&&s.units[i].alive):[];}
/** Выбитые самим действием (вытолкнуты/притянуты), без тех, кто провалился на месте. */
export function displaced(s,a,n=simulate(s,a)){return knocked(s,a,n).filter(v=>{const b=s.units.find(t=>t.id===v.id);return b.x!==v.x||b.y!==v.y;});}
/** Фразы журнала ходов (интерфейс может заменить их переводом). */
export const TEXT={ended:'Ход завершён',out:'выбит',fell:'провалился',crack:'клетка центра рушится',ringStart:'края рушатся',ringGone:'края обрушились'};
export function describe(s,a,n=simulate(s,a)){let text=a.type==='end'?TEXT.ended:`${ROLES[s.units.find(u=>u.id===a.id).role].name}: ${ACTIONS[a.type].toLowerCase()}`;
 const out=displaced(s,a,n),sunk=knocked(s,a,n).filter(u=>!out.includes(u));const nm=l=>l.map(u=>ROLES[u.role].name).join(', ');
 if(out.length)text+=` · ${TEXT.out}: ${nm(out)}`;if(sunk.length)text+=` · ${TEXT.fell}: ${nm(sunk)}`;
 if(n.cracks&&n.cracks[0]!==s.cracks?.[0])text+=` · ${TEXT.crack}`;
 if(!s.ring&&n.ring)text+=` · ${TEXT.ringStart}`;if(s.ring==='warn'&&n.ring==='gone')text+=` · ${TEXT.ringGone}`;
 return text;}
function outcome(n){const eliminated=[0,1].filter(team=>n.units.filter(u=>u.team===team&&u.alive).length<=1);if(eliminated.length===2)n.draw=true;else if(eliminated.length===1)n.winner=1-eliminated[0];}
/** Решение по очкам центра (лимит ходов или повтор позиции). */
function byScore(n){n.byScore=true;if(n.score[0]===n.score[1])n.draw=true;else n.winner=n.score[0]>n.score[1]?0:1;}
/** Быстрый ход без проверки легальности, истории и повторов — для поиска. */
function step(s,a){const n=simulate(s,a);outcome(n);if(n.winner===null&&!n.draw&&n.turnNo>TURN_LIMIT)byScore(n);return n;}
export function apply(s,a){if(!legal(s).some(b=>sameAction(a,b)))return null;const n=simulate(s,a);n.history=s.history.concat([{team:s.turn,text:describe(s,a,n),action:a}]);n.seen={...s.seen};outcome(n);
 if(n.endedTurn&&n.winner===null&&!n.draw){const k=key(n);n.seen[k]=(n.seen[k]||0)+1;if(n.seen[k]>=3||n.turnNo>TURN_LIMIT)byScore(n);}
 delete n.endedTurn;if(n.winner===null&&!n.draw&&!legal(n).length)n.draw=true;return n;}

/**
 * Угрозы: каких роботов команды `team` соперник может выбить за свой ход (до двух действий),
 * вытолкнув или притянув их. Возвращает Map id → первое действие связки.
 */
export function threatsAgainst(s,team){const probe={...s,turn:1-team,left:PER_TURN,acted:[],winner:null,draw:false};const out=new Map();
 const lost=(n,first)=>{for(const u of n.units){const b=probe.units.find(t=>t.id===u.id);if(u.team===team&&b.alive&&!u.alive&&(b.x!==u.x||b.y!==u.y)&&!out.has(u.id))out.set(u.id,[first]);}};
 for(const a of legal(probe)){if(a.type==='end')continue;const n=simulate(probe,a);if(!n)continue;lost(n,a);
  if(n.turn===probe.turn)for(const b of legal(n)){if(b.type!=='push'&&b.type!=='pull')continue;const m=simulate(n,b);if(m)lost(m,a);}}
 return out;}

// ── Бот ─────────────────────────────────────────────
function value(s,team){if(s.winner!==null)return s.winner===team?1e5:-1e5;if(s.draw)return -25;let v=12*(s.score[team]-s.score[1-team]);
 const danger=[...s.holes,...(s.cracks||[]),...(s.ring==='warn'?RING:[])].map(cell);
 for(const u of s.units){if(!u.alive)continue;const sign=u.team===team?1:-1;let edge=Math.min(u.x,u.y,N-1-u.x,N-1-u.y);for(const [hx,hy] of danger)edge=Math.min(edge,Math.abs(hx-u.x)+Math.abs(hy-u.y)-1);v+=sign*(100+edge*6+(central(u)&&!s.holes.includes(u.x+','+u.y)?6:0)+(u.braced?3:0));}
 const enemies=s.units.filter(e=>e.alive&&e.team!==team);for(const u of s.units){if(!u.alive||u.team!==team||!enemies.length)continue;let m=99;for(const e of enemies)m=Math.min(m,Math.abs(e.x-u.x)+Math.abs(e.y-u.y));v-=1.5*m;}return v;}
const order=a=>a.type==='push'?0:a.type==='pull'||a.type==='repel'?1:a.type==='end'?4:2;
function search(s,team,depth,alpha,beta){if(depth===0||s.winner!==null||s.draw)return value(s,team);const moves=legal(s).sort((a,b)=>order(a)-order(b));if(!moves.length)return value(s,team);const max=s.turn===team;let best=max?-Infinity:Infinity;for(const a of moves){const v=search(step(s,a),team,depth-1,alpha,beta);if(max){if(v>best)best=v;if(best>alpha)alpha=best;}else{if(v<best)best=v;if(best<beta)beta=best;}if(beta<=alpha)break;}return best;}
export const LEVELS={easy:{name:'Новичок',depth:1,noise:45},normal:{name:'Боец',depth:3,noise:4},hard:{name:'Мастер',depth:4,noise:0}};
/** Выбор одного действия. level: easy | normal | hard. rand — источник случайности для разнообразия партий. */
export function bot(s,level='normal',rand=Math.random){const cfg=LEVELS[level]||LEVELS.normal,team=s.turn;let best=null,score=-Infinity;
 for(const a of legal(s).sort((a,b)=>order(a)-order(b))){const n=step(s,a);let v=cfg.depth>1?search(n,team,cfg.depth-1,score-cfg.noise-1,Infinity)+.08*value(n,team):value(n,team);if(n.winner===null&&!n.draw&&n.turn!==team&&s.seen[key(n)])v-=35;if(cfg.noise)v+=rand()*cfg.noise;if(v>score){score=v;best=a;}}
 return best;}
