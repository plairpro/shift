// Запасной канал для онлайна: сообщения через публичный сервис ntfy.sh по обычному HTTPS.
// Пошаговой игре не нужно прямое соединение — достаточно пересылать короткие сообщения о ходах.
// Интерфейс совместим с соединением PeerJS: on('open'|'data'|'close'|'error'), send(obj), close().
const BASE='https://ntfy.sh/';
export class Relay{
 constructor(code,isHost){this.topic=`shift-${code}-r`;this.isHost=isHost;this.me=Math.random().toString(36).slice(2,10);this.peer=null;this.handlers={};this.closed=false;this.isOpen=false;
  try{this.es=new EventSource(BASE+this.topic+'/sse');}catch(e){setTimeout(()=>this.emit('error',e));return;}
  this.es.onopen=()=>{if(!isHost&&!this.isOpen)this.knock();};
  this.es.onmessage=e=>{let d;try{d=JSON.parse(JSON.parse(e.data).message);}catch{return;}if(!d||d.f===this.me)return;this.receive(d);};
  this.es.onerror=()=>{if(!this.isOpen&&this.es.readyState===2)this.emit('error',new Error('relay'));};
 }
 on(ev,cb){(this.handlers[ev]??=[]).push(cb);return this;}
 emit(ev,arg){for(const cb of this.handlers[ev]||[])cb(arg);}
 post(obj){if(this.closed)return;fetch(BASE+this.topic,{method:'POST',body:JSON.stringify({f:this.me,...obj})}).catch(()=>{});}
 // Гость стучится, пока хозяин не ответит (не больше ~10 попыток, чтобы не упереться в лимиты сервиса)
 knock(){let n=0;const tick=()=>{if(this.isOpen||this.closed||n++>10)return;this.post({t:'join'});this.knockTimer=setTimeout(tick,2500);};tick();}
 receive(d){
  if(this.isHost&&d.t==='join'&&!this.peer){this.peer=d.f;this.post({t:'welcome',to:d.f});this.open();return;}
  if(!this.isHost&&d.t==='welcome'&&d.to===this.me&&!this.peer){this.peer=d.f;this.open();return;}
  if(d.t==='bye'&&d.f===this.peer){this.close(true);return;}
  if(d.t==='m'&&d.f===this.peer&&this.isOpen)this.emit('data',d.m);}
 open(){this.isOpen=true;clearTimeout(this.knockTimer);this.emit('open');}
 send(m){this.post({t:'m',m});}
 close(remote=false){if(this.closed)return;if(!remote&&this.isOpen)this.post({t:'bye'});this.closed=true;clearTimeout(this.knockTimer);this.es?.close();if(this.isOpen){this.isOpen=false;this.emit('close');}}
}
