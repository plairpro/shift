// Язык интерфейса: русский или английский.
// Порядок выбора: ?lang=ru|en в адресе → сохранённый выбор → язык браузера (ru/uk/be/kk → русский, остальное → английский).
import{ROLES,ACTIONS,LEVELS,TEXT}from'./engine.js';

const KEY='shift.lang';
function detect(){
 try{const q=new URLSearchParams(location.search).get('lang');if(q==='ru'||q==='en'){localStorage.setItem(KEY,q);return q;}}catch{}
 try{const s=localStorage.getItem(KEY);if(s==='ru'||s==='en')return s;}catch{}
 const langs=(navigator.languages?.length?navigator.languages:[navigator.language||'en']).map(l=>String(l).toLowerCase());
 return langs.some(l=>/^(ru|uk|be|kk)\b/.test(l))?'ru':'en';
}
export const LANG=detect();
export const EN=LANG==='en';
/** Строка на текущем языке: T('по-русски','in English'). */
export const T=(ru,en)=>EN?en:ru;
export function setLang(l){try{localStorage.setItem(KEY,l);}catch{}const u=new URL(location.href);u.searchParams.delete('lang');location.replace(u.href);}

// Статический текст страницы (index.html написан по-русски): точные совпадения текстовых узлов и атрибутов.
const PAGE={
 'Сдвиг — тактическая дуэль роботов. Толкай, притягивай, комбинируй ходы.':'Shift — a tactical robot duel. Push, pull, combine your moves.',
 'СДВИГ — дуэль роботов':'Shift — robot duel',
 'Сдвиг':'Shift',
 'Против бота':'Vs bot',
 'Правила':'Rules',
 'Звук':'Sound',
 'Новая игра':'New game',
 'Вы':'You',
 'Ход 1':'Turn 1',
 'выбей 3 из 4 ·':'knock out 3 of 4 ·',
 'очки центра 0 : 0':'center points 0 : 0',
 'Бот':'Bot',
 'Подготовка роботов…':'Preparing robots…',
 'Обозначения':'Legend',
 'ход':'move','прыжок':'jump','толчок':'push','притяжение':'pull','выбьет':'knocks out','провал':'hole','пропадёт':'collapses',
 'Сменить ракурс':'Change view',
 'Сверху':'Top',
 'Ваш ход':'Your turn',
 'Выберите робота на поле или в списке':'Pick a robot on the board or in the list',
 'Завершить ход':'End turn',
 'Предпросмотр':'Preview',
 'Отмена':'Cancel',
 'Подтвердить':'Confirm',
 'Ваш отряд':'Your squad',
 'Центр':'Center',
 'Подсказка':'Hint',
 'Вернуть ход':'Undo',
 'Последние действия':'Recent actions',
 'Толкай. Притягивай. Комбинируй ходы.':'Push. Pull. Combine your moves.',
 'Модели:':'Models:',
 'Закрыть':'Close',
 'Сдвиг · тактическая дуэль':'Shift · tactical duel',
 'Переиграй.':'Outplay.',
 'Вытолкни.':'Push out.',
 'Четыре робота с разными умениями и обрушающийся центр. Выбей трёх роботов соперника — за край или в провал.':'Four robots with different skills and a collapsing center. Knock out three enemy robots — off the edge or into a hole.',
 'Сила бота':'Bot strength',
 'Новичок':'Rookie','Боец':'Fighter','Мастер':'Master',
 'Играть против бота':'Play vs bot',
 'Вдвоём на одном экране':'Two players, one screen',
 'Онлайн с другом':'Online with a friend',
 'Никакой случайности в бою — только позиция и расчёт.':'No luck in battle — only position and calculation.',
 'Как играть':'How to play',
 'Поле — тоже оружие.':'The board is a weapon too.',
 'Кто ходит первым, решает «камень, ножницы, бумага» до первой победы. Ходят по очереди:':'Rock, paper, scissors (first win) decides who goes first. Players alternate:',
 'за ход — одно действие':'one action per turn',
 'любым своим роботом. Цель — выбить 3 из 4 роботов соперника: вытолкнуть за край или в провал.':'with any of your robots. Goal: knock out 3 of the 4 enemy robots — push them off the edge or into a hole.',
 'Выберите робота':'Pick a robot',
 '— на поле или в списке. На поле появятся все его варианты.':'— on the board or in the list. All its options appear on the board.',
 'Нажмите на метку.':'Tap a marker.',
 'Цвет подскажет действие, красный — кто-то вылетит за край или в провал.':'The color shows the action; red means someone goes off the edge or into a hole.',
 'Проверьте предпросмотр':'Check the preview',
 'и подтвердите. Повторный клик по той же метке тоже подтверждает.':'and confirm. Tapping the same marker again also confirms.',
 'Поле и расстановка':'Board and setup',
 'Поле 5×5, в середине — обрушаемый центр-крест из 5 клеток. Отряд стоит буквой «Т»: Таран, Якорь и Магнит в ряд, Прыгун — за Якорем на крайней линии. У соперника — зеркально.':'A 5×5 board with a collapsing cross-shaped center of 5 cells. Your squad stands in a T: Ram, Anchor and Magnet in a row, the Jumper behind the Anchor on the back edge. The opponent is mirrored.',
 'Все роботы':'All robots',
 'Ходят на 1 клетку по прямой (не в провал). Толкают соседа и всю цепочку за ним на 1 клетку — своих тоже. По диагонали ходит только Прыгун; толчки, притяжение и прыжки — только по прямой.':'Move 1 cell orthogonally (not into a hole). Push a neighbor and the whole chain behind it by 1 cell — your own robots too. Only the Jumper moves diagonally; pushes, pulls and jumps are straight lines only.',
 'Обрушение поля':'Collapsing board',
 'Когда заняты все целые клетки центра, та, что занята дольше всех, становится розовой и проваливается в конце следующего хода. Дальше так же с оставшимися. После 30-го хода весь внешний край поля обрушивается разом: за 5 ходов до этого он бледнеет и включается отсчёт, а в последний ход становится розовым. Кто стоит на провалившейся клетке — выбывает. В провал нельзя зайти, но туда можно столкнуть или притянуть.':'When every intact center cell is occupied, the one held longest turns pink and falls at the end of the next turn. Then the same with the rest. After turn 30 the whole outer ring collapses at once: 5 turns before, it fades and a countdown starts; on the last turn it turns pink. A robot on a collapsed cell is out. You can’t step into a hole, but you can push or pull robots into it.',
 'Очки центра: в конце каждого хода +1 той команде, у которой в центре больше роботов. Если за 60 ходов никто не выбил троих или позиция повторилась трижды — побеждает тот, у кого больше очков центра (равенство — ничья).':'Center points: at the end of each turn, +1 to the team with more robots in the center. If no one knocks out three robots in 60 turns, or a position repeats three times, the higher center score wins (a tie is a draw).',
 'Клавиши:':'Keys:',
 'выбор робота,':'pick a robot,',
 'подтвердить,':'confirm,',
 'отмена,':'cancel,',
 'вернуть действие.':'undo.',
 'Понятно':'Got it',
 'Онлайн · дуэль по приглашению':'Online · invite duel',
 'Позови соперника.':'Invite an opponent.',
 'Создай комнату и отправь ссылку другу. Оставь эту вкладку открытой.':'Create a room and send the link to a friend. Keep this tab open.',
 'Создать комнату':'Create room',
 'Ссылка-приглашение':'Invite link',
 'Скопировать ссылку':'Copy link',
 'или введи код комнаты':'or enter a room code',
 'Код комнаты':'Room code',
 'Войти':'Join',
 'Прямое соединение WebRTC. В некоторых сетях подключение может быть недоступно. При разрыве создайте новую комнату.':'Moves travel through a public relay or a direct WebRTC link. Some networks may block it. If the connection drops, create a new room.',
 'Кто ходит первым':'Who goes first',
 'Камень, ножницы, бумага':'Rock, paper, scissors',
 'Камень':'Rock','Ножницы':'Scissors','Бумага':'Paper',
 'Начать партию':'Start the game',
 'Дуэль завершена':'Duel over',
 'Ещё партия':'Play again',
 'Посмотреть поле':'View the board',
};

function translatePage(){
 document.documentElement.lang='en';
 const norm=s=>s.replace(/\s+/g,' ').trim();
 const w=document.createTreeWalker(document.body,NodeFilter.SHOW_TEXT);const nodes=[];while(w.nextNode())nodes.push(w.currentNode);
 for(const n of nodes){const k=norm(n.nodeValue);if(PAGE[k]){const lead=n.nodeValue.match(/^\s*/)[0],tail=n.nodeValue.match(/\s*$/)[0];n.nodeValue=lead+PAGE[k]+tail;}}
 for(const el of document.querySelectorAll('[aria-label],[placeholder],[title]'))for(const a of ['aria-label','placeholder','title']){const v=el.getAttribute(a);if(v&&PAGE[norm(v)])el.setAttribute(a,PAGE[norm(v)]);}
 document.title=PAGE[norm(document.title)]||document.title;
 const d=document.querySelector('meta[name="description"]');if(d&&PAGE[norm(d.content)])d.content=PAGE[norm(d.content)];
}

// Тексты игровых правил (роли, действия, уровни бота, журнал ходов).
function translateEngine(){
 Object.assign(ROLES.ram,{name:'Ram',short:'Pushes 2 cells',tip:'Pushes the adjacent robot and the whole chain behind it two cells at once. Most dangerous near the edge.'});
 Object.assign(ROLES.magnet,{name:'Magnet',short:'Pulls 2 cells',tip:'Pulls the first robot in a line from 2–5 cells away by two cells toward itself (by one if there is a single cell between them). Pulls across holes — if a hole is in the way, the robot falls in. Can’t pull through other robots or a braced robot.'});
 Object.assign(ROLES.anchor,{name:'Anchor',short:'Shield for a turn',tip:'Braces until the start of your next turn: during the opponent’s turn it can’t be pulled, and only another Anchor can push it. A chain pushed into it stops there. Then the brace wears off — brace again to keep standing firm. Doesn’t save it from a hole.'});
 Object.assign(ROLES.jumper,{name:'Jumper',short:'Moves diagonally too',tip:'Moves one cell in any direction, including diagonals. Jumps exactly two cells in a straight line only — over any robots.'});
 Object.assign(ACTIONS,{move:'Move',push:'Push',pull:'Pull',brace:'Brace',jump:'Jump',repel:'Repel',end:'End turn'});
 LEVELS.easy.name='Rookie';LEVELS.normal.name='Fighter';LEVELS.hard.name='Master';
 Object.assign(TEXT,{ended:'Turn ended',out:'out',fell:'fell',crack:'a center cell is collapsing',ringStart:'the edges are collapsing',ringGone:'the edges collapsed'});
}

export function applyLanguage(){if(EN){translateEngine();translatePage();}}
