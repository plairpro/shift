# СДВИГ / SHIFT

Browser prototype of a deterministic 1v1 tactical robot duel, intended for https://plairpro.github.io/shift/.

## Run

Node.js 22.12+ or 24.

```sh
npm ci
npm run dev
npm test
npm run build
```

In restricted containers use `npm run dev -- --host 127.0.0.1`.
The `dist/` directory is a standalone static build. Serve over HTTP(S), not file://.
All robot models ship locally. No CDN is required for game code or models.

## Modes

- Bot: alpha-beta search, three levels — Новичок (1 ply + noise), Боец (2 ply), Мастер (3 ply). No hidden bonuses.
- Local: two people on one screen.
- Online: invite link / code using PeerJS public signaling and WebRTC data channel. Host validates actions and move numbers. No backend account, matchmaking, authoritative anti-cheat, persistence, reconnection, or guaranteed TURN relay. Some networks cannot establish a connection. This mode is a prototype, not tournament infrastructure.

## Rules v0.1

6×6 board; identical four-robot teams. Each turn is exactly one robot action. All information is public.

- Every robot moves 1 empty cell orthogonally.
- Every robot pushes an adjacent robot and the contiguous chain beyond it one cell. The Ram pushes two steps; the entire action must be legal. Friendly robots can be pushed. Robots crossing the boundary are removed.
- Magnet pulls the first robot on an unobstructed orthogonal ray at distance 2–3 one cell toward itself.
- Anchor can brace until it moves. Braced robots cannot be pulled and can be pushed only by an Anchor (also as part of a chain).
- Jumper can also step 1 cell diagonally, or jump exactly two cells orthogonally or diagonally to an empty cell.
- Center collapse: whenever all intact central cells are occupied (4, then 3, 2, 1), the one held longest is marked and becomes a hole after the next ply. The first center hole also dooms the outer ring: one ply later all 20 edge cells collapse at once and the board shrinks to 4×4. A robot on it falls. Holes cannot be entered by moving or jumping, but robots can be pushed or pulled into them.
- Eliminate three of four opposing robots to win. Both teams down to one or zero = draw. Threefold repetition (including player to move and center state) or 120 plies = draw.
- No clocks in this first prototype. First-player advantage and strategic depth are not yet established through playtesting.

Click a robot: every legal target appears on the board at once, colour-coded (green move, blue jump, amber push, violet pull, yellow brace, red = knocks someone out). Click a target to preview, then confirm (button, Enter, or a second click on the same target). Red pulsing rings mark your robots the opponent can knock out next turn; the preview warns if your move exposes a robot. Hint (master-level suggestion) and Undo are available vs bot and on one screen. Keys: 1–4 select, Enter confirm, Esc cancel, Z undo. Camera button toggles oblique/overhead; online guests see the board from their own side.

## GitHub Pages

Create/access `plairpro/shift`, push this project to `main`, and in Settings → Pages select GitHub Actions. The included `.github/workflows/pages.yml` runs tests/build and deploys `dist/`.

## Assets

See ASSETS.md. Four animated Quaternius mechs, CC0.
