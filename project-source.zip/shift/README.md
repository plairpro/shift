# СДВИГ / SHIFT

Browser prototype of a deterministic 1v1 tactical robot duel, intended for https://plairpro.github.io/shift/.

## Run

Node.js 22.12+ or 24.

```sh
npm ci
npm run dev
npm test
npm run build
```

In restricted containers use `npm run dev -- --host 127.0.0.1`.
The `dist/` directory is a standalone static build. Serve over HTTP(S), not file://.
All robot models ship locally. No CDN is required for game code or models.

## Modes

- Bot: deterministic two-ply minimax, no hidden bonuses.
- Local: two people on one screen.
- Online: invite link / code using PeerJS public signaling and WebRTC data channel. Host validates actions and move numbers. No backend account, matchmaking, authoritative anti-cheat, persistence, reconnection, or guaranteed TURN relay. Some networks cannot establish a connection. This mode is a prototype, not tournament infrastructure.

## Rules v0.1

6×6 board; identical four-robot teams. Each turn is exactly one robot action OR one 90° turn of the central 2×2 platform. All information is public.

- Every robot moves 1–2 empty cells orthogonally, without jumping occupied cells.
- Every robot pushes an adjacent robot and the contiguous chain beyond it one cell. The Ram pushes two steps; the entire action must be legal. Friendly robots can be pushed. Robots crossing the boundary are removed.
- Magnet pulls the first robot on an unobstructed orthogonal ray at distance 2–3 one cell toward itself.
- Anchor can brace until it moves. Braced robots cannot be pushed or pulled; braced anchors on the center block rotation.
- Jumper jumps exactly two cells orthogonally or diagonally to an empty cell.
- Rotation requires at least one live robot in the central 2×2. Rotation on consecutive turns is forbidden.
- Eliminate three of four opposing robots to win. Both teams down to one or zero = draw. Threefold repetition (including player to move and rotation availability) or 120 plies = draw.
- No clocks in this first prototype. First-player advantage and strategic depth are not yet established through playtesting.

Click a robot, choose an action, click a highlighted target, then confirm. Rotate buttons also require confirmation. Esc cancels; Enter confirms. Controls support touch. Camera button switches between oblique and overhead views.

## GitHub Pages

Create/access `plairpro/shift`, push this project to `main`, and in Settings → Pages select GitHub Actions. The included `.github/workflows/pages.yml` runs tests/build and deploys `dist/`.

## Assets

See ASSETS.md. Four animated Quaternius mechs, CC0.
