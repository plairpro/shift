# Validation — 2026-10-05

- `npm test`: 8 passing engine tests: legal turn ownership, chain ejection and victory, anchored blocking, center rotation, magnet obstruction, jumping/unbracing, legal bot choice, board invariants.
- `npm run build`: succeeds. Robots, code, and fonts served locally.
- Chromium 134 headless at 1440×1000 and 390×844: all models loaded; local move selection/preview/confirmation, central rotation, bot reply and mobile move passed. No uncaught JavaScript errors. Mobile page has no horizontal overflow.
- Fixed a raycast bug where decorative grid edges intercepted cell clicks.
- Fixed the arena changing size when the action panel expanded.
- Screenshots in preview/.
- Two browser clients with mocked transport: invite/handshake, host move, host validation of guest move and matching state on both clients passed. This tests application synchronization, not real WebRTC transport.
- Real PeerJS signaling connection attempted in this environment: failed with network error. Real Internet WebRTC connectivity remains unverified.
- Automated testing is not evidence of balanced competitive play or performance on physical mobile hardware. First-player advantage and prolonged defensive play require human playtesting.
- GitHub connector identifies plairpro and can access four existing repositories, but plairpro/shift returns 404. No available connector method creates repositories. Nothing has been published to the requested URL yet.
