# Validation — 2026-10-05

- `npm test`: 8 passing engine tests: legal turn ownership, chain ejection and victory, anchored blocking, center rotation, magnet obstruction, jumping/unbracing, legal bot choice, board invariants.
- `npm run build`: succeeds. Robots, code, and fonts served locally.
- Chromium 134 headless at 1440×1000 and 390×844: all models loaded; local move selection/preview/confirmation, central rotation, bot reply and mobile move passed. No uncaught JavaScript errors. Mobile page has no horizontal overflow.
- Fixed a raycast bug where decorative grid edges intercepted cell clicks.
- Fixed the arena changing size when the action panel expanded.
- Screenshots in preview/.
- Two browser clients with mocked transport: invite/handshake, host move, host validation of guest move and matching state on both clients passed. This tests application synchronization, not real WebRTC transport.
- Real PeerJS signaling connection attempted in this environment: failed with network error. Real Internet WebRTC connectivity remains unverified.
- Automated testing is not evidence of balanced competitive play or performance on physical mobile hardware. First-player advantage and prolonged defensive play require human playtesting.
- GitHub connector identifies plairpro and can access four existing repositories, but plairpro/shift returns 404. No available connector method creates repositories. Nothing has been published to the requested URL yet.

# Validation — v0.2 interface pass

- `npm test`: 11 passing (added threat detection, braced-anchor immunity, bot levels).
- Bot search ~30× faster (units-only cloning instead of JSON copies of history): Боец ≈ 5 ms, Мастер ≈ 30 ms per move.
- Self-play: any non-blundering bot pair (Боец/Мастер, 12 games each) draws at the 120-ply limit; 1-ply players lose to Боец every time. Conclusion: losses to the bot come from unseen one-move threats — hence threat rings and exposure warnings.
- Headless Chromium (SwiftShader) 1440×950, 1200×900, 390×844: model load, selection, preview, confirm, bot reply, threat display, hint+confirm full game to victory dialog, rules dialog, overhead camera. No uncaught errors.
- Online protocol bumped to version 2 (room ids `shift-v2-*`); real WebRTC still unverified.
