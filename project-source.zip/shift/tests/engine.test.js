import {test} from 'node:test';import assert from 'node:assert/strict';import{initial,legal,apply,simulate,central,bot}from'../src/engine.js';
const sparse=()=>{let s=initial();s.units.forEach(u=>u.alive=false);return s;};
test('initial board and turn ownership',()=>{let s=initial();assert.equal(s.units.length,8);assert(legal(s).every(a=>a.id?.startsWith('0-')));assert.equal(apply(s,{type:'move',id:'1-ram',x:0,y:0}),null);});
test('ram pushes whole chain out, wins after third elimination',()=>{let s=sparse();Object.assign(s.units[0],{alive:true,x:2,y:2});Object.assign(s.units[1],{alive:true,x:0,y:0});Object.assign(s.units[4],{alive:true,x:3,y:2});Object.assign(s.units[5],{alive:true,x:4,y:2});let n=apply(s,{type:'push',id:'0-ram',x:3,y:2});assert(n);assert.equal(n.units[4].x,5);assert.equal(n.units[5].alive,false);assert.equal(n.winner,0);});
test('braced anchor blocks a non-anchor chain push',()=>{let s=initial();Object.assign(s.units[0],{x:1,y:2});Object.assign(s.units[6],{x:2,y:2,braced:true});assert(!legal(s).some(a=>a.type==='push'&&a.id==='0-ram'&&a.x===2));});
test('magnet cannot pull through a figure',()=>{let s=initial();Object.assign(s.units[1],{x:2,y:3});Object.assign(s.units[4],{x:2,y:1});assert(legal(s).some(a=>a.type==='pull'&&a.x===2&&a.y===1));Object.assign(s.units[2],{x:2,y:2});assert(!legal(s).some(a=>a.type==='pull'&&a.x===2&&a.y===1));});
test('jump ignores occupied path and unbracing on movement',()=>{let s=initial();assert(legal(s).some(a=>a.type==='jump'));s.units[2].braced=true;const a=legal(s).find(a=>a.id==='0-anchor'&&a.type==='move');assert.equal(apply(s,a).units[2].braced,false);});
test('bot returns a legal action without mutating state',()=>{let s=initial(),before=JSON.stringify(s),a=bot(s);assert(apply(s,a));assert.equal(JSON.stringify(s),before);});
test('legal random play keeps live units unique and on board',()=>{let s=initial();for(let i=0;i<100&&s.winner===null&&!s.draw;i++){let l=legal(s);s=apply(s,l[(i*17+3)%l.length]);const u=s.units.filter(u=>u.alive);assert.equal(new Set(u.map(u=>`${u.x},${u.y}`)).size,u.length);assert(u.every(u=>u.x>=0&&u.x<6&&u.y>=0&&u.y<6));}});
import{threatsAgainst,LEVELS,knocked}from'../src/engine.js';
test('threats: ram next to a unit on the edge is a threat',()=>{let s=sparse();Object.assign(s.units[0],{alive:true,x:3,y:0});Object.assign(s.units[1],{alive:true,x:1,y:1});Object.assign(s.units[2],{alive:true,x:0,y:3});Object.assign(s.units[4],{alive:true,x:4,y:0});Object.assign(s.units[5],{alive:true,x:5,y:5});const t=threatsAgainst(s,1);assert(t.has('1-ram'));assert(!threatsAgainst(s,0).has('0-ram'));});
test('threats ignore braced anchors',()=>{let s=sparse();Object.assign(s.units[0],{alive:true,x:4,y:2});Object.assign(s.units[1],{alive:true,x:0,y:0});Object.assign(s.units[6],{alive:true,x:5,y:2,braced:true});Object.assign(s.units[5],{alive:true,x:3,y:3});assert(!threatsAgainst(s,1).has('1-anchor'));s.units[6].braced=false;assert(threatsAgainst(s,1).has('1-anchor'));});
test('every bot level returns a legal action, hard takes a winning push',()=>{let s=sparse();Object.assign(s.units[0],{alive:true,x:2,y:2});Object.assign(s.units[1],{alive:true,x:0,y:0});Object.assign(s.units[4],{alive:true,x:3,y:2});Object.assign(s.units[5],{alive:true,x:4,y:2});Object.assign(s.units[6],{alive:true,x:0,y:5});for(const lv of Object.keys(LEVELS))assert(apply(s,bot(s,lv)));const a=bot(s,'hard');assert.equal(knocked(s,a).filter(u=>u.team===1).length>=1,true);});
test('only an anchor can push a braced anchor',()=>{let s=sparse();Object.assign(s.units[0],{alive:true,x:1,y:2});Object.assign(s.units[2],{alive:true,x:3,y:3});Object.assign(s.units[1],{alive:true,x:5,y:5});Object.assign(s.units[6],{alive:true,x:2,y:2,braced:true});Object.assign(s.units[4],{alive:true,x:3,y:2});Object.assign(s.units[5],{alive:true,x:0,y:5});
 assert(!legal(s).some(a=>a.type==='push'&&a.id==='0-ram'));const a=legal(s).find(a=>a.type==='push'&&a.id==='0-anchor'&&a.x===3&&a.y===2);assert(a);
 Object.assign(s.units[2],{x:2,y:3});const b=legal(s).find(a=>a.type==='push'&&a.id==='0-anchor'&&a.x===2&&a.y===2);assert(b);const n=apply(s,b);assert.deepEqual([n.units[6].x,n.units[6].y],[2,1]);assert.equal(n.units[6].braced,true);});

test('center collapse: when all intact center cells are held, the longest-held one falls after the next ply',()=>{let s=sparse();
 const put=(i,x,y,since)=>Object.assign(s.units[i],{alive:true,x,y,since});
 put(0,2,2,5);put(1,3,2,1);put(4,3,3,4);put(5,0,0,0);put(6,5,5,0);put(2,2,4,0);
 // синий Якорь занимает последнюю клетку центра (2,3)
 let n=apply(s,{type:'move',id:'0-anchor',x:2,y:3});assert(n);assert.deepEqual(n.cracks,['3,2']);assert.deepEqual(n.holes,[]);
 // следующий ход: проваливается (3,2) — там стоял синий Магнит
 const m=legal(n).find(a=>a.id==='1-anchor'&&a.type==='move');n=apply(n,m);assert.deepEqual(n.holes,['3,2']);assert.equal(n.units[1].alive,false);
 // в провал нельзя войти, но туда можно столкнуть
 assert(!legal(n).some(a=>a.type==='move'&&a.x===3&&a.y===2));
});
test('push into a hole knocks out',()=>{let s=sparse();s.holes=['2,2'];s.cracks=[];Object.assign(s.units[0],{alive:true,x:4,y:2});Object.assign(s.units[4],{alive:true,x:3,y:2});Object.assign(s.units[1],{alive:true,x:0,y:5});Object.assign(s.units[5],{alive:true,x:5,y:5});Object.assign(s.units[6],{alive:true,x:5,y:0});
 const n=apply(s,{type:'push',id:'0-ram',x:3,y:2});assert(n);assert.equal(n.units[4].alive,false);});

test('after a hole, the remaining three cells collapse the same way when all held',()=>{let s=sparse();s.holes=['2,2'];s.turn=1;s.ply=10;
 const put=(i,x,y,since)=>Object.assign(s.units[i],{alive:true,x,y,since});
 put(0,3,2,7);put(1,3,3,2);put(4,0,0,0);put(5,5,5,0);put(6,1,3,0);put(2,0,5,0);
 let n=apply(s,{type:'move',id:'1-anchor',x:2,y:3});assert(n);assert.deepEqual(n.cracks,['3,3']);
 n=apply(n,legal(n).find(a=>a.id==='0-ram'&&a.type==='move'&&a.x===4));assert.deepEqual(n.holes,['2,2','3,3']);assert.equal(n.units[1].alive,false);assert.equal(n.cracks,null);});

test('outer ring is doomed only after the whole center has fallen',()=>{let s=sparse();s.holes=['3,2','3,3','2,3'];s.cracks=['2,2'];s.ply=10;
 const put=(i,x,y)=>Object.assign(s.units[i],{alive:true,x,y,since:0});
 put(0,1,1);put(1,0,3);put(2,3,3);put(4,2,2);put(5,4,4);put(6,5,1);put(7,2,4);
 let n=apply(s,{type:'move',id:'0-ram',x:1,y:2});assert.equal(n.ring,'warn');assert.equal(n.units[4].alive,false);
 n=apply(n,legal(n).find(a=>a.id==='1-magnet'&&a.type==='move'&&a.x===3));assert.equal(n.ring,'gone');
 assert.equal(n.units[1].alive,false);assert.equal(n.units[6].alive,false);assert(n.units[0].alive);
 assert(!legal(n).some(a=>a.type==='move'&&(a.x===0||a.y===0||a.x===5||a.y===5)));});

test('a first center hole alone does not doom the ring',()=>{let s=sparse();s.cracks=['2,2'];s.ply=10;
 const put=(i,x,y)=>Object.assign(s.units[i],{alive:true,x,y,since:0});put(0,1,1);put(1,0,3);put(4,4,4);put(5,5,5);put(6,5,1);
 const n=apply(s,{type:'move',id:'0-ram',x:1,y:2});assert.deepEqual(n.holes,['2,2']);assert.equal(n.ring,null);});
