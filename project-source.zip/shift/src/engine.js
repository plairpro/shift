export const ROLES={ram:{name:'Таран',icon:'↟',model:'George',tip:'Толкает цепочку на две клетки. Остальные — на одну.'},magnet:{name:'Магнит',icon:'⊂',model:'Leela',tip:'Притягивает робота с расстояния 2–3 клеток на одну клетку.'},anchor:{name:'Якорь',icon:'⊥',model:'Mike',tip:'Закрепляется: нельзя сдвинуть. На центре блокирует платформу. Ход снимает фиксацию.'},jumper:{name:'Прыгун',icon:'⌁',model:'Stan',tip:'Прыгает на две клетки по прямой или диагонали, через любые фигуры.'}};
export const DIRS=[[1,0],[-1,0],[0,1],[0,-1]];
export const inside=(x,y)=>x>=0&&x<6&&y>=0&&y<6;
export const central=(u)=>u.x>=2&&u.x<=3&&u.y>=2&&u.y<=3;
export const at=(s,x,y)=>s.units.find(u=>u.alive&&u.x===x&&u.y===y);
export const clone=s=>JSON.parse(JSON.stringify(s));
export function key(s){return JSON.stringify([s.turn,s.lastRotation,s.units.map(u=>[u.id,u.x,u.y,u.alive,u.braced])]);}
export function initial(){let units=[];[0,1].forEach(team=>Object.keys(ROLES).forEach((role,i)=>units.push({id:`${team}-${role}`,role,team,x:team?4-i:1+i,y:team?1:4,alive:true,braced:false})));let s={units,turn:0,ply:0,winner:null,draw:false,lastRotation:false,history:[],seen:{}};s.seen[key(s)]=1;return s;}
function shifted(s,target,dx,dy,steps){const n=clone(s);const id=target.id;for(let i=0;i<steps;i++){let t=n.units.find(u=>u.id===id);if(!t.alive)break;let chain=[],cur=t;while(cur){if(cur.braced)return null;chain.push(cur);cur=at(n,cur.x+dx,cur.y+dy);}for(const v of chain.reverse()){v.x+=dx;v.y+=dy;if(!inside(v.x,v.y))v.alive=false;}}return n;}
export function legal(s){if(s.winner!==null||s.draw)return [];let list=[];for(const u of s.units.filter(u=>u.alive&&u.team===s.turn)){
 for(const [dx,dy] of DIRS){for(let d=1;d<=2;d++){const x=u.x+dx*d,y=u.y+dy*d;if(!inside(x,y)||at(s,x,y))break;list.push({type:'move',id:u.id,x,y});}
 const t=at(s,u.x+dx,u.y+dy);if(t&&shifted(s,t,dx,dy,u.role==='ram'?2:1))list.push({type:'push',id:u.id,x:t.x,y:t.y});
 if(u.role==='magnet'){for(let d=1;d<=3;d++){const t=at(s,u.x+dx*d,u.y+dy*d);if(t){if(d>=2&&!t.braced)list.push({type:'pull',id:u.id,x:t.x,y:t.y});break;}}}
 }
 if(u.role==='anchor'&&!u.braced)list.push({type:'brace',id:u.id,x:u.x,y:u.y});
 if(u.role==='jumper')for(const dx of [-2,0,2])for(const dy of [-2,0,2])if((dx||dy)&&inside(u.x+dx,u.y+dy)&&!at(s,u.x+dx,u.y+dy))list.push({type:'jump',id:u.id,x:u.x+dx,y:u.y+dy});
 }
 if(!s.lastRotation&&s.units.some(u=>u.alive&&central(u))&&!s.units.some(u=>u.alive&&u.braced&&central(u)))list.push({type:'rotate',dir:1},{type:'rotate',dir:-1});
 return list;
}
export const sameAction=(a,b)=>!!a&&!!b&&a.type===b.type&&a.id===b.id&&a.x===b.x&&a.y===b.y&&a.dir===b.dir;
export function simulate(s,a){let n=clone(s),u=n.units.find(u=>u.id===a.id);if(a.type==='move'||a.type==='jump'){u.x=a.x;u.y=a.y;u.braced=false;}if(a.type==='brace')u.braced=true;
 if(a.type==='push'){const dx=Math.sign(a.x-u.x),dy=Math.sign(a.y-u.y);n=shifted(n,at(n,a.x,a.y),dx,dy,u.role==='ram'?2:1);if(!n)return null;}
 if(a.type==='pull'){let t=at(n,a.x,a.y);t.x+=Math.sign(u.x-t.x);t.y+=Math.sign(u.y-t.y);}
 if(a.type==='rotate')for(const t of n.units.filter(t=>t.alive&&central(t))){const x=t.x,y=t.y;t.x=a.dir===1?5-y:y;t.y=a.dir===1?x:5-x;}
 return n;
}
export function describe(s,a,n=simulate(s,a)){let text=a.type==='rotate'?`Платформа ${a.dir===1?'↻':'↺'}`:`${ROLES[s.units.find(u=>u.id===a.id).role].name}: ${{move:'ход',push:'толчок',pull:'притяжение',brace:'фиксация',jump:'прыжок'}[a.type]}`;const lost=n.units.filter((u,i)=>!u.alive&&s.units[i].alive);if(lost.length)text+=` · за край: ${lost.map(u=>ROLES[u.role].name).join(', ')}`;return text;}
export function apply(s,a){if(!legal(s).some(b=>sameAction(a,b)))return null;const n=simulate(s,a);n.history.push({team:s.turn,text:describe(s,a,n),action:a});n.ply++;n.turn=1-s.turn;n.lastRotation=a.type==='rotate';const eliminated=[0,1].filter(team=>n.units.filter(u=>u.team===team&&u.alive).length<=1);if(eliminated.length===2)n.draw=true;else if(eliminated.length===1)n.winner=1-eliminated[0];const k=key(n);n.seen[k]=(n.seen[k]||0)+1;if(n.winner===null&&(n.seen[k]>=3||n.ply>=120))n.draw=true;if(n.winner===null&&!n.draw&&!legal(n).length)n.draw=true;return n;}
function value(s,team){if(s.winner!==null)return s.winner===team?1e5:-1e5;if(s.draw)return -25;let v=0;for(const u of s.units.filter(u=>u.alive)){const sign=u.team===team?1:-1;const edge=Math.min(u.x,u.y,5-u.x,5-u.y);v+=sign*(100+edge*6+(central(u)?5:0)+(u.braced?4:0));}for(const u of s.units.filter(u=>u.alive&&u.team===team)){const enemies=s.units.filter(e=>e.alive&&e.team!==team);if(enemies.length)v-=1.5*Math.min(...enemies.map(e=>Math.abs(e.x-u.x)+Math.abs(e.y-u.y)));}return v;}
export function bot(s){const team=s.turn;let best=null,score=-Infinity;for(const a of legal(s)){const n=apply(s,a);let v=value(n,team);if(n.winner===null&&!n.draw){let worst=Infinity;for(const b of legal(n)){const nn=apply(n,b);worst=Math.min(worst,value(nn,team));}v=worst+.08*value(n,team);if(n.seen[key(n)]>1)v-=35;}if(v>score){score=v;best=a;}}return best;}
