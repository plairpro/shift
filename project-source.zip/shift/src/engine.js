// СДВИГ — игровая логика. Чистые функции, без DOM.
export const ROLES={
 ram:{name:'Таран',icon:'ram',model:'George',short:'Толкает на 2 клетки',tip:'Толкает соседнего робота и всю цепочку за ним сразу на две клетки. Самый опасный у края.'},
 magnet:{name:'Магнит',icon:'magnet',model:'Leela',short:'Тянет на 2 клетки',tip:'Притягивает первого робота на линии с расстояния 2–5 клеток на две клетки к себе (на одну, если между ними одна клетка). Тянет через провалы — если провал на пути, робот в него падает. Через фигуры и закреплённых не тянет.'},
 anchor:{name:'Якорь',icon:'anchor',model:'Mike',short:'Щит на ход соперника',tip:'Закрепляется до начала вашего следующего хода: в ход соперника его нельзя притянуть, а толкнуть может только другой Якорь. Потом фиксация снимается — чтобы стоять дальше, закрепитесь снова. От провала не спасает.'},
 jumper:{name:'Прыгун',icon:'jumper',model:'Stan',short:'Ходит и по диагонали',tip:'Ходит на одну клетку в любую сторону, включая диагонали, или прыгает ровно на две клетки по прямой или диагонали — через любые фигуры.'}
};
export const ACTIONS={move:'Ход',push:'Толчок',pull:'Притянуть',brace:'Закрепиться',jump:'Прыжок',end:'Завершить ход'};
/** Действий за ход (разными роботами). */
export const PER_TURN=2;
/** После этого хода обрушивается внешний край поля. */
export const RING_TURN=30;
/** После этого хода партия заканчивается по очкам центра. */
export const TURN_LIMIT=60;
export const DIRS=[[1,0],[-1,0],[0,1],[0,-1]];
export const inside=(x,y)=>x>=0&&x<6&&y>=0&&y<6;
export const central=(u)=>u.x>=2&&u.x<=3&&u.y>=2&&u.y<=3;
export const at=(s,x,y)=>s.units.find(u=>u.alive&&u.x===x&&u.y===y);
/** Центр 2×2 по часовой стрелке (как видит голубой игрок). */
export const CENTER=['2,2','3,2','3,3','2,3'];
/** Внешнее кольцо поля (край 6×6). */
export const RING=[];for(let x=0;x<6;x++)for(let y=0;y<6;y++)if(x===0||y===0||x===5||y===5)RING.push(x+','+y);
export const isHole=(s,x,y)=>s.holes.includes(x+','+y);
export const nextCrack=s=>s.cracks?.[0]??null;
const cell=c=>c.split(',').map(Number);
const copyUnits=s=>({...s,units:s.units.map(u=>({...u})),acted:s.acted.slice(),score:s.score.slice()});
export const clone=s=>({...copyUnits(s),history:s.history.slice(),seen:{...s.seen}});
export function key(s){return JSON.stringify([s.turn,s.holes,s.cracks,s.ring,s.units.map(u=>[u.id,u.x,u.y,u.alive,u.braced])]);}
/** first — команда, которая ходит первой (по итогам «камень, ножницы, бумага»). */
export function initial(first=0){let units=[];[0,1].forEach(team=>Object.keys(ROLES).forEach((role,i)=>units.push({id:`${team}-${role}`,role,team,x:team?4-i:1+i,y:team?1:4,alive:true,braced:false,since:0})));
 let s={units,turn:first,first,ply:0,turnNo:1,left:PER_TURN,acted:[],score:[0,0],winner:null,draw:false,byScore:false,holes:[],cracks:null,ring:null,history:[],seen:{}};s.seen[key(s)]=1;return s;}
/** Сколько своих роботов команда держит на целых клетках центра. */
export const centerCount=(s,team)=>CENTER.filter(c=>!s.holes.includes(c)&&at(s,...cell(c))?.team===team).length;
/** Сдвиг цепочки. heavy — толкает Якорь: только он сдвигает закреплённых. */
function shifted(s,target,dx,dy,steps,heavy=false){const n=copyUnits(s);const id=target.id;for(let i=0;i<steps;i++){let t=n.units.find(u=>u.id===id);if(!t.alive)break;let chain=[],cur=t;while(cur){if(cur.braced&&!heavy)return null;chain.push(cur);cur=at(n,cur.x+dx,cur.y+dy);}for(const v of chain.reverse()){v.x+=dx;v.y+=dy;if(!inside(v.x,v.y)||isHole(n,v.x,v.y))v.alive=false;}}return n;}
const free=(s,x,y)=>inside(x,y)&&!at(s,x,y)&&!isHole(s,x,y);
export function legal(s){if(s.winner!==null||s.draw)return [];let list=[];for(const u of s.units){if(!u.alive||u.team!==s.turn||s.acted.includes(u.id))continue;
 for(const [dx,dy] of DIRS){if(free(s,u.x+dx,u.y+dy))list.push({type:'move',id:u.id,x:u.x+dx,y:u.y+dy});
  const t=at(s,u.x+dx,u.y+dy);if(t&&shifted(s,t,dx,dy,u.role==='ram'?2:1,u.role==='anchor'))list.push({type:'push',id:u.id,x:t.x,y:t.y});
  if(u.role==='magnet'){for(let d=1;d<=5;d++){const t=at(s,u.x+dx*d,u.y+dy*d);if(t){if(d>=2&&!t.braced)list.push({type:'pull',id:u.id,x:t.x,y:t.y});break;}}}
 }
 if(u.role==='anchor'&&!u.braced)list.push({type:'brace',id:u.id,x:u.x,y:u.y});
 if(u.role==='jumper'){for(const dx of [-1,1])for(const dy of [-1,1])if(free(s,u.x+dx,u.y+dy))list.push({type:'move',id:u.id,x:u.x+dx,y:u.y+dy});
  for(const dx of [-2,0,2])for(const dy of [-2,0,2])if((dx||dy)&&free(s,u.x+dx,u.y+dy))list.push({type:'jump',id:u.id,x:u.x+dx,y:u.y+dy});}
 }
 if(s.acted.length)list.push({type:'end'});
 return list;
}
export const sameAction=(a,b)=>!!a&&!!b&&a.type===b.type&&a.id===b.id&&a.x===b.x&&a.y===b.y;
/** Полный переход: действие + (если ход закончился) события конца хода. */
export function simulate(s,a){let n=copyUnits(s);
 if(a.type!=='end'){const u=n.units.find(u=>u.id===a.id);
  if(a.type==='move'||a.type==='jump'){u.x=a.x;u.y=a.y;u.braced=false;}
  if(a.type==='brace')u.braced=true;
  if(a.type==='push'){const dx=Math.sign(a.x-u.x),dy=Math.sign(a.y-u.y);n=shifted(n,at(n,a.x,a.y),dx,dy,u.role==='ram'?2:1,u.role==='anchor');if(!n)return null;}
  if(a.type==='pull'){let t=at(n,a.x,a.y);const dx=Math.sign(u.x-t.x),dy=Math.sign(u.y-t.y),dist=Math.abs(u.x-t.x)+Math.abs(u.y-t.y);
   // Магнит тянет на 2 клетки (на 1, если между ними одна клетка); провал по пути — падение
   for(let k=0;k<Math.min(2,dist-1);k++){t.x+=dx;t.y+=dy;if(isHole(n,t.x,t.y)){t.alive=false;break;}}}
  n.units.forEach((v,i)=>{const p=s.units[i];if(v.x!==p.x||v.y!==p.y)v.since=s.ply+1;if(v.alive&&isHole(n,v.x,v.y))v.alive=false;});
  n.acted=[...n.acted,a.id];n.left=s.left-1;}
 n.ply=s.ply+1;
 const canAct=n.units.some(u=>u.alive&&u.team===n.turn&&!n.acted.includes(u.id));
 if(a.type==='end'||n.left<=0||!canAct)endTurn(n);
 return n;
}
/**
 * Конец хода:
 * • центр — отмеченная (розовая) клетка проваливается; если все целые клетки центра заняты,
 *   отмечается та, что занята дольше всех (провалится в конце следующего хода);
 * • край — после хода RING_TURN-1 краснеет, после хода RING_TURN обрушивается целиком;
 * • очки центра — +1 той команде, у которой в центре больше роботов;
 * • ход переходит сопернику, его Якоря снимают фиксацию.
 */
function endTurn(n){n.endedTurn=true;
 if(n.cracks?.length){const c=n.cracks[0];n.holes=[...n.holes,c];const v=at(n,...cell(c));if(v)v.alive=false;}
 n.cracks=null;
 {const left=CENTER.filter(c=>!n.holes.includes(c)),occ=left.map(c=>at(n,...cell(c)));
  if(left.length&&occ.every(Boolean)){let first=0;occ.forEach((u,i)=>{if(u.since<occ[first].since)first=i;});n.cracks=[left[first]];}}
 if(n.ring==='warn'){n.holes=[...n.holes,...RING];n.ring='gone';for(const u of n.units)if(u.alive&&RING.includes(u.x+','+u.y))u.alive=false;}
 else if(!n.ring&&n.turnNo+1>=RING_TURN)n.ring='warn';
 const c0=centerCount(n,0),c1=centerCount(n,1);if(c0!==c1)n.score[c0>c1?0:1]++;
 n.turn=1-n.turn;n.turnNo++;n.left=PER_TURN;n.acted=[];
 for(const u of n.units)if(u.team===n.turn)u.braced=false;
}
/** Роботы, выбывшие в результате действия. */
export function knocked(s,a,n=simulate(s,a)){return n?n.units.filter((u,i)=>!u.alive&&s.units[i].alive):[];}
/** Выбитые самим действием (вытолкнуты/притянуты), без тех, кто провалился на месте. */
export function displaced(s,a,n=simulate(s,a)){return knocked(s,a,n).filter(v=>{const b=s.units.find(t=>t.id===v.id);return b.x!==v.x||b.y!==v.y;});}
export function describe(s,a,n=simulate(s,a)){let text=a.type==='end'?'Ход завершён':`${ROLES[s.units.find(u=>u.id===a.id).role].name}: ${ACTIONS[a.type].toLowerCase()}`;
 const out=displaced(s,a,n),sunk=knocked(s,a,n).filter(u=>!out.includes(u));const nm=l=>l.map(u=>ROLES[u.role].name).join(', ');
 if(out.length)text+=` · выбит: ${nm(out)}`;if(sunk.length)text+=` · провалился: ${nm(sunk)}`;
 if(n.cracks&&n.cracks[0]!==s.cracks?.[0])text+=' · клетка центра рушится';
 if(!s.ring&&n.ring)text+=' · края рушатся';if(s.ring==='warn'&&n.ring==='gone')text+=' · края обрушились';
 return text;}
function outcome(n){const eliminated=[0,1].filter(team=>n.units.filter(u=>u.team===team&&u.alive).length<=1);if(eliminated.length===2)n.draw=true;else if(eliminated.length===1)n.winner=1-eliminated[0];}
/** Решение по очкам центра (лимит ходов или повтор позиции). */
function byScore(n){n.byScore=true;if(n.score[0]===n.score[1])n.draw=true;else n.winner=n.score[0]>n.score[1]?0:1;}
/** Быстрый ход без проверки легальности, истории и повторов — для поиска. */
function step(s,a){const n=simulate(s,a);outcome(n);if(n.winner===null&&!n.draw&&n.turnNo>TURN_LIMIT)byScore(n);return n;}
export function apply(s,a){if(!legal(s).some(b=>sameAction(a,b)))return null;const n=simulate(s,a);n.history=s.history.concat([{team:s.turn,text:describe(s,a,n),action:a}]);n.seen={...s.seen};outcome(n);
 if(n.endedTurn&&n.winner===null&&!n.draw){const k=key(n);n.seen[k]=(n.seen[k]||0)+1;if(n.seen[k]>=3||n.turnNo>TURN_LIMIT)byScore(n);}
 delete n.endedTurn;if(n.winner===null&&!n.draw&&!legal(n).length)n.draw=true;return n;}

/**
 * Угрозы: каких роботов команды `team` соперник может выбить за свой ход (до двух действий),
 * вытолкнув или притянув их. Возвращает Map id → первое действие связки.
 */
export function threatsAgainst(s,team){const probe={...s,turn:1-team,left:PER_TURN,acted:[],winner:null,draw:false};const out=new Map();
 const lost=(n,first)=>{for(const u of n.units){const b=probe.units.find(t=>t.id===u.id);if(u.team===team&&b.alive&&!u.alive&&(b.x!==u.x||b.y!==u.y)&&!out.has(u.id))out.set(u.id,[first]);}};
 for(const a of legal(probe)){if(a.type==='end')continue;const n=simulate(probe,a);if(!n)continue;lost(n,a);
  if(n.turn===probe.turn)for(const b of legal(n)){if(b.type!=='push'&&b.type!=='pull')continue;const m=simulate(n,b);if(m)lost(m,a);}}
 return out;}

// ── Бот ─────────────────────────────────────────────
function value(s,team){if(s.winner!==null)return s.winner===team?1e5:-1e5;if(s.draw)return -25;let v=12*(s.score[team]-s.score[1-team]);
 const danger=[...s.holes,...(s.cracks||[]),...(s.ring==='warn'?RING:[])].map(cell);
 for(const u of s.units){if(!u.alive)continue;const sign=u.team===team?1:-1;let edge=Math.min(u.x,u.y,5-u.x,5-u.y);for(const [hx,hy] of danger)edge=Math.min(edge,Math.abs(hx-u.x)+Math.abs(hy-u.y)-1);v+=sign*(100+edge*6+(central(u)&&!s.holes.includes(u.x+','+u.y)?6:0)+(u.braced?3:0));}
 const enemies=s.units.filter(e=>e.alive&&e.team!==team);for(const u of s.units){if(!u.alive||u.team!==team||!enemies.length)continue;let m=99;for(const e of enemies)m=Math.min(m,Math.abs(e.x-u.x)+Math.abs(e.y-u.y));v-=1.5*m;}return v;}
const order=a=>a.type==='push'?0:a.type==='pull'?1:a.type==='end'?4:2;
function search(s,team,depth,alpha,beta){if(depth===0||s.winner!==null||s.draw)return value(s,team);const moves=legal(s).sort((a,b)=>order(a)-order(b));if(!moves.length)return value(s,team);const max=s.turn===team;let best=max?-Infinity:Infinity;for(const a of moves){const v=search(step(s,a),team,depth-1,alpha,beta);if(max){if(v>best)best=v;if(best>alpha)alpha=best;}else{if(v<best)best=v;if(best<beta)beta=best;}if(beta<=alpha)break;}return best;}
export const LEVELS={easy:{name:'Новичок',depth:1,noise:45},normal:{name:'Боец',depth:3,noise:4},hard:{name:'Мастер',depth:4,noise:0}};
/** Выбор одного действия. level: easy | normal | hard. rand — источник случайности для разнообразия партий. */
export function bot(s,level='normal',rand=Math.random){const cfg=LEVELS[level]||LEVELS.normal,team=s.turn;let best=null,score=-Infinity;
 for(const a of legal(s).sort((a,b)=>order(a)-order(b))){const n=step(s,a);let v=cfg.depth>1?search(n,team,cfg.depth-1,score-cfg.noise-1,Infinity)+.08*value(n,team):value(n,team);if(n.winner===null&&!n.draw&&n.turn!==team&&s.seen[key(n)])v-=35;if(cfg.noise)v+=rand()*cfg.noise;if(v>score){score=v;best=a;}}
 return best;}
