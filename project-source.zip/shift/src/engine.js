// СДВИГ — игровая логика. Чистые функции, без DOM.
export const ROLES={
 ram:{name:'Таран',icon:'ram',model:'George',short:'Толкает на 2 клетки',tip:'Толкает соседнего робота и всю цепочку за ним сразу на две клетки. Самый опасный у края.'},
 magnet:{name:'Магнит',icon:'magnet',model:'Leela',short:'Тянет с 2–3 клеток',tip:'Притягивает первого робота на линии с расстояния 2–3 клетки на одну клетку к себе. Через фигуры не тянет.'},
 anchor:{name:'Якорь',icon:'anchor',model:'Mike',short:'Сдвигает закреплённых',tip:'Закрепляется: его нельзя притянуть, и толкнуть может только другой Якорь — цепочку через закреплённого тоже. От провала фиксация не спасает. Любой свой ход снимает фиксацию.'},
 jumper:{name:'Прыгун',icon:'jumper',model:'Stan',short:'Ходит и по диагонали',tip:'Ходит на одну клетку в любую сторону, включая диагонали, или прыгает ровно на две клетки по прямой или диагонали — через любые фигуры.'}
};
export const ACTIONS={move:'Ход',push:'Толчок',pull:'Притянуть',brace:'Закрепиться',jump:'Прыжок'};
export const DIRS=[[1,0],[-1,0],[0,1],[0,-1]];
export const inside=(x,y)=>x>=0&&x<6&&y>=0&&y<6;
export const central=(u)=>u.x>=2&&u.x<=3&&u.y>=2&&u.y<=3;
export const at=(s,x,y)=>s.units.find(u=>u.alive&&u.x===x&&u.y===y);
/** Центр 2×2 по часовой стрелке (как видит голубой игрок). */
export const CENTER=['2,2','3,2','3,3','2,3'];
/** Внешнее кольцо поля (край 6×6). */
export const RING=[];for(let x=0;x<6;x++)for(let y=0;y<6;y++)if(x===0||y===0||x===5||y===5)RING.push(x+','+y);
export const isHole=(s,x,y)=>s.holes.includes(x+','+y);
/** Клетка, которая провалится следующей (трещина), или null. */
export const nextCrack=s=>s.cracks?.[0]??null;
// Копируем только юнитов; история и счётчик повторов копируются в apply().
const copyUnits=s=>({...s,units:s.units.map(u=>({...u}))});
export const clone=s=>({...copyUnits(s),history:s.history.slice(),seen:{...s.seen}});
export function key(s){return JSON.stringify([s.turn,s.holes,s.cracks,s.ring,s.units.map(u=>[u.id,u.x,u.y,u.alive,u.braced])]);}
export function initial(){let units=[];[0,1].forEach(team=>Object.keys(ROLES).forEach((role,i)=>units.push({id:`${team}-${role}`,role,team,x:team?4-i:1+i,y:team?1:4,alive:true,braced:false,since:0})));let s={units,turn:0,ply:0,winner:null,draw:false,holes:[],cracks:null,ring:null,history:[],seen:{}};s.seen[key(s)]=1;return s;}
/** Сдвиг цепочки. heavy — толкает Якорь: только он сдвигает закреплённых. */
function shifted(s,target,dx,dy,steps,heavy=false){const n=copyUnits(s);const id=target.id;for(let i=0;i<steps;i++){let t=n.units.find(u=>u.id===id);if(!t.alive)break;let chain=[],cur=t;while(cur){if(cur.braced&&!heavy)return null;chain.push(cur);cur=at(n,cur.x+dx,cur.y+dy);}for(const v of chain.reverse()){v.x+=dx;v.y+=dy;if(!inside(v.x,v.y)||isHole(n,v.x,v.y))v.alive=false;}}return n;}
export function legal(s){if(s.winner!==null||s.draw)return [];let list=[];for(const u of s.units.filter(u=>u.alive&&u.team===s.turn)){
 for(const [dx,dy] of DIRS){{const x=u.x+dx,y=u.y+dy;if(inside(x,y)&&!at(s,x,y)&&!isHole(s,x,y))list.push({type:'move',id:u.id,x,y});}
 const t=at(s,u.x+dx,u.y+dy);if(t&&shifted(s,t,dx,dy,u.role==='ram'?2:1,u.role==='anchor'))list.push({type:'push',id:u.id,x:t.x,y:t.y});
 if(u.role==='magnet'){for(let d=1;d<=3;d++){const t=at(s,u.x+dx*d,u.y+dy*d);if(t){if(d>=2&&!t.braced)list.push({type:'pull',id:u.id,x:t.x,y:t.y});break;}}}
 }
 if(u.role==='anchor'&&!u.braced)list.push({type:'brace',id:u.id,x:u.x,y:u.y});
 // Прыгун: шаг на 1 по диагонали и прыжок на 2
 if(u.role==='jumper')for(const dx of [-1,1])for(const dy of [-1,1]){const x=u.x+dx,y=u.y+dy;if(inside(x,y)&&!at(s,x,y)&&!isHole(s,x,y))list.push({type:'move',id:u.id,x,y});}
 if(u.role==='jumper')for(const dx of [-2,0,2])for(const dy of [-2,0,2])if((dx||dy)&&inside(u.x+dx,u.y+dy)&&!at(s,u.x+dx,u.y+dy)&&!isHole(s,u.x+dx,u.y+dy))list.push({type:'jump',id:u.id,x:u.x+dx,y:u.y+dy});
 }
 return list;
}
export const sameAction=(a,b)=>!!a&&!!b&&a.type===b.type&&a.id===b.id&&a.x===b.x&&a.y===b.y&&a.dir===b.dir;
export function simulate(s,a){let n=copyUnits(s),u=n.units.find(u=>u.id===a.id);if(a.type==='move'||a.type==='jump'){u.x=a.x;u.y=a.y;u.braced=false;}if(a.type==='brace')u.braced=true;
 if(a.type==='push'){const dx=Math.sign(a.x-u.x),dy=Math.sign(a.y-u.y);n=shifted(n,at(n,a.x,a.y),dx,dy,u.role==='ram'?2:1,u.role==='anchor');if(!n)return null;}
 if(a.type==='pull'){let t=at(n,a.x,a.y);t.x+=Math.sign(u.x-t.x);t.y+=Math.sign(u.y-t.y);}
 return settle(s,n);
}
/**
 * Обрушение центра. Когда заняты все ещё целые клетки центра (сначала 4, потом 3, 2, 1),
 * та из них, что занята дольше всех, помечается (розовая) и после следующего хода проваливается.
 * Кто на ней стоит — выбывает. В провал можно столкнуть или притянуть.
 */
function settle(prev,n){const ply=prev.ply+1;
 n.units.forEach((u,i)=>{const p=prev.units[i];if(u.x!==p.x||u.y!==p.y)u.since=ply;if(u.alive&&isHole(n,u.x,u.y))u.alive=false;});
 n.cracks=null;
 // Внешний край: после первой дыры в центре — предупреждение, через ход обрушивается целиком
 if(prev.ring==='warn'){n.holes=[...n.holes,...RING];n.ring='gone';for(const u of n.units)if(u.alive&&RING.includes(u.x+','+u.y))u.alive=false;}
 if(prev.cracks?.length){const [x,y]=prev.cracks[0].split(',').map(Number);n.holes=[...n.holes,prev.cracks[0]];const v=at(n,x,y);if(v)v.alive=false;if(!n.ring&&CENTER.every(c=>n.holes.includes(c)))n.ring='warn';}
 {const left=CENTER.filter(c=>!n.holes.includes(c)),occ=left.map(c=>at(n,...c.split(',').map(Number)));
  if(left.length&&occ.every(Boolean)){let first=0;occ.forEach((u,i)=>{if(u.since<occ[first].since)first=i;});n.cracks=[left[first]];}}
 return n;}
/** Роботы, которые вылетят за край в результате действия. */
export function knocked(s,a,n=simulate(s,a)){return n?n.units.filter((u,i)=>!u.alive&&s.units[i].alive):[];}
/** Выбитые самим действием (вытолкнуты/притянуты), без тех, кто провалился на месте. */
export function displaced(s,a,n=simulate(s,a)){return knocked(s,a,n).filter(v=>{const b=s.units.find(t=>t.id===v.id);const c=n.units.find(t=>t.id===v.id);return b.x!==c.x||b.y!==c.y;});}
export function describe(s,a,n=simulate(s,a)){let text=`${ROLES[s.units.find(u=>u.id===a.id).role].name}: ${ACTIONS[a.type].toLowerCase()}`;const out=displaced(s,a,n),sunk=knocked(s,a,n).filter(u=>!out.includes(u));const nm=l=>l.map(u=>ROLES[u.role].name).join(', ');if(out.length)text+=` · выбит: ${nm(out)}`;if(sunk.length)text+=` · провалился: ${nm(sunk)}`;if(!s.cracks&&n.cracks)text+=' · клетка центра рушится';if(!s.ring&&n.ring)text+=' · края поля рушатся';if(s.ring==='warn')text+=' · края обрушились';else if(n.holes.length>s.holes.length&&!sunk.length)text+=' · провал в центре';return text;}
function outcome(n){const eliminated=[0,1].filter(team=>n.units.filter(u=>u.team===team&&u.alive).length<=1);if(eliminated.length===2)n.draw=true;else if(eliminated.length===1)n.winner=1-eliminated[0];}
/** Быстрый ход без проверки легальности, истории и повторов — для поиска. */
function step(s,a){const n=simulate(s,a);n.turn=1-s.turn;n.ply=s.ply+1;outcome(n);return n;}
export function apply(s,a){if(!legal(s).some(b=>sameAction(a,b)))return null;const n=simulate(s,a);n.history=s.history.concat([{team:s.turn,text:describe(s,a,n),action:a}]);n.seen={...s.seen};n.ply=s.ply+1;n.turn=1-s.turn;outcome(n);const k=key(n);n.seen[k]=(n.seen[k]||0)+1;if(n.winner===null&&(n.seen[k]>=3||n.ply>=120))n.draw=true;if(n.winner===null&&!n.draw&&!legal(n).length)n.draw=true;return n;}

/**
 * Угрозы: каких роботов команды `team` соперник может выбить одним действием,
 * если ход будет за ним. Возвращает Map id → список действий-угроз.
 */
export function threatsAgainst(s,team){const probe={...s,turn:1-team,winner:null,draw:false};const out=new Map();for(const a of legal(probe)){if(a.type!=='push'&&a.type!=='pull')continue;const n=simulate(probe,a);if(!n)continue;for(const u of displaced(probe,a,n))if(u.team===team){if(!out.has(u.id))out.set(u.id,[]);out.get(u.id).push(a);}}return out;}

// ── Бот ─────────────────────────────────────────────
function value(s,team){if(s.winner!==null)return s.winner===team?1e5:-1e5;if(s.draw)return -25;let v=0;for(const u of s.units){if(!u.alive)continue;const sign=u.team===team?1:-1;let edge=Math.min(u.x,u.y,5-u.x,5-u.y);for(const c of [...s.holes,...(s.cracks||[])]){const [hx,hy]=c.split(',').map(Number);edge=Math.min(edge,Math.abs(hx-u.x)+Math.abs(hy-u.y)-1);}v+=sign*(100+edge*6+(!s.cracks&&central(u)?5:0)+(u.braced?4:0));}const enemies=s.units.filter(e=>e.alive&&e.team!==team);for(const u of s.units){if(!u.alive||u.team!==team||!enemies.length)continue;let m=99;for(const e of enemies)m=Math.min(m,Math.abs(e.x-u.x)+Math.abs(e.y-u.y));v-=1.5*m;}return v;}
const order=a=>a.type==='push'?0:a.type==='pull'?1:2;
function search(s,team,depth,alpha,beta){if(depth===0||s.winner!==null||s.draw)return value(s,team);const moves=legal(s).sort((a,b)=>order(a)-order(b));if(!moves.length)return value(s,team);const max=s.turn===team;let best=max?-Infinity:Infinity;for(const a of moves){const v=search(step(s,a),team,depth-1,alpha,beta);if(max){if(v>best)best=v;if(best>alpha)alpha=best;}else{if(v<best)best=v;if(best<beta)beta=best;}if(beta<=alpha)break;}return best;}
export const LEVELS={easy:{name:'Новичок',depth:1,noise:45},normal:{name:'Боец',depth:2,noise:4},hard:{name:'Мастер',depth:3,noise:0}};
/** Выбор хода. level: easy | normal | hard. rand — источник случайности для разнообразия партий. */
export function bot(s,level='normal',rand=Math.random){const cfg=LEVELS[level]||LEVELS.normal,team=s.turn;let best=null,score=-Infinity;for(const a of legal(s).sort((a,b)=>order(a)-order(b))){const n=step(s,a);let v=cfg.depth>1?search(n,team,cfg.depth-1,-Infinity,Infinity)+.08*value(n,team):value(n,team);if(n.winner===null&&!n.draw&&s.seen[key(n)])v-=35;if(cfg.noise)v+=rand()*cfg.noise;if(v>score){score=v;best=a;}}return best;}
