import * as T from 'three';
import {GLTFLoader} from 'three/addons/loaders/GLTFLoader.js';
import{clone as skeletonClone}from'three/addons/utils/SkeletonUtils.js';
import{ROLES,central}from'./engine.js';
import{badgeCanvas}from'./icons.js';

// Свои — голубые, соперник — розовый (с точки зрения того, кто смотрит на экран).
export const ME_HEX='#5ec8ff',FOE_HEX='#ff7ac0';
const ME=0x5ec8ff,FOE=0xff7ac0;
// Цвета меток действий — те же, что в легенде интерфейса (style.css).
export const MARK={move:0xb7f3b0,jump:0x5fe8d0,push:0xffc46b,pull:0xc79bff,brace:0xffe27a,kill:0xff5a4e};
const STEP=1.28,TILE=1.19;
const HEIGHT={ram:1.08,anchor:1.0,magnet:.95,jumper:.86};
const world=(x,y)=>new T.Vector3((x-2.5)*STEP,.08,(y-2.5)*STEP);

export class Arena{
 constructor(el,onPick){
  this.el=el;this.onPick=onPick;this.units=new Map();this.tiles=[];this.mixers=[];this.markers=[];this.hover=null;this.view={team:0,overhead:false};this.me=0;this.badgeCache=new Map();
  const r=this.renderer=new T.WebGLRenderer({antialias:true,alpha:true,powerPreference:'high-performance'});
  r.setPixelRatio(Math.min(devicePixelRatio,2));r.shadowMap.enabled=true;r.shadowMap.type=T.PCFShadowMap;r.outputColorSpace=T.SRGBColorSpace;r.toneMapping=T.ACESFilmicToneMapping;r.toneMappingExposure=1.15;el.prepend(r.domElement);
  this.scene=new T.Scene();this.scene.fog=new T.Fog(0x0f1a1f,24,50);
  this.camera=new T.PerspectiveCamera(30,1,.1,120);this.timer=new T.Timer();
  this.ray=new T.Raycaster();this.mouse=new T.Vector2();
  this.previewGroup=new T.Group();this.markerGroup=new T.Group();this.scene.add(this.previewGroup,this.markerGroup);
  this.scene.add(new T.HemisphereLight(0xdbeeff,0x3a4a44,2.1));
  const key=new T.DirectionalLight(0xfff1dc,3.2);key.position.set(-4,14,7);key.castShadow=true;key.shadow.mapSize.set(2048,2048);Object.assign(key.shadow.camera,{left:-6,right:6,top:6,bottom:-6,near:1,far:32});key.shadow.bias=-.0006;key.shadow.normalBias=.02;this.scene.add(key);
  const rim=new T.DirectionalLight(0x8fe6ff,1.4);rim.position.set(6,6,-8);this.scene.add(rim);
  this.buildBoard();
  new ResizeObserver(()=>this.resize()).observe(el);this.resize();
  const cv=r.domElement;
  cv.addEventListener('pointermove',e=>{if(e.pointerType==='mouse')this.setHover(this.cellAt(e));});
  cv.addEventListener('pointerleave',()=>this.setHover(null));
  cv.addEventListener('pointerdown',e=>{this.down={x:e.clientX,y:e.clientY};});
  cv.addEventListener('pointerup',e=>{if(this.anim)return;if(this.down&&Math.hypot(e.clientX-this.down.x,e.clientY-this.down.y)>12)return;const c=this.cellAt(e);if(c)onPick(c.x,c.y);});
  r.setAnimationLoop(t=>this.frame(t));
 }
 /** Клетка под курсором: сначала робот (по нему проще попасть), потом плитка. */
 cellAt(e){const b=this.el.getBoundingClientRect();this.mouse.set((e.clientX-b.left)/b.width*2-1,-(e.clientY-b.top)/b.height*2+1);this.ray.setFromCamera(this.mouse,this.camera);
  // Плитка под курсором. Если это подсвеченная цель — она важнее робота, который её загораживает.
  const h=this.ray.intersectObjects(this.tiles,false);const tile=h.length?{x:h[0].object.userData.x,y:h[0].object.userData.y}:null;
  if(tile&&this.markers.some(g=>g.userData.x===tile.x&&g.userData.y===tile.y))return tile;
  const hits=this.ray.intersectObjects([...this.units.values()].filter(o=>o.root.visible).map(o=>o.hit),false);
  if(hits.length){const u=this.state?.units.find(u=>u.id===hits[0].object.userData.id);if(u?.alive)return{x:u.x,y:u.y};}
  return tile;}
 box(w,h,d,color,x,y,z,parent=this.scene,opts={}){const m=new T.Mesh(new T.BoxGeometry(w,h,d),new T.MeshStandardMaterial({color,roughness:.78,metalness:.18,...opts}));m.position.set(x,y,z);m.receiveShadow=true;parent.add(m);return m;}
 buildBoard(){
  this.center=new T.Group();this.scene.add(this.center);
  this.box(8.3,.5,8.3,0x1d2e33,0,-.43,0);
  this.box(7.95,.12,7.95,0x0b161b,0,-.13,0);
  // Периметр — «обрыв» (красная линия), домашние стороны команд — цветные полосы на торцах
  const half=3*STEP+.06,glow=(c,i=.9)=>({emissive:c,emissiveIntensity:i,roughness:.4});
  for(const s of [-1,1]){this.box(2*half+.08,.05,.05,0xff6a55,0,-.05,s*half,this.scene,glow(0xff4a3a,.55));this.box(.05,.05,2*half+.08,0xff6a55,s*half,-.05,0,this.scene,glow(0xff4a3a,.55));}
  this.strips=[this.box(6.2,.16,.06,ME,0,-.43,4.16,this.scene,glow(ME,1.1)),this.box(6.2,.16,.06,FOE,0,-.43,-4.16,this.scene,glow(FOE,1.1))];
  for(let x=0;x<6;x++)for(let y=0;y<6;y++){const c=central({x,y});const p=world(x,y);const color=c?((x+y)%2?0x55776c:0x5f8377):((x+y)%2?0x2a3f45:0x334b51);
   const tile=this.box(TILE,.16,TILE,color,p.x,0,p.z,c?this.center:this.scene);tile.userData={x,y};this.tiles.push(tile);}
  // Рамка поворотной платформы (вращается вместе с центром)
  const e=STEP+.015,f=glow(0xb7f3b0,.8);
  for(const s of [-1,1]){this.box(2*e+.07,.035,.07,0xb7f3b0,0,.1,s*e,this.center,f);this.box(.07,.035,2*e+.07,0xb7f3b0,s*e,.1,0,this.center,f);}
  for(const x of [-3.75,3.75])for(const z of [-3.75,3.75])this.box(.55,2.2,.55,0x16252a,x,-1.75,z);
  const floor=new T.Mesh(new T.CircleGeometry(40,48),new T.MeshStandardMaterial({color:0x111d22,roughness:1}));floor.rotation.x=-Math.PI/2;floor.position.y=-2.85;floor.receiveShadow=true;this.scene.add(floor);
 }
 async load(state,onProgress){const loader=new GLTFLoader();let count=0;const models={};
  await Promise.all(Object.entries(ROLES).map(async([role,r])=>{models[role]=await loader.loadAsync(`${import.meta.env.BASE_URL}models/${r.model}.glb`);onProgress(++count);}));
  for(const u of state.units){const gltf=models[u.role],model=skeletonClone(gltf.scene);const mats=[];
   const b=new T.Box3().setFromObject(model),size=b.getSize(new T.Vector3()),c=b.getCenter(new T.Vector3());const factor=HEIGHT[u.role]/size.y;model.scale.setScalar(factor);model.position.set(-c.x*factor,-b.min.y*factor,-c.z*factor);
   // Корпус окрашен в цвет команды, текстура сохраняется
   model.traverse(o=>{if(!o.isMesh)return;o.castShadow=true;o.receiveShadow=true;const list=(Array.isArray(o.material)?o.material:[o.material]).map(m=>{m=m.clone();mats.push(m);return m;});o.material=list.length===1?list[0]:list;});
   const root=new T.Group(),facing=new T.Group();facing.add(model);root.add(facing);
   const disc=new T.Mesh(new T.CylinderGeometry(.44,.47,.05,40),new T.MeshStandardMaterial({color:0x14232a,roughness:.5}));disc.position.y=.025;disc.receiveShadow=true;root.add(disc);
   const halo=new T.Mesh(new T.RingGeometry(.4,.48,48),new T.MeshBasicMaterial({color:ME,side:T.DoubleSide}));halo.rotation.x=-Math.PI/2;halo.position.y=.055;root.add(halo);
   const ringMat=c=>new T.MeshBasicMaterial({color:c,side:T.DoubleSide,transparent:true,depthWrite:false});
   const selection=new T.Mesh(new T.RingGeometry(.53,.6,48),ringMat(0xffffff));selection.rotation.x=-Math.PI/2;selection.position.y=.06;selection.visible=false;root.add(selection);
   const danger=new T.Mesh(new T.RingGeometry(.48,.68,48),ringMat(MARK.kill));danger.rotation.x=-Math.PI/2;danger.position.y=.065;danger.visible=false;root.add(danger);
   const braces=new T.Group();for(const dx of [-1,1])for(const dz of [-1,1])this.box(.13,.18,.13,0xffe27a,dx*.37,.09,dz*.37,braces,{emissive:0xffcc33,emissiveIntensity:.6});braces.visible=false;root.add(braces);
   // Значок роли над головой — читается с любого ракурса
   const badge=new T.Sprite(new T.SpriteMaterial({depthTest:false,transparent:true}));badge.renderOrder=10;badge.scale.setScalar(.3);badge.position.y=HEIGHT[u.role]+.22;root.add(badge);
   // Невидимый цилиндр — крупная зона попадания по роботу
   const hit=new T.Mesh(new T.CylinderGeometry(.4,.4,HEIGHT[u.role]+.35,12),new T.MeshBasicMaterial({visible:false}));hit.position.y=(HEIGHT[u.role]+.35)/2;hit.userData.id=u.id;root.add(hit);
   const mixer=new T.AnimationMixer(model);this.mixers.push(mixer);const actions={};for(const clip of gltf.animations)actions[clip.name]=mixer.clipAction(clip);actions.Idle?.play();if(actions.Idle)actions.Idle.time=Math.random()*actions.Idle.getClip().duration;
   this.scene.add(root);this.units.set(u.id,{root,facing,selection,danger,braces,badge,halo,mats,hit,mixer,actions,current:'Idle',team:u.team,role:u.role});}
  this.applyColors();this.setState(state);}
 /** Значок роли: кэш текстур по имени и цвету. */
 badgeTex(name,fill,ring){const k=name+fill+(ring||'');if(!this.badgeCache.has(k)){const cv=badgeCanvas(name,fill,'#0b171c',ring);const tex=new T.CanvasTexture(cv);tex.colorSpace=T.SRGBColorSpace;cv.onupdate=()=>{tex.needsUpdate=true;};this.badgeCache.set(k,tex);}return this.badgeCache.get(k);}
 /** Чья сторона «своя»: её роботы голубые, соперника — розовые. */
 setMe(team){if(this.me===team)return;this.me=team;this.applyColors();if(this.state)this.setState(this.state);}
 applyColors(){if(this.strips)this.strips.forEach((b,t)=>{const c=t===this.me?ME:FOE;b.material.color.set(c);b.material.emissive.set(c);});for(const o of this.units.values()){const mine=o.team===this.me,tint=new T.Color(mine?ME:FOE);
   for(const m of o.mats){m.color=new T.Color(1,1,1).lerp(tint,mine?.78:.6);if(m.emissive)m.emissive=tint.clone().multiplyScalar(mine?.2:.12);}
   o.halo.material.color.set(mine?ME:FOE);o.tex={normal:this.badgeTex(ROLES[o.role].icon,mine?ME_HEX:FOE_HEX),braced:o.role==='anchor'?this.badgeTex('lock',mine?ME_HEX:FOE_HEX,'#ffe27a'):null};o.badge.material.map=o.tex.normal;o.badge.material.needsUpdate=true;}}
 pose(o,name){if(o.current===name||!o.actions[name])return;o.actions[o.current]?.fadeOut(.12);o.actions[name].reset().fadeIn(.12).play();o.current=name;}
 setState(s){this.state=s;for(const u of s.units){const o=this.units.get(u.id);if(!o)continue;o.root.visible=u.alive;o.root.position.copy(world(u.x,u.y));o.root.rotation.set(0,0,0);o.facing.rotation.y=u.team?0:Math.PI;o.braces.visible=u.braced;if(o.tex.braced)o.badge.material.map=u.braced?o.tex.braced:o.tex.normal;this.pose(o,'Idle');}}
 /** Метки целей для выбранного робота. actions: [{type,x,y,id,kill}] */
 highlight(id,actions=[]){for(const [k,o]of this.units)o.selection.visible=k===id;this.clearMarkers();
  const sel=id&&this.state?.units.find(u=>u.id===id);
  for(const a of actions){if(a.type==='rotate'||!sel)continue;const g=new T.Group(),p=world(a.x,a.y);g.position.set(p.x,.1,p.z);g.userData={x:a.x,y:a.y};const color=a.kill?MARK.kill:MARK[a.type];
   const tile=new T.Mesh(new T.PlaneGeometry(TILE-.06,TILE-.06),new T.MeshBasicMaterial({color,transparent:true,opacity:.16,depthWrite:false}));tile.rotation.x=-Math.PI/2;g.add(tile);
   if(a.type==='move'){const d=new T.Mesh(new T.CircleGeometry(.16,32),new T.MeshBasicMaterial({color}));d.rotation.x=-Math.PI/2;d.position.y=.01;g.add(d);}
   if(a.type==='jump'){const d=new T.Mesh(new T.RingGeometry(.15,.25,32),new T.MeshBasicMaterial({color,side:T.DoubleSide}));d.rotation.x=-Math.PI/2;d.position.y=.01;g.add(d);}
   if(a.type==='brace'){const fr=new T.Mesh(new T.RingGeometry(.6,.68,4,1),new T.MeshBasicMaterial({color,side:T.DoubleSide}));fr.rotation.set(-Math.PI/2,0,Math.PI/4);fr.position.y=.012;g.add(fr);}
   if(a.type==='push'||a.type==='pull'){const ring=new T.Mesh(new T.RingGeometry(.52,.6,48),new T.MeshBasicMaterial({color,side:T.DoubleSide}));ring.rotation.x=-Math.PI/2;ring.position.y=.012;g.add(ring);
    let dx=Math.sign(a.x-sel.x),dz=Math.sign(a.y-sel.y);if(a.type==='pull'){dx=-dx;dz=-dz;}
    const shape=new T.Shape();shape.moveTo(0,.2);shape.lineTo(.2,-.04);shape.lineTo(.09,-.04);shape.lineTo(0,.07);shape.lineTo(-.09,-.04);shape.lineTo(-.2,-.04);shape.closePath();
    const ch=new T.Mesh(new T.ShapeGeometry(shape),new T.MeshBasicMaterial({color,side:T.DoubleSide}));ch.geometry.rotateX(-Math.PI/2);ch.position.set(0,.015,-.6);const arm=new T.Group();arm.add(ch);arm.rotation.y=Math.atan2(-dx,-dz);g.add(arm);}
   this.markerGroup.add(g);this.markers.push(g);}
  this.applyHover();}
 clearMarkers(){for(const g of this.markers){this.markerGroup.remove(g);g.traverse(n=>{n.geometry?.dispose();n.material?.dispose?.();});}this.markers=[];}
 setHover(c){const k=c?`${c.x},${c.y}`:null;if(k===this.hoverKey)return;this.hoverKey=k;this.hover=c;this.applyHover();}
 applyHover(){const c=this.hover;let point=false;for(const g of this.markers){const on=!!c&&g.userData.x===c.x&&g.userData.y===c.y;g.scale.setScalar(on?1.1:1);g.children[0].material.opacity=on?.4:.16;point||=on;}
  if(c&&!point){const u=this.state?.units.find(u=>u.alive&&u.x===c.x&&u.y===c.y);point=!!u&&!!this.selectable?.(u);}
  this.renderer.domElement.style.cursor=point?'pointer':'default';}
 setThreats(ids){const set=new Set(ids);for(const [k,o]of this.units)o.danger.visible=set.has(k);}
 clearPreview(){while(this.previewGroup.children.length){const o=this.previewGroup.children[0];this.previewGroup.remove(o);o.traverse(n=>{n.geometry?.dispose();n.material?.dispose?.();});}}
 preview(before,after){this.clearPreview();for(const u of after.units){const prev=before.units.find(t=>t.id===u.id);if(!prev.alive||(prev.x===u.x&&prev.y===u.y))continue;
   const from=world(prev.x,prev.y),to=world(u.x,u.y);from.y=to.y=.32;const delta=to.clone().sub(from);const col=u.alive?0xe9fff0:MARK.kill;
   this.previewGroup.add(new T.ArrowHelper(delta.clone().normalize(),from,delta.length(),col,.26,.18));
   const ghost=new T.Mesh(new T.CylinderGeometry(.42,.42,.06,32),new T.MeshBasicMaterial({color:u.alive?(u.team===this.me?ME:FOE):MARK.kill,transparent:true,opacity:.45,depthWrite:false}));ghost.position.copy(to);ghost.position.y=.13;this.previewGroup.add(ghost);
   if(!u.alive){const s=new T.Shape(),k=.07,l=.3;[[-k,-l],[k,-l],[k,-k],[l,-k],[l,k],[k,k],[k,l],[-k,l],[-k,k],[-l,k],[-l,-k],[-k,-k]].forEach(([x,y],i)=>i?s.lineTo(x,y):s.moveTo(x,y));s.closePath();const x=new T.Mesh(new T.ShapeGeometry(s),new T.MeshBasicMaterial({color:MARK.kill,side:T.DoubleSide}));x.geometry.rotateX(-Math.PI/2);x.rotation.y=Math.PI/4;x.position.copy(to);x.position.y=.2;this.previewGroup.add(x);}}}
 async animate(before,after,a){this.clearPreview();this.highlight(null);this.setThreats([]);
  for(const u of after.units){let old=before.units.find(t=>t.id===u.id),o=this.units.get(u.id);if(!o)continue;if(old.x!==u.x||old.y!==u.y){const dx=u.x-old.x,dz=u.y-old.y;o.facing.rotation.y=Math.atan2(dx,dz);this.pose(o,a.type==='jump'&&u.id===a.id?'Jump':a.type==='move'?'Walk':'HitRecieve_1');}if(u.id===a.id&&(a.type==='push'||a.type==='pull')){o.facing.rotation.y=Math.atan2(a.x-old.x,a.y-old.y);this.pose(o,'Punch');}}
  return new Promise(resolve=>this.anim={before,after,a,start:performance.now(),duration:a.type==='rotate'?850:720,resolve});}
 /** Камера всегда смотрит со стороны своей команды: наклонный вид или сверху. */
 setView(v){Object.assign(this.view,v);this.resize();}
 toggleCamera(){this.setView({overhead:!this.view.overhead});return this.view.overhead;}
 resize(){const w=this.el.clientWidth,h=this.el.clientHeight;if(!w||!h)return;this.renderer.setSize(w,h,false);const cam=this.camera;cam.aspect=w/h;
  const portrait=cam.aspect<1.05,el=this.view.overhead?Math.PI/2-.001:(portrait?60:52)*Math.PI/180,tv=Math.tan(cam.fov*Math.PI/360);
  const halfW=portrait?4.3:4.55,halfH=4.25*Math.sin(el)+.8*Math.cos(el)+(this.view.overhead||portrait?.15:.75);const d=Math.max(halfW/(tv*cam.aspect),halfH/tv);
  const side=this.view.team?-1:1;cam.up.set(0,1,0);if(this.view.overhead)cam.up.set(0,0,-side);cam.position.set(0,d*Math.sin(el),side*d*Math.cos(el));cam.lookAt(0,this.view.overhead?0:.2,this.view.overhead?0:side*(portrait?.25:1.05));cam.updateProjectionMatrix();}
 frame(time){if(document.hidden)return;this.timer.update(time);const dt=Math.min(this.timer.getDelta(),.05);this.mixers.forEach(m=>m.update(dt));
  const pulse=.7+.3*Math.sin(performance.now()/170);for(const o of this.units.values())if(o.danger.visible)o.danger.material.opacity=pulse;
  if(this.anim){const{before,after,a,start,duration,resolve}=this.anim;const t=Math.min(1,(performance.now()-start)/duration),e=t*t*(3-2*t);if(a.type==='rotate')this.center.rotation.y=-a.dir*Math.PI/2*e;
   for(const u of after.units){const old=before.units.find(t=>t.id===u.id),o=this.units.get(u.id);if(!o||!old.alive)continue;const from=world(old.x,old.y),to=world(u.x,u.y);
    if(a.type==='rotate'&&central(old)){const angle=-a.dir*Math.PI/2*e;const x=from.x,z=from.z;from.x=x*Math.cos(angle)+z*Math.sin(angle);from.z=-x*Math.sin(angle)+z*Math.cos(angle);o.root.position.copy(from);}
    else{o.root.position.lerpVectors(from,to,e);if(a.type==='jump'&&a.id===u.id)o.root.position.y+=Math.sin(t*Math.PI)*.9;if(!u.alive&&t>.45){o.root.position.y-=Math.pow((t-.45)/.55,2)*4;o.root.rotation.z=(u.x>2.5?1:-1)*t*1.7;}}}
   if(t===1){this.center.rotation.y=0;this.anim=null;this.setState(after);resolve();}}
  this.renderer.render(this.scene,this.camera);}
}
