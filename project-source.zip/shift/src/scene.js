import * as T from 'three';
import {GLTFLoader} from 'three/addons/loaders/GLTFLoader.js';
import{clone as skeletonClone}from'three/addons/utils/SkeletonUtils.js';
import{ROLES,central,isHole}from'./engine.js';
import{badgeCanvas}from'./icons.js';

// Свои — голубые, соперник — розовый (с точки зрения того, кто смотрит на экран).
export const ME_HEX='#5ec8ff',FOE_HEX='#ff7ac0';
const ME=0x5ec8ff,FOE=0xff7ac0;
// Цвета меток действий — те же, что в легенде интерфейса (style.css).
export const MARK={move:0xb7f3b0,jump:0x5fe8d0,push:0xffc46b,pull:0xc79bff,brace:0xffe27a,kill:0xff5a4e};
const STEP=1.28,TILE=1.19;
const HEIGHT={ram:1.08,anchor:1.0,magnet:.95,jumper:.86};
const inside6=(x,y)=>x>=0&&x<6&&y>=0&&y<6;
const world=(x,y)=>new T.Vector3((x-2.5)*STEP,.08,(y-2.5)*STEP);

/** Верх корпуса: 97-й перцентиль высот вершин в текущей позе — антенны и тонкие выступы не учитываются. */
function bodyTop(model){const ys=[],v=new T.Vector3();model.traverse(o=>{if(!o.isMesh)return;const pos=o.geometry.attributes.position;const step=Math.max(1,Math.floor(pos.count/1500));for(let i=0;i<pos.count;i+=step){o.getVertexPosition(i,v);v.applyMatrix4(o.matrixWorld);ys.push(v.y);}});ys.sort((a,b)=>a-b);return ys[Math.floor(ys.length*.97)]??0;}

export class Arena{
 constructor(el,onPick){
  this.el=el;this.onPick=onPick;this.units=new Map();this.tiles=[];this.mixers=[];this.markers=[];this.hover=null;this.view={team:0,overhead:false};this.me=0;this.badgeCache=new Map();
  const r=this.renderer=new T.WebGLRenderer({antialias:true,alpha:true,powerPreference:'high-performance'});
  r.setPixelRatio(Math.min(devicePixelRatio,2));r.shadowMap.enabled=true;r.shadowMap.type=T.PCFShadowMap;r.outputColorSpace=T.SRGBColorSpace;r.toneMapping=T.ACESFilmicToneMapping;r.toneMappingExposure=1.15;el.prepend(r.domElement);
  this.scene=new T.Scene();this.scene.fog=new T.Fog(0x0f1a1f,24,50);
  this.camera=new T.PerspectiveCamera(30,1,.1,120);this.timer=new T.Timer();
  this.ray=new T.Raycaster();this.mouse=new T.Vector2();
  this.previewGroup=new T.Group();this.markerGroup=new T.Group();this.scene.add(this.previewGroup,this.markerGroup);
  this.scene.add(new T.HemisphereLight(0xdbeeff,0x3a4a44,2.1));
  const key=new T.DirectionalLight(0xfff1dc,3.2);key.position.set(-4,14,7);key.castShadow=true;key.shadow.mapSize.set(2048,2048);Object.assign(key.shadow.camera,{left:-6,right:6,top:6,bottom:-6,near:1,far:32});key.shadow.bias=-.0006;key.shadow.normalBias=.02;this.scene.add(key);
  const rim=new T.DirectionalLight(0x8fe6ff,1.4);rim.position.set(6,6,-8);this.scene.add(rim);
  this.buildBoard();
  new ResizeObserver(()=>this.resize()).observe(el);this.resize();
  const cv=r.domElement;
  cv.addEventListener('pointermove',e=>{if(e.pointerType==='mouse')this.setHover(this.cellAt(e));});
  cv.addEventListener('pointerleave',()=>this.setHover(null));
  cv.addEventListener('pointerdown',e=>{this.down={x:e.clientX,y:e.clientY};});
  cv.addEventListener('pointerup',e=>{if(this.anim)return;if(this.down&&Math.hypot(e.clientX-this.down.x,e.clientY-this.down.y)>12)return;const c=this.cellAt(e);if(c)onPick(c.x,c.y);});
  r.setAnimationLoop(t=>this.frame(t));
 }
 /** Клетка под курсором: сначала робот (по нему проще попасть), потом плитка. */
 cellAt(e){const b=this.el.getBoundingClientRect();this.mouse.set((e.clientX-b.left)/b.width*2-1,-(e.clientY-b.top)/b.height*2+1);this.ray.setFromCamera(this.mouse,this.camera);
  // Плитка под курсором. Если это подсвеченная цель — она важнее робота, который её загораживает.
  const h=this.ray.intersectObjects(this.tiles,false);const tile=h.length?{x:h[0].object.userData.x,y:h[0].object.userData.y}:null;
  if(tile&&this.markers.some(g=>g.userData.x===tile.x&&g.userData.y===tile.y))return tile;
  const hits=this.ray.intersectObjects([...this.units.values()].filter(o=>o.root.visible).map(o=>o.hit),false);
  if(hits.length){const u=this.state?.units.find(u=>u.id===hits[0].object.userData.id);if(u?.alive)return{x:u.x,y:u.y};}
  return tile;}
 box(w,h,d,color,x,y,z,parent=this.scene,opts={}){const m=new T.Mesh(new T.BoxGeometry(w,h,d),new T.MeshStandardMaterial({color,roughness:.78,metalness:.18,...opts}));m.position.set(x,y,z);m.receiveShadow=true;parent.add(m);return m;}
 buildBoard(){
  this.center=new T.Group();this.scene.add(this.center);
  this.box(8.3,.5,8.3,0x1d2e33,0,-.43,0);
  this.box(7.95,.12,7.95,0x0b161b,0,-.13,0);
  // Периметр — «обрыв» (красная линия), домашние стороны команд — цветные полосы на торцах
  const half=3*STEP+.06,glow=(c,i=.9)=>({emissive:c,emissiveIntensity:i,roughness:.4});
  for(const s of [-1,1]){this.box(2*half+.08,.05,.05,0xff6a55,0,-.05,s*half,this.scene,glow(0xff4a3a,.55));this.box(.05,.05,2*half+.08,0xff6a55,s*half,-.05,0,this.scene,glow(0xff4a3a,.55));}
  this.strips=[this.box(6.2,.16,.06,ME,0,-.43,4.16,this.scene,glow(ME,1.1)),this.box(6.2,.16,.06,FOE,0,-.43,-4.16,this.scene,glow(FOE,1.1))];
  for(let x=0;x<6;x++)for(let y=0;y<6;y++){const c=central({x,y});const p=world(x,y);const color=c?((x+y)%2?0x55776c:0x5f8377):((x+y)%2?0x2a3f45:0x334b51);
   const tile=this.box(TILE,.16,TILE,color,p.x,0,p.z,c?this.center:this.scene);tile.userData={x,y,color};this.tiles.push(tile);}
  // Рамка центра 2×2 — зоны обрушения
  const e=STEP+.015,f=glow(0xb7f3b0,.8);
  for(const s of [-1,1]){this.box(2*e+.07,.035,.07,0xb7f3b0,0,.1,s*e,this.center,f);this.box(.07,.035,2*e+.07,0xb7f3b0,s*e,.1,0,this.center,f);}
  // Провалы и трещины центра
  this.pits=new Map();
  for(const tile of this.tiles){const {x,y}=tile.userData;if(!central({x,y}))continue;const p=world(x,y);
   const pit=new T.Mesh(new T.BoxGeometry(TILE,.02,TILE),new T.MeshBasicMaterial({color:0x020507}));pit.position.set(p.x,-.17,p.z);pit.visible=false;this.scene.add(pit);
   const rim=new T.Mesh(new T.RingGeometry(.5,.6,4,1),new T.MeshBasicMaterial({color:0xff6a55,side:T.DoubleSide,transparent:true,opacity:.7,depthWrite:false}));rim.rotation.set(-Math.PI/2,0,Math.PI/4);rim.position.set(p.x,-.05,p.z);rim.scale.setScalar(1.18);rim.visible=false;this.scene.add(rim);
   const crack=new T.Group();crack.position.set(p.x,.085,p.z);crack.visible=false;
   const cm=new T.MeshBasicMaterial({color:0xff5a4e,transparent:true,depthWrite:false});
   for(const [ax,az,bx,bz] of [[-.5,-.3,-.1,0],[-.1,0,.15,-.4],[-.1,0,.25,.15],[.25,.15,.5,.05],[.25,.15,.1,.5],[-.1,0,-.35,.45]]){const dx=bx-ax,dz=bz-az,len=Math.hypot(dx,dz);const seg=new T.Mesh(new T.PlaneGeometry(len,.045),cm);seg.rotation.x=-Math.PI/2;seg.rotation.z=-Math.atan2(dz,dx);seg.position.set((ax+bx)/2,0,(az+bz)/2);crack.add(seg);}
   const frame=new T.Mesh(new T.RingGeometry(.78,.84,4,1),cm);frame.rotation.set(-Math.PI/2,0,Math.PI/4);crack.add(frame);
   this.scene.add(crack);this.pits.set(x+','+y,{tile,pit,rim,crack,mat:cm});}
  for(const x of [-3.75,3.75])for(const z of [-3.75,3.75])this.box(.55,2.2,.55,0x16252a,x,-1.75,z);
  const floor=new T.Mesh(new T.CircleGeometry(40,48),new T.MeshStandardMaterial({color:0x111d22,roughness:1}));floor.rotation.x=-Math.PI/2;floor.position.y=-2.85;floor.receiveShadow=true;this.scene.add(floor);
 }
 async load(state,onProgress){const loader=new GLTFLoader();let count=0;const models={};
  await Promise.all(Object.entries(ROLES).map(async([role,r])=>{models[role]=await loader.loadAsync(`${import.meta.env.BASE_URL}models/${r.model}.glb`);onProgress(++count);}));
  for(const u of state.units){const gltf=models[u.role],model=skeletonClone(gltf.scene);const mats=[];
   const b=new T.Box3().setFromObject(model),size=b.getSize(new T.Vector3()),c=b.getCenter(new T.Vector3());const factor=HEIGHT[u.role]/size.y;model.scale.setScalar(factor);model.position.set(-c.x*factor,-b.min.y*factor,-c.z*factor);
   // Корпус окрашен в цвет команды, текстура сохраняется
   model.traverse(o=>{if(!o.isMesh)return;o.castShadow=true;o.receiveShadow=true;const list=(Array.isArray(o.material)?o.material:[o.material]).map(m=>{m=m.clone();mats.push(m);return m;});o.material=list.length===1?list[0]:list;});
   const root=new T.Group(),facing=new T.Group();facing.add(model);root.add(facing);
   const disc=new T.Mesh(new T.CylinderGeometry(.44,.47,.05,40),new T.MeshStandardMaterial({color:0x14232a,roughness:.5}));disc.position.y=.025;disc.receiveShadow=true;disc.visible=false;root.add(disc);
   const halo=new T.Mesh(new T.RingGeometry(.425,.46,64),new T.MeshBasicMaterial({color:ME,side:T.DoubleSide}));halo.rotation.x=-Math.PI/2;halo.position.y=.055;halo.visible=false;root.add(halo);
   const ringMat=c=>new T.MeshBasicMaterial({color:c,side:T.DoubleSide,transparent:true,depthWrite:false});
   const selection=new T.Mesh(new T.RingGeometry(.535,.565,64),ringMat(0xffffff));selection.rotation.x=-Math.PI/2;selection.position.y=.06;selection.visible=false;root.add(selection);
   const danger=new T.Mesh(new T.RingGeometry(.5,.58,64),ringMat(MARK.kill));danger.rotation.x=-Math.PI/2;danger.position.y=.065;danger.visible=false;root.add(danger);
   const braces=new T.Group();for(const dx of [-1,1])for(const dz of [-1,1])this.box(.13,.18,.13,0xffe27a,dx*.37,.09,dz*.37,braces,{emissive:0xffcc33,emissiveIntensity:.6});braces.visible=false;root.add(braces);
   // Значок роли над головой — читается с любого ракурса
   const badge=new T.Sprite(new T.SpriteMaterial({depthTest:false,transparent:true}));badge.renderOrder=10;badge.scale.setScalar(.3);badge.position.y=HEIGHT[u.role]+.22;root.add(badge);
   // Невидимый цилиндр — крупная зона попадания по роботу
   const hit=new T.Mesh(new T.CylinderGeometry(.4,.4,HEIGHT[u.role]+.35,12),new T.MeshBasicMaterial({visible:false}));hit.position.y=(HEIGHT[u.role]+.35)/2;hit.userData.id=u.id;root.add(hit);
   const mixer=new T.AnimationMixer(model);this.mixers.push(mixer);const actions={};for(const clip of gltf.animations)actions[clip.name]=mixer.clipAction(clip);actions.Idle?.play();
   // Значок ставим по реальной макушке робота в стойке Idle (а не по габаритам модели в исходной позе)
   mixer.update(0);root.updateMatrixWorld(true);badge.position.y=bodyTop(model)+.2;
   if(actions.Idle)actions.Idle.time=Math.random()*actions.Idle.getClip().duration;
   this.scene.add(root);this.units.set(u.id,{root,facing,selection,danger,braces,badge,halo,disc,mats,hit,mixer,actions,current:'Idle',team:u.team,role:u.role});}
  this.applyColors();this.setState(state);}
 /** Значок роли: кэш текстур по имени и цвету. */
 badgeTex(name,fill,ring){const k=name+fill+(ring||'');if(!this.badgeCache.has(k)){const cv=badgeCanvas(name,fill,'#0b171c',ring);const tex=new T.CanvasTexture(cv);tex.colorSpace=T.SRGBColorSpace;cv.onupdate=()=>{tex.needsUpdate=true;};this.badgeCache.set(k,tex);}return this.badgeCache.get(k);}
 /** Чья сторона «своя»: её роботы голубые, соперника — розовые. */
 setMe(team){if(this.me===team)return;this.me=team;this.applyColors();if(this.state)this.setState(this.state);}
 applyColors(){if(this.strips)this.strips.forEach((b,t)=>{const c=t===this.me?ME:FOE;b.material.color.set(c);b.material.emissive.set(c);});for(const o of this.units.values()){const mine=o.team===this.me,tint=new T.Color(mine?ME:FOE);
   for(const m of o.mats){m.color=new T.Color(1,1,1).lerp(tint,mine?.78:.6);if(m.emissive)m.emissive=tint.clone().multiplyScalar(mine?.2:.12);}
   o.halo.material.color.set(mine?ME:FOE);o.tex={normal:this.badgeTex(ROLES[o.role].icon,mine?ME_HEX:FOE_HEX),braced:o.role==='anchor'?this.badgeTex('lock',mine?ME_HEX:FOE_HEX,'#ffe27a'):null};o.badge.material.map=o.tex.normal;o.badge.material.needsUpdate=true;}}
 updateCenter(s){for(const [k,o] of this.pits){const hole=s.holes.includes(k);o.tile.visible=!hole;o.tile.position.y=0;o.pit.visible=hole;o.rim.visible=hole;o.crack.visible=!hole&&!!s.cracks?.includes(k);o.next=!hole&&s.cracks?.[0]===k;o.tile.material.color.set(o.next?0x8a4a42:s.cracks?.includes(k)?0x5e5a52:o.tile.userData.color);}}
 pose(o,name){if(o.current===name||!o.actions[name])return;o.actions[o.current]?.fadeOut(.12);o.actions[name].reset().fadeIn(.12).play();o.current=name;}
 setState(s){this.state=s;this.updateCenter(s);for(const u of s.units){const o=this.units.get(u.id);if(!o)continue;o.root.visible=u.alive;o.root.position.copy(world(u.x,u.y));o.root.rotation.set(0,0,0);o.facing.rotation.y=u.team?0:Math.PI;o.braces.visible=u.braced;if(o.tex.braced)o.badge.material.map=u.braced?o.tex.braced:o.tex.normal;this.pose(o,'Idle');}}
 /** Метки целей для выбранного робота. actions: [{type,x,y,id,kill}] */
 highlight(id,actions=[]){// Подставка и кольца — только у выбранного робота
  for(const [k,o]of this.units)o.selection.visible=o.halo.visible=o.disc.visible=k===id;this.clearMarkers();
  const sel=id&&this.state?.units.find(u=>u.id===id);
  for(const a of actions){if(!sel)continue;const g=new T.Group(),p=world(a.x,a.y);g.position.set(p.x,.1,p.z);g.userData={x:a.x,y:a.y};const color=a.kill?MARK.kill:MARK[a.type];
   const tile=new T.Mesh(new T.PlaneGeometry(TILE-.06,TILE-.06),new T.MeshBasicMaterial({color,transparent:true,opacity:.16,depthWrite:false}));tile.rotation.x=-Math.PI/2;g.add(tile);
   if(a.type==='move'){const d=new T.Mesh(new T.CircleGeometry(.16,32),new T.MeshBasicMaterial({color}));d.rotation.x=-Math.PI/2;d.position.y=.01;g.add(d);}
   if(a.type==='jump'){const d=new T.Mesh(new T.RingGeometry(.17,.21,48),new T.MeshBasicMaterial({color,side:T.DoubleSide}));d.rotation.x=-Math.PI/2;d.position.y=.01;g.add(d);}
   if(a.type==='brace'){const fr=new T.Mesh(new T.RingGeometry(.63,.66,4,1),new T.MeshBasicMaterial({color,side:T.DoubleSide}));fr.rotation.set(-Math.PI/2,0,Math.PI/4);fr.position.y=.012;g.add(fr);}
   if(a.type==='push'||a.type==='pull'){const ring=new T.Mesh(new T.RingGeometry(.54,.57,64),new T.MeshBasicMaterial({color,side:T.DoubleSide}));ring.rotation.x=-Math.PI/2;ring.position.y=.012;g.add(ring);
    let dx=Math.sign(a.x-sel.x),dz=Math.sign(a.y-sel.y);if(a.type==='pull'){dx=-dx;dz=-dz;}
    const shape=new T.Shape();shape.moveTo(0,.2);shape.lineTo(.2,-.04);shape.lineTo(.09,-.04);shape.lineTo(0,.07);shape.lineTo(-.09,-.04);shape.lineTo(-.2,-.04);shape.closePath();
    const ch=new T.Mesh(new T.ShapeGeometry(shape),new T.MeshBasicMaterial({color,side:T.DoubleSide}));ch.geometry.rotateX(-Math.PI/2);ch.position.set(0,.015,-.6);const arm=new T.Group();arm.add(ch);arm.rotation.y=Math.atan2(-dx,-dz);g.add(arm);}
   this.markerGroup.add(g);this.markers.push(g);}
  this.applyHover();}
 clearMarkers(){for(const g of this.markers){this.markerGroup.remove(g);g.traverse(n=>{n.geometry?.dispose();n.material?.dispose?.();});}this.markers=[];}
 setHover(c){const k=c?`${c.x},${c.y}`:null;if(k===this.hoverKey)return;this.hoverKey=k;this.hover=c;this.applyHover();}
 applyHover(){const c=this.hover;let point=false;for(const g of this.markers){const on=!!c&&g.userData.x===c.x&&g.userData.y===c.y;g.scale.setScalar(on?1.1:1);g.children[0].material.opacity=on?.4:.16;point||=on;}
  if(c&&!point){const u=this.state?.units.find(u=>u.alive&&u.x===c.x&&u.y===c.y);point=!!u&&!!this.selectable?.(u);}
  this.renderer.domElement.style.cursor=point?'pointer':'default';}
 setThreats(ids){const set=new Set(ids);for(const [k,o]of this.units)o.danger.visible=set.has(k);}
 clearPreview(){while(this.previewGroup.children.length){const o=this.previewGroup.children[0];this.previewGroup.remove(o);o.traverse(n=>{n.geometry?.dispose();n.material?.dispose?.();});}}
 /** Плоская пунктирная стрелка на полу — под роботами, над клетками. */
 dashedArrow(from,to,color,colorAt=null,noHead=false){const g=new T.Group(),dir=to.clone().sub(from);dir.y=0;const len=dir.length();if(len<.01)return g;dir.normalize();
  const mk=c=>new T.MeshBasicMaterial({color:c,transparent:true,opacity:.95,depthWrite:false}),cache=new Map(),mats=c=>{if(!cache.has(c))cache.set(c,mk(c));return cache.get(c);},mat=mats(color);const start=.3,headLen=.18,tip=len-.03,end=noHead?len-.32:tip-headLen-.04,dash=.12,gap=.08,w=.032;
  const dot=new T.CircleGeometry(.038,20),n=Math.max(1,Math.round((end-start)/.17));for(let i=0;i<=n;i++){const d=start+(end-start)*i/n,m=new T.Mesh(dot,colorAt?mats(colorAt(d)):mat);m.position.copy(from).addScaledVector(dir,start+(end-start)*i/n);m.rotation.x=-Math.PI/2;g.add(m);}
  const sh=new T.Shape();sh.moveTo(headLen,0);sh.lineTo(0,.1);sh.lineTo(.045,0);sh.lineTo(0,-.1);sh.closePath();if(!noHead){const head=new T.Mesh(new T.ShapeGeometry(sh),colorAt?mats(colorAt(len)):mat);head.rotation.set(-Math.PI/2,0,Math.atan2(-dir.z,dir.x));head.position.copy(from).addScaledVector(dir,tip-headLen);g.add(head);}
  g.renderOrder=1;g.traverse(n=>n.renderOrder=1);return g;}
 preview(before,after){this.clearPreview();const Y=.105;const groups=new Map();
  for(const u of after.units){const prev=before.units.find(t=>t.id===u.id);if(!prev.alive)continue;const moved=prev.x!==u.x||prev.y!==u.y;if(!moved&&u.alive)continue;
   const col=!u.alive?MARK.kill:(u.team===this.me?ME:FOE);const to=world(u.x,u.y);to.y=Y;
   if(moved){// Цепочка: роботы, сдвинутые по одной линии в одну сторону, рисуются одной стрелкой
    const dx=Math.sign(u.x-prev.x),dy=Math.sign(u.y-prev.y),straight=!dx||!dy,k=straight?`${dx},${dy},${dx?prev.y:prev.x}`:u.id;
    if(!groups.has(k))groups.set(k,[]);groups.get(k).push({prev,u,col});}
   if(u.alive){const ring=new T.Mesh(new T.RingGeometry(.39,.415,64),new T.MeshBasicMaterial({color:col,transparent:true,opacity:.9,depthWrite:false,side:T.DoubleSide}));ring.rotation.x=-Math.PI/2;ring.position.copy(to);ring.renderOrder=1;this.previewGroup.add(ring);}
   else{const s=new T.Shape(),k=.035,l=.24;[[-k,-l],[k,-l],[k,-k],[l,-k],[l,k],[k,k],[k,l],[-k,l],[-k,k],[-l,k],[-l,-k],[-k,-k]].forEach(([x,y],i)=>i?s.lineTo(x,y):s.moveTo(x,y));s.closePath();const x=new T.Mesh(new T.ShapeGeometry(s),new T.MeshBasicMaterial({color:MARK.kill,side:T.DoubleSide,depthWrite:false}));x.geometry.rotateX(-Math.PI/2);x.rotation.y=Math.PI/4;x.position.copy(to);x.position.y=moved?Y+.01:.3;this.previewGroup.add(x);}}
  for(const list of groups.values()){const P=v=>{const w=world(v.x,v.y);w.y=Y;return w;};
   const dir=P(list[0].u).sub(P(list[0].prev)).normalize(),proj=v=>P(v).dot(dir);
   list.sort((a,b)=>proj(a.prev)-proj(b.prev));const from=P(list[0].prev),last=list.reduce((m,e)=>proj(e.u)>proj(m.u)?e:m,list[0]),to=P(last.u),base=proj(list[0].prev);
   // Цвет точки — того робота, который проходит это место последним (самый передний)
   const colorAt=d=>{let c=list[0].col;for(const e of list)if(proj(e.prev)-base<=d+1e-6)c=e.col;return c;};
   this.previewGroup.add(this.dashedArrow(from,to,last.col,list.length>1?colorAt:null,!last.u.alive));}}
 async animate(before,after,a){this.clearPreview();this.highlight(null);this.setThreats([]);
  for(const u of after.units){let old=before.units.find(t=>t.id===u.id),o=this.units.get(u.id);if(!o)continue;if(old.x!==u.x||old.y!==u.y){const dx=u.x-old.x,dz=u.y-old.y;o.facing.rotation.y=Math.atan2(dx,dz);this.pose(o,a.type==='jump'&&u.id===a.id?'Jump':a.type==='move'?'Walk':'HitRecieve_1');}if(u.id===a.id&&(a.type==='push'||a.type==='pull')){o.facing.rotation.y=Math.atan2(a.x-old.x,a.y-old.y);this.pose(o,'Punch');}}
  return new Promise(resolve=>this.anim={before,after,a,start:performance.now(),duration:720,resolve});}
 /** Камера всегда смотрит со стороны своей команды: наклонный вид или сверху. */
 setView(v){Object.assign(this.view,v);this.resize();}
 toggleCamera(){this.setView({overhead:!this.view.overhead});return this.view.overhead;}
 resize(){const w=this.el.clientWidth,h=this.el.clientHeight;if(!w||!h)return;this.renderer.setSize(w,h,false);const cam=this.camera;cam.aspect=w/h;
  const portrait=cam.aspect<1.05,el=this.view.overhead?Math.PI/2-.001:(portrait?60:52)*Math.PI/180,tv=Math.tan(cam.fov*Math.PI/360);
  const halfW=portrait?4.3:4.55,halfH=4.25*Math.sin(el)+.8*Math.cos(el)+(this.view.overhead||portrait?.15:.75);const d=Math.max(halfW/(tv*cam.aspect),halfH/tv);
  const side=this.view.team?-1:1;cam.up.set(0,1,0);if(this.view.overhead)cam.up.set(0,0,-side);cam.position.set(0,d*Math.sin(el),side*d*Math.cos(el));cam.lookAt(0,this.view.overhead?0:.2,this.view.overhead?0:side*(portrait?.25:1.05));cam.updateProjectionMatrix();}
 frame(time){if(document.hidden)return;this.timer.update(time);const dt=Math.min(this.timer.getDelta(),.05);this.mixers.forEach(m=>m.update(dt));
  const pulse=.7+.3*Math.sin(performance.now()/170);for(const o of this.units.values())if(o.danger.visible)o.danger.material.opacity=pulse;for(const o of this.pits.values())if(o.crack.visible)o.mat.opacity=o.next?pulse:.35;
  if(this.anim){const{before,after,a,start,duration,resolve}=this.anim;const t=Math.min(1,(performance.now()-start)/duration),e=t*t*(3-2*t);for(const k of after.holes)if(!before.holes.includes(k)){const o=this.pits.get(k);o.tile.position.y=-Math.pow(t,2)*3;o.crack.visible=t<.3;}
   for(const u of after.units){const old=before.units.find(t=>t.id===u.id),o=this.units.get(u.id);if(!o||!old.alive)continue;const from=world(old.x,old.y),to=world(u.x,u.y);
    {o.root.position.lerpVectors(from,to,e);if(a.type==='jump'&&a.id===u.id)o.root.position.y+=Math.sin(t*Math.PI)*.9;if(!u.alive&&t>.45){o.root.position.y-=Math.pow((t-.45)/.55,2)*4;if(inside6(u.x,u.y))o.root.rotation.y+=.12;else o.root.rotation.z=(u.x>2.5?1:-1)*t*1.7;}}}
   if(t===1){this.anim=null;this.setState(after);resolve();}}
  this.renderer.render(this.scene,this.camera);}
}
