import '@fontsource/manrope/400.css';
import '@fontsource/manrope/600.css';
import '@fontsource/manrope/700.css';
import '@fontsource/manrope/800.css';
import './style.css';
import{initial,legal,apply,simulate,describe,knocked,displaced,threatsAgainst,ROLES,ACTIONS,LEVELS,at,bot,sameAction,central,CENTER,RING,RING_TURN,TURN_LIMIT,PER_TURN}from'./engine.js';
import{Arena}from'./scene.js';
import{icon}from'./icons.js';

const $=id=>document.getElementById(id);
const store={get(k,d){try{return localStorage.getItem('shift.'+k)??d;}catch{return d;}},set(k,v){try{localStorage.setItem('shift.'+k,v);}catch{}}};
const TEAM_NAME=['Голубые','Розовые'];
let state=initial(),selected=null,pending=null,mode='bot',level=store.get('level','normal'),busy=false,thinking=false,ready=false,started=false,generation=0,muted=store.get('muted','0')==='1',audio,past=[];
let peer=null,connection=null,host=false,onlineTeam=0,connected=false,networkGeneration=0;
if(!LEVELS[level])level='normal';

// Значки в статичной разметке
document.querySelectorAll('[data-icon]').forEach(el=>el.insertAdjacentHTML('afterbegin',icon(el.dataset.icon)));
$('rolesGrid').innerHTML=Object.entries(ROLES).map(([k,r])=>`<div class="role-rule"><span class="role-ico">${icon(r.icon)}</span><div><b>${r.name}</b><p>${r.tip}</p></div></div>`).join('');

const arena=new Arena($('viewport'),pick);
arena.selectable=u=>myTurn()&&u.team===state.turn&&!state.acted.includes(u.id);

function toast(t){$('toast').textContent=t;$('toast').classList.add('visible');clearTimeout(toast.timer);toast.timer=setTimeout(()=>$('toast').classList.remove('visible'),3200);}
function sound(type='move'){if(muted)return;try{audio??=new(window.AudioContext||window.webkitAudioContext)();audio.resume();const now=audio.currentTime;const o=audio.createOscillator(),g=audio.createGain();o.type=type==='push'||type==='ko'?'triangle':'sine';const f={rotate:[180,65],push:[100,35],ko:[220,40],select:[520,640],move:[460,620]}[type]||[460,620];o.frequency.setValueAtTime(f[0],now);o.frequency.exponentialRampToValueAtTime(f[1],now+.18);g.gain.setValueAtTime(.0001,now);g.gain.exponentialRampToValueAtTime(type==='select'?.04:.075,now+.02);g.gain.exponentialRampToValueAtTime(.0001,now+.25);o.connect(g).connect(audio.destination);o.start();o.stop(now+.27);}catch{}}

const ended=()=>state.winner!==null||state.draw;
const myTurn=()=>started&&ready&&!busy&&!ended()&&(mode==='local'||mode==='bot'&&state.turn===0||mode==='online'&&connected&&state.turn===onlineTeam);
/** Чью сторону показывает интерфейс: в локальной игре — того, кто ходит. */
const viewTeam=()=>mode==='online'?onlineTeam:mode==='bot'?0:state.turn;
const choices=()=>myTurn()?legal(state):[];
const teamName=t=>mode==='bot'?(t?'Бот':'Вы'):mode==='online'?(t===onlineTeam?'Вы':'Соперник'):TEAM_NAME[t];

/** Цели выбранного робота: ход и прыжок в одну клетку дают одно и то же — оставляем ход. */
function targetsFor(id){const list=choices().filter(a=>a.id===id);const out=[];for(const a of list){if(a.type==='jump'&&list.some(b=>b.type==='move'&&b.x===a.x&&b.y===a.y))continue;const lost=displaced(state,a);out.push({...a,kill:lost.some(u=>u.team!==state.turn),selfKill:lost.some(u=>u.team===state.turn)});}return out;}
function currentThreats(){if(!myTurn())return new Map();const t=threatsAgainst(state,state.turn);
 // Робот на клетке, которая провалится после этого хода, тоже в опасности
 const c=state.cracks?.[0];if(c){const u=at(state,...c.split(',').map(Number));if(u&&u.team===state.turn&&!t.has(u.id))t.set(u.id,[]);}
 if(state.ring==='warn')for(const u of state.units)if(u.alive&&u.team===state.turn&&RING.includes(u.x+','+u.y)&&!t.has(u.id))t.set(u.id,[]);return t;}
/** Что соперник сможет выбить сразу после этого действия. */
function exposureAfter(a){const n=simulate(state,a);if(!n)return[];const next={...n,turn:1-state.turn,winner:null,draw:false};return[...threatsAgainst(next,state.turn).keys()].map(id=>n.units.find(u=>u.id===id));}

function render(){
 const team=state.turn,mine=myTurn(),view=viewTeam(),threats=currentThreats();
 document.body.dataset.turn=team;const me=mode==='online'?onlineTeam:0;document.body.dataset.me=me;arena.setMe(me);
 $('modePill').textContent=mode==='bot'?`Против бота · ${LEVELS[level].name}`:mode==='local'?'Вдвоём на одном экране':`Онлайн · ${connected?'на связи':'нет связи'}`;
 const per=state.turnNo===1?1:PER_TURN;$('round').textContent=ended()?'Конец':`Ход ${state.turnNo} · действие ${Math.min(state.acted.length+1,per)}/${per}`;
 $('centerScore').textContent=`очки центра ${state.score[0]} : ${state.score[1]}`;
 for(const t of [0,1]){$('name'+t).textContent=teamName(t);$('pips'+t).innerHTML=state.units.filter(u=>u.team===t).map(u=>`<span class="pip${u.alive?'':' out'}${threats.has(u.id)?' danger':''}" title="${ROLES[u.role].name}${u.alive?'':' — выбит'}">${icon(ROLES[u.role].icon)}</span>`).join('');document.querySelector('.side-'+t).classList.toggle('active',!ended()&&team===t);}
 // Заголовок и подсказка-шаг
 const title=state.winner!==null?`${teamName(state.winner)==='Вы'?'Победа!':teamName(state.winner)==='Бот'?'Бот победил':`Победа: ${teamName(state.winner)}`}`:state.draw?'Ничья':!started?'Сдвиг':mode==='online'&&!connected?'Нет соединения':busy?'…':mine?(mode==='local'?`Ход: ${TEAM_NAME[team]}`:'Ваш ход'):mode==='bot'?'Ход бота':'Ход соперника';
 $('turnTitle').textContent=title;
 const tsel=selected&&targetsFor(selected);
 $('turnHint').textContent=ended()?'Начните новую партию или посмотрите на поле':!started?'Выберите режим, чтобы начать':!mine?(mode==='bot'?'Бот выбирает действие…':'Следите за позицией'):pending?'Проверьте результат и подтвердите ход':selected?(tsel.length?'Нажмите на метку на поле':'У этого робота нет ходов — выберите другого'):state.acted.length?'Второе действие — другим роботом. Или завершите ход.':threats.size?`Под угрозой: ${[...threats.keys()].map(id=>ROLES[state.units.find(u=>u.id===id).role].name).join(', ')} — защитите или атакуйте первым`:'Выберите робота на поле или в списке';
 $('turnHint').classList.toggle('alert',mine&&!selected&&!pending&&threats.size>0);
 $('thinking').classList.toggle('hidden',!thinking);
 // Отряд
 $('squadLabel').textContent=mode==='local'?`Отряд: ${TEAM_NAME[view]}`:'Ваш отряд';
 const squad=state.units.filter(u=>u.team===view);
 $('squad').replaceChildren(...squad.map((u,i)=>{const b=document.createElement('button');b.className='unit t'+u.team;b.classList.toggle('active',selected===u.id);const done=state.acted.includes(u.id)&&u.team===state.turn;b.disabled=!u.alive||!mine||done;b.classList.toggle('done',done);
  const tags=[!u.alive&&'<span class="tag out">выбит</span>',u.alive&&threats.has(u.id)&&'<span class="tag danger">под угрозой</span>',done&&'<span class="tag out">сделал ход</span>',u.braced&&'<span class="tag lock">закреплён</span>'].filter(Boolean).join('');
  b.innerHTML=`<span class="unit-ico">${icon(ROLES[u.role].icon)}</span><span class="unit-txt"><b>${ROLES[u.role].name}</b><small>${ROLES[u.role].short}</small></span><span class="unit-tags">${tags}<kbd>${i+1}</kbd></span>`;b.onclick=()=>select(u);return b;}));
 // Детали выбранного
 const u=state.units.find(u=>u.id===selected);$('detail').classList.toggle('hidden',!u);
 if(u){const types=['move','jump','push','pull','brace'].filter(t=>tsel.some(a=>a.type===t));const kills=tsel.filter(a=>a.kill).length;
  $('detail').innerHTML=`<p>${ROLES[u.role].tip}</p><div class="chips">${types.map(t=>`<span class="chip ${t}">${ACTIONS[t]} · ${tsel.filter(a=>a.type===t).length}</span>`).join('')}${kills?`<span class="chip kill">Выбивает · ${kills}</span>`:''}${types.length?'':'<span class="chip none">нет доступных действий</span>'}</div>${tsel.some(a=>a.type==='brace')?`<button id="braceBtn" class="outline wide">${icon('lock')} Закрепиться на месте</button>`:''}`;
  $('braceBtn')?.addEventListener('click',()=>stage(tsel.find(a=>a.type==='brace')));}
 // Платформа
 // Центр: состояние обрушения
 const cHoles=CENTER.filter(c=>state.holes.includes(c)).length;
 const cr=state.cracks,cells=[...document.querySelectorAll('#centerMini i')];
 CENTER.forEach((c,k)=>{const [x,y]=c.split(',').map(Number);const u=at(state,x,y);const el=cells[[0,1,3,2][k]];el.className=state.holes.includes(c)?'hole':cr?.[0]===c?'next':u?'t'+u.team:'';});
 const nextCell=cr?.[0],victim=nextCell&&at(state,...nextCell.split(',').map(Number));
 $('centerTag').textContent=cHoles===4?'обрушен':cr?'рушится':`${CENTER.filter(c=>!state.holes.includes(c)&&at(state,...c.split(',').map(Number))).length}/${CENTER.filter(c=>!state.holes.includes(c)).length}`;
 $('centerTag').className='tag'+(cr&&cHoles<4?' danger':'');
 const intact=CENTER.filter(c=>!state.holes.includes(c)).length;
 $('centerHint').textContent=cHoles===4?'Центр — провал 2×2. Сталкивайте туда соперников.':cr?(victim?`В конце следующего хода провалится розовая клетка с роботом: ${ROLES[victim.role].name}${victim.team===viewTeam()?' (ваш!) — уводите его':''}.`:'В конце следующего хода провалится розовая клетка.'):`Займут все ${intact===4?'4 клетки':intact===1?'оставшуюся клетку':'оставшиеся '+intact+' клетки'} — первая занятая провалится.`;
 $('ringHint').textContent=state.ring==='gone'?'Края поля обрушились.':state.ring==='warn'?'':`Края поля обрушатся после ${RING_TURN}-го хода — осталось ${RING_TURN-state.turnNo+1}.`;
 if(state.ring==='warn')$('centerHint').textContent='Края поля рушатся! В конце этого хода всё внешнее кольцо обрушится — уводите роботов внутрь.';
 $('centerTag').textContent=state.ring==='warn'?'края рушатся':$('centerTag').textContent;if(state.ring==='warn')$('centerTag').className='tag danger';
 // Предпросмотр
 $('preview').classList.toggle('hidden',!pending);$('confirm').disabled=!mine;
 if(pending){const lost=knocked(state,pending);$('previewText').textContent=describe(state,pending);const exposed=exposureAfter(pending).filter(v=>v.alive);
  const n2=simulate(state,pending),fell=lost.filter(v=>v.team===state.turn),pushed=fell.filter(v=>{const b=state.units.find(t=>t.id===v.id);const c=n2.units.find(t=>t.id===v.id);return b.x!==c.x||b.y!==c.y;}),sunk=fell.filter(v=>!pushed.includes(v));
  const warn=[pushed.length&&'Вы выталкиваете своего робота!',sunk.length&&`${sunk.map(v=>ROLES[v.role].name).join(', ')} провалится в центре — этим ходом вы его не спасаете`,exposed.length&&`После хода соперник сможет выбить: ${exposed.map(v=>ROLES[v.role].name).join(', ')}`].filter(Boolean);
  $('previewWarn').innerHTML=warn.length?icon('warn')+warn.join('. '):'';$('previewWarn').classList.toggle('hidden',!warn.length);
  $('preview').classList.toggle('good',lost.some(v=>v.team!==state.turn));}
 // Инструменты
 $('hintBtn').disabled=!mine||mode==='online';
 $('endTurn').classList.toggle('hidden',!mine||!state.acted.length||!!pending);
 $('undoBtn').disabled=busy||thinking||mode==='online'||!past.length||!started;
 // Журнал
 const hist=state.history.slice(-6).reverse();
 $('history').innerHTML=hist.length?hist.map(h=>`<li><span class="team-dot t${h.team}"></span>${h.text}</li>`).join(''):'<li class="empty">Здесь появятся ходы партии.</li>';
 // Баннер на поле
 const banner=!ended()&&state.ring==='warn'&&!thinking?'Края рушатся в конце этого хода!':ended()?(state.draw?'Ничья':`${teamName(state.winner)==='Вы'?'Вы победили':teamName(state.winner)+' — победа'}`):thinking?'Бот думает…':(mode==='online'&&started&&!mine&&!busy&&connected)?'Ход соперника':'';
 $('banner').textContent=banner;$('banner').classList.toggle('visible',!!banner);
 arena.highlight(selected,pending?[]:(tsel||[]));
 arena.setThreats(pending?[]:[...threats.keys()]);
}

function select(u){if(!myTurn()||u.team!==state.turn||!u.alive||state.acted.includes(u.id))return;if(selected===u.id&&!pending){selected=null;render();return;}selected=u.id;pending=null;arena.clearPreview();render();sound('select');}
function deselect(){selected=null;pending=null;arena.clearPreview();render();}
function pick(x,y){if(!myTurn())return;
 const t=selected&&targetsFor(selected).find(a=>a.x===x&&a.y===y);
 if(t){if(pending&&sameAction(pending,t))confirm();else stage(t);return;}
 const u=at(state,x,y);
 if(u&&u.team===state.turn){if(state.acted.includes(u.id)){toast('Этот робот уже действовал в этом ходу.');return;}select(u);return;}
 if(pending||selected){deselect();return;}
 if(u)toast('Это робот соперника. Выберите своего, затем его толчок.');}
function stage(a){if(!a||!myTurn())return;if(a.id)selected=a.id;pending=a;arena.preview(state,simulate(state,a));render();sound('select');}
function confirm(){if(!myTurn()||!pending)return;const a=pending;if(mode==='online'&&!host){connection.send({type:'request',ply:state.ply,action:a});pending=null;busy=true;arena.clearPreview();render();}else commit(a);}
function endTurn(){if(!myTurn()||!state.acted.length)return;pending={type:'end'};confirm();}
function cancel(){if(pending){pending=null;arena.clearPreview();render();}else if(selected)deselect();}

async function commit(a,remote=false){if(busy||!ready)return;const n=apply(state,a);if(!n)return;const before=state,oldGeneration=generation;if(mode!=='online')past.push(before);state=n;busy=true;selected=null;pending=null;render();const ko=knocked(before,a).length;sound(ko?'ko':a.type==='push'||a.type==='pull'?'push':a.type);
 if(mode==='online'&&host&&!remote)connection?.send({type:'action',ply:before.ply,action:a});
 await arena.animate(before,n,a);if(oldGeneration!==generation)return;busy=false;render();
 if(ended()){const w=state.winner;$('endTitle').textContent=state.draw?'Ничья.':mode==='bot'?(w===0?'Победа!':'Бот победил.'):mode==='online'?(w===onlineTeam?'Победа!':'Поражение.'):`${TEAM_NAME[w]} побеждают.`;
  const sc=`${state.score[0]} : ${state.score[1]}`;
  $('endText').textContent=state.byScore?(state.draw?`Очки центра равны (${sc}) — ничья.`:`Решили очки центра: ${sc}. ${state.turnNo>TURN_LIMIT?`Прошло ${TURN_LIMIT} ходов.`:'Позиция повторилась трижды.'}`):state.draw?'Осталось по одному роботу.':`Три робота выбиты. Партия заняла ${state.turnNo-1} ходов.`+(mode==='bot'&&w===1?' Попробуйте вернуть ход и найти другой путь.':'');
  $('rematch').textContent=mode==='online'?'Новая комната':'Ещё партия';setTimeout(()=>$('endDialog').showModal(),500);}
 else scheduleBot();}
function scheduleBot(){if(mode!=='bot'||state.turn!==1||busy||!started||ended())return;const epoch=generation;thinking=true;render();
 setTimeout(()=>{if(epoch!==generation||mode!=='bot'||state.turn!==1||busy){return;}const a=bot(state,level);thinking=false;if(a)commit(a);else render();},550);}
function undo(){if(mode==='online'||busy||!past.length)return;generation++;thinking=false;let s=past.pop();while(mode==='bot'&&s.turn===1&&past.length)s=past.pop();state=s;selected=null;pending=null;arena.clearPreview();arena.setState(state);$('endDialog').close();render();sound('select');scheduleBot();}
function hint(){if(!myTurn()||mode==='online')return;const a=bot(state,'hard');if(!a)return;stage(a);toast('Совет мастера — можно подтвердить или выбрать своё.');}

function start(m,keepNetwork=false){if(busy){toast('Дождитесь завершения хода.');return;}if(!keepNetwork)cleanNetwork();generation++;thinking=false;mode=m;state=initial();past=[];selected=null;pending=null;started=true;arena.clearPreview();arena.setView({team:mode==='online'?onlineTeam:0});arena.setState(state);['startDialog','endDialog','onlineDialog'].forEach(id=>$(id).close());render();sound();}

// ── Обработчики ─────────────────────────────────
$('confirm').onclick=confirm;$('cancel').onclick=cancel;

$('hintBtn').onclick=hint;$('endTurn').onclick=endTurn;$('undoBtn').onclick=undo;
const levelButtons=[...document.querySelectorAll('#levelSeg button')];const paintLevel=()=>levelButtons.forEach(b=>b.classList.toggle('active',b.dataset.level===level));paintLevel();
levelButtons.forEach(b=>b.onclick=()=>{level=b.dataset.level;store.set('level',level);paintLevel();});
$('startBot').onclick=()=>start('bot');$('startLocal').onclick=()=>start('local');$('startOnline').onclick=()=>{$('startDialog').close();$('onlineDialog').showModal();};
$('menu').onclick=()=>{if(!busy)$('startDialog').showModal();else toast('Дождитесь завершения хода.');};
$('closeStart').onclick=()=>{$('startDialog').close();if(!started&&ready)start('bot');};
$('help').onclick=()=>$('helpDialog').showModal();
const paintSound=()=>{$('sound').innerHTML=icon(muted?'mute':'sound');$('sound').setAttribute('aria-label',muted?'Включить звук':'Выключить звук');};paintSound();
$('sound').onclick=()=>{muted=!muted;store.set('muted',muted?'1':'0');paintSound();if(!muted)sound();};
$('camera').onclick=()=>{const top=arena.toggleCamera();$('camera').querySelector('span').textContent=top?'Наклон':'Сверху';};
$('rematch').onclick=()=>{if(mode==='online'){$('endDialog').close();cleanNetwork();$('onlineDialog').showModal();$('inviteBox').classList.add('hidden');$('onlineStatus').textContent='Создайте новую комнату для реванша.';}else start(mode);};
document.querySelectorAll('[data-close]').forEach(b=>b.onclick=()=>$(b.dataset.close).close());
document.addEventListener('keydown',e=>{if(document.querySelector('dialog[open]')||e.target.tagName==='INPUT')return;
 if(e.key==='Escape')cancel();
 else if(e.key==='Enter'&&pending){e.preventDefault();confirm();}
 else if((e.key==='e'||e.key==='у'||e.key==='E')&&!pending)endTurn();
 else if(/^[1-4]$/.test(e.key)){const u=state.units.filter(u=>u.team===viewTeam())[+e.key-1];if(u)select(u);}
 else if((e.key==='z'||e.key==='я'||e.key==='Z')&&!e.metaKey)undo();
 else if((e.ctrlKey||e.metaKey)&&e.code==='KeyZ'){e.preventDefault();undo();}});

// ── Онлайн ──────────────────────────────────────
function cleanNetwork(){networkGeneration++;connected=false;connection?.close();peer?.destroy();connection=null;peer=null;}
function onlineStatus(t){$('onlineStatus').textContent=t;}
async function openPeer(id){const {Peer}=await import('peerjs');return new Promise((resolve,reject)=>{const p=id?new Peer(id):new Peer();peer=p;const timer=setTimeout(()=>{p.destroy();reject(new Error('Сервис соединения не ответил. Попробуйте другую сеть.'));},15000);p.once('open',()=>{clearTimeout(timer);resolve(p);});p.on('error',e=>{clearTimeout(timer);const msg=e.type==='peer-unavailable'?'Комната не найдена. Проверьте код и вкладку создателя.':`Не удалось подключиться: ${e.type}.`;onlineStatus(msg);reject(new Error(msg));});});}
function attach(c,isHost,epoch){connection=c;host=isHost;onlineTeam=isHost?0:1;
 c.on('open',()=>{if(epoch!==networkGeneration)return;connected=true;onlineStatus('Соединение установлено.');if(isHost){start('online',true);c.send({type:'hello',version:9});}});
 c.on('data',async msg=>{if(epoch!==networkGeneration||!msg||typeof msg!=='object')return;
  if(msg.type==='hello'&&!isHost){if(msg.version!==9){onlineStatus('Версии игры различаются. Обновите страницы.');c.close();return;}start('online',true);}
  if(msg.type==='request'&&isHost&&mode==='online'){if(msg.ply!==state.ply||state.turn!==1||busy||!legal(state).some(a=>sameAction(a,msg.action))){c.send({type:'reject'});return;}await commit(msg.action);}
  if(msg.type==='action'&&!isHost&&mode==='online'){if(msg.ply!==state.ply||!legal(state).some(a=>sameAction(a,msg.action))){toast('Партии рассинхронизировались. Создайте новую комнату.');connected=false;busy=false;render();return;}busy=false;await commit(msg.action,true);}
  if(msg.type==='reject'){busy=false;render();toast('Ход отклонён. Выберите действие ещё раз.');}});
 c.on('close',()=>{if(epoch!==networkGeneration)return;connected=false;busy=!!arena.anim;render();onlineStatus('Соединение прервано. Создайте новую комнату.');if(mode==='online')toast('Соперник отключился. Создайте новую комнату.');});
 c.on('error',()=>onlineStatus('Ошибка прямого соединения. Попробуйте другую сеть.'));}
$('host').onclick=async()=>{if(!ready||busy)return;cleanNetwork();$('inviteBox').classList.add('hidden');onlineStatus('Создаём комнату…');$('host').disabled=true;const epoch=networkGeneration;try{const code=Array.from(crypto.getRandomValues(new Uint8Array(4)),b=>b.toString(16).padStart(2,'0')).join('');const p=await openPeer(`shift-v9-${code}`);if(epoch!==networkGeneration)return;const url=new URL(location.href);url.hash=`room=${code}`;$('invite').value=url.href;$('inviteBox').classList.remove('hidden');onlineStatus(`Код ${code}. Ожидаем второго игрока…`);p.on('connection',c=>{if(connection){c.close();return;}attach(c,true,epoch);});}catch(e){onlineStatus(e.message);}finally{$('host').disabled=false;}};
$('join').onclick=async()=>{if(!ready||busy)return;const code=$('roomCode').value.trim().replace(/^.*room=/,'').toLowerCase();if(!/^[a-z0-9-]{4,32}$/.test(code)){onlineStatus('Введите код из приглашения.');return;}cleanNetwork();onlineStatus('Подключаемся к сопернику…');$('join').disabled=true;const epoch=networkGeneration;try{const p=await openPeer();if(epoch!==networkGeneration)return;const c=p.connect(`shift-v9-${code}`,{reliable:true});attach(c,false,epoch);setTimeout(()=>{if(epoch===networkGeneration&&!connected){onlineStatus('Нет соединения. Проверьте код; обе вкладки должны оставаться открытыми.');c.close();}},15000);}catch(e){onlineStatus(e.message);}finally{$('join').disabled=false;}};
$('copyInvite').onclick=async()=>{try{await navigator.clipboard.writeText($('invite').value);toast('Ссылка скопирована.');}catch{$('invite').select();toast('Скопируйте выделенную ссылку.');}};

render();
arena.load(state,n=>{$('loadText').textContent=`Подготовка роботов · ${n}/4`;}).then(()=>{ready=true;$('loading').classList.add('hidden');render();const room=new URLSearchParams(location.hash.slice(1)).get('room');if(room){$('roomCode').value=room;$('onlineDialog').showModal();}else $('startDialog').showModal();}).catch(e=>{console.error(e);$('loadText').textContent='Не удалось загрузить роботов. Обновите страницу.';});
// Для смоук-тестов в браузере: чтение состояния и «касание» клетки.
window.shiftDebug={getState:()=>structuredClone(state),get ready(){return ready},get busy(){return busy},get connected(){return connected},get mode(){return mode},get selected(){return selected},get pending(){return pending},tap:(x,y)=>pick(x,y),arena};
