// Единые значки ролей и действий: SVG для интерфейса, canvas-спрайты для 3D-сцены.
const P={
 ram:'<path d="M5.5 12.5 12 6l6.5 6.5M5.5 19 12 12.5l6.5 6.5"/>',
 magnet:'<path d="M7 4.5v7.5a5 5 0 0 0 10 0V4.5"/><path d="M4.5 8h5M14.5 8h5"/>',
 anchor:'<circle cx="12" cy="5" r="2"/><path d="M12 7v13.5M8 10.5h8M4.5 13.5a7.5 7.5 0 0 0 15 0"/>',
 jumper:'<path d="M4 19.5C5.5 9 18.5 9 20 19.5"/><path d="m16.2 17.6 3.8 1.9 1.4-4"/><circle cx="4" cy="19.5" r="1.4"/>',
 rotL:'<path d="M5 12a7 7 0 1 0 2.1-5"/><path d="M4.5 3.5V8H9"/>',
 rotR:'<path d="M19 12a7 7 0 1 1-2.1-5"/><path d="M19.5 3.5V8H15"/>',
 lock:'<rect x="5" y="10.5" width="14" height="10" rx="2"/><path d="M8 10.5V8a4 4 0 0 1 8 0v2.5"/>',
 warn:'<path d="M12 4 21 19.5H3z"/><path d="M12 10v4.5M12 17v.1"/>',
 hint:'<path d="M9 18h6M10 21h4M12 3a6 6 0 0 0-3.5 10.9c.6.5 1 1.2 1 2.1h5c0-.9.4-1.6 1-2.1A6 6 0 0 0 12 3z"/>',
 undo:'<path d="M9 14 4 9l5-5"/><path d="M4 9h10.5a5.5 5.5 0 0 1 0 11H11"/>',
 camera:'<path d="M3 8.5 12 4l9 4.5-9 4.5z"/><path d="M3 13l9 4.5 9-4.5"/>',
 sound:'<path d="M4 9.5h4l5-4v13l-5-4H4z"/><path d="M16.5 9a4 4 0 0 1 0 6M19 6.5a7.5 7.5 0 0 1 0 11"/>',
 mute:'<path d="M4 9.5h4l5-4v13l-5-4H4z"/><path d="m17 9.5 5 5M22 9.5l-5 5"/>',
 x:'<path d="M6 6l12 12M18 6 6 18"/>'
};
export function icon(name,cls=''){return `<svg class="ico ${cls}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${P[name]||''}</svg>`;}
/** Рисует значок роли в круге цвета команды на canvas. Возвращает canvas (синхронно перерисовывается после загрузки SVG). */
export function badgeCanvas(name,fill,ink='#0d1a1f',ring=null){const c=document.createElement('canvas');c.width=c.height=128;const g=c.getContext('2d');
 const base=()=>{g.clearRect(0,0,128,128);g.beginPath();g.arc(64,64,56,0,Math.PI*2);g.fillStyle=fill;g.fill();g.lineWidth=7;g.strokeStyle=ring||'rgba(8,16,20,.85)';g.stroke();};
 base();const img=new Image();const svg=`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="76" height="76" fill="none" stroke="${ink}" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round">${P[name]}</svg>`;
 img.onload=()=>{base();g.drawImage(img,26,26,76,76);c.onupdate?.();};img.src='data:image/svg+xml;charset=utf-8,'+encodeURIComponent(svg);return c;}
