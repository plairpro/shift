# Asset provenance

Robot models: Quaternius, Animated Mech Pack.
Source: https://quaternius.com/packs/animatedmech.html
Official download folder: https://drive.google.com/drive/folders/1sueV_4CGMpZC8y30mWfgKK9UaT3mkHBX
License stated by the creator: CC0 https://creativecommons.org/publicdomain/zero/1.0/

Downloaded from Textured/glTF, October 5, 2026:
- George.gltf → public/models/George.glb (Таран)
- Leela.gltf → public/models/Leela.glb (Магнит)
- Mike.gltf → public/models/Mike.glb (Якорь)
- Stan.gltf → public/models/Stan.glb (Прыгун)

Files converted to binary glTF containers, preserving geometry, textures, skeletons and selected animations (Idle, Walk, Punch, HitRecieve_1, Death, Jump, Dance).
Arena geometry and game interface authored for this prototype.

Three.js (MIT) and PeerJS (MIT) are installed via npm. Font: Manrope (SIL Open Font License), bundled locally via @fontsource/manrope; system sans-serif is the fallback.
