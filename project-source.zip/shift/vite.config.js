import { defineConfig } from 'vite';
export default defineConfig({base:'./',build:{chunkSizeWarningLimit:900}});
