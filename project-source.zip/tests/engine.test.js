import {test} from 'node:test';import assert from 'node:assert/strict';
import{initial,legal,apply,bot,threatsAgainst,LEVELS,RING_TURN,TURN_LIMIT,centerCount,configure}from'../src/engine.js';
// Эти проверки написаны для поля 7×7 с центром 3×3 — механика от размера не зависит.
configure({n:7,center:['2,2','3,2','4,2','4,3','4,4','3,4','2,4','2,3','3,3']});
const sparse=(turn=0)=>{let s=initial();s.units.forEach(u=>u.alive=false);s.turn=turn;s.left=2;s.acted=[];s.turnNo=5;s.ply=10;return s;};
const put=(s,i,x,y,extra={})=>Object.assign(s.units[i],{alive:true,x,y,since:0,...extra});
// индексы: 0 Таран,1 Магнит,2 Якорь,3 Прыгун (голубые); 4..7 то же у розовых
const find=(s,f)=>legal(s).find(f);

test('every turn, including the first, has two actions by different robots',()=>{let s=initial();assert(legal(s).every(a=>a.id?.startsWith('0-')));
 s=apply(s,find(s,a=>a.type==='move'));assert.equal(s.turn,0);s=apply(s,find(s,a=>a.type==='move'&&a.id!==s.acted[0]));assert.equal(s.turn,1);assert.equal(s.left,2);
 const a=find(s,a=>a.type==='move');s=apply(s,a);assert.equal(s.turn,1);assert(!legal(s).some(b=>b.id===a.id));assert(legal(s).some(b=>b.type==='end'));
 s=apply(s,find(s,a=>a.type==='move'));assert.equal(s.turn,0);assert.equal(s.turnNo,3);});

test('player may end the turn after one action',()=>{let s=initial();s=apply(s,find(s,a=>a.type==='move'));s=apply(s,{type:'end'});assert.equal(s.turn,1);});

test('ram pushes the whole chain two cells; robots crossing the edge are out',()=>{let s=sparse();put(s,0,3,2);put(s,1,0,0);put(s,4,4,2);put(s,5,5,2);put(s,6,5,5);
 const n=apply(s,{type:'push',id:'0-ram',x:4,y:2});assert(n);assert.equal(n.units[4].x,6);assert.equal(n.units[5].alive,false);});

test('brace protects during the opponent turn and wears off when the owner turn starts',()=>{let s=sparse();put(s,2,2,2);put(s,0,0,5);put(s,4,1,2);put(s,5,5,5);put(s,6,5,0);
 s=apply(s,{type:'brace',id:'0-anchor',x:2,y:2});s=apply(s,{type:'end'});assert.equal(s.turn,1);assert.equal(s.units[2].braced,true);
 assert(!legal(s).some(a=>a.type==='push'&&a.id==='1-ram'));
 s=apply(s,find(s,a=>a.id==='1-magnet'&&a.type==='move'));s=apply(s,{type:'end'});assert.equal(s.turn,0);assert.equal(s.units[2].braced,false);});

test('only an anchor can push a braced robot',()=>{let s=sparse();put(s,0,1,2);put(s,2,2,3);put(s,1,5,5);put(s,6,2,2,{braced:true});put(s,4,3,2);put(s,5,0,5);
 assert(!legal(s).some(a=>a.type==='push'&&a.id==='0-ram'));const b=find(s,a=>a.type==='push'&&a.id==='0-anchor'&&a.x===2&&a.y===2);assert(b);
 const n=apply(s,b);assert.deepEqual([n.units[6].x,n.units[6].y],[2,1]);});

test('magnet pulls from up to 5 cells by 2 and drags through a hole',()=>{let s=sparse();put(s,1,0,5);put(s,0,5,5);put(s,2,5,4);put(s,4,0,0);put(s,5,4,0);put(s,6,3,0);
 let n=apply(s,find(s,a=>a.type==='pull'&&a.x===0&&a.y===0));assert.deepEqual([n.units[4].x,n.units[4].y],[0,2]);
 s.holes=['0,2'];n=apply(s,find(s,a=>a.type==='pull'&&a.x===0&&a.y===0));assert.equal(n.units[4].alive,false);});

test('center: when all intact cells are held, the longest-held cracks and falls at the end of the next turn',()=>{let s=sparse();const pre=['4,2','4,3','4,4','3,4','2,4','2,3'].filter(c=>c!=='2,3');s.holes=pre.slice();
 put(s,0,2,2,{since:5});put(s,1,3,2,{since:1});put(s,4,3,3,{since:4});put(s,5,0,0);put(s,6,5,5);put(s,2,1,3);put(s,7,0,6);put(s,4,3,3,{since:4});
 let n=apply(s,{type:'move',id:'0-anchor',x:2,y:3});n=apply(n,{type:'end'});assert.deepEqual(n.cracks,['3,2']);assert.deepEqual(n.holes,pre);
 n=apply(n,find(n,a=>a.id==='1-anchor'&&a.type==='move'));n=apply(n,{type:'end'});assert.deepEqual(n.holes,[...pre,'3,2']);assert.equal(n.units[1].alive,false);
 assert(!legal(n).some(a=>a.type==='move'&&a.x===3&&a.y===2));});

test('outer ring turns red before turn RING_TURN and collapses after it',()=>{let s=sparse();s.turnNo=RING_TURN-1;put(s,0,2,2);put(s,1,0,3);put(s,2,1,1);put(s,4,4,4);put(s,5,6,6);put(s,6,3,1);
 s=apply(s,{type:'move',id:'0-ram',x:2,y:1});s=apply(s,{type:'end'});assert.equal(s.ring,'warn');assert(s.units[1].alive);
 s=apply(s,find(s,a=>a.id==='1-ram'&&a.type==='move'&&a.x===4&&a.y===3));s=apply(s,{type:'end'});assert.equal(s.ring,'gone');assert.equal(s.units[1].alive,false);assert.equal(s.units[5].alive,false);
 assert(!legal(s).some(a=>a.type==='move'&&(a.x===0||a.y===0||a.x===6||a.y===6)));});

test('center points decide the game at the turn limit',()=>{let s=sparse();s.turnNo=TURN_LIMIT;put(s,0,2,2);put(s,1,3,3);put(s,2,0,4);put(s,4,4,1);put(s,5,4,0);put(s,6,1,0);s.score=[3,3];
 assert.equal(centerCount(s,0),2);s=apply(s,{type:'move',id:'0-anchor',x:1,y:4});s=apply(s,{type:'end'});assert.equal(s.winner,0);assert.equal(s.byScore,true);});

test('threats include two-action combos (pull, then push)',()=>{let s=sparse(0);put(s,0,2,5);put(s,2,0,0);put(s,3,0,1);put(s,4,4,4);put(s,5,5,5);put(s,6,5,1);
 const t=threatsAgainst(s,0);assert(t.has('0-ram'));});

test('every bot level returns a legal action without mutating state',()=>{let s=initial();const before=JSON.stringify(s);for(const lv of Object.keys(LEVELS)){const a=bot(s,lv);assert(apply(s,a));}assert.equal(JSON.stringify(s),before);});

test('random legal play keeps live units unique and on intact cells',()=>{let s=initial();for(let i=0;i<300&&s.winner===null&&!s.draw;i++){let l=legal(s);s=apply(s,l[(i*17+3)%l.length]);const u=s.units.filter(u=>u.alive);assert.equal(new Set(u.map(u=>`${u.x},${u.y}`)).size,u.length);assert(u.every(u=>u.x>=0&&u.x<7&&u.y>=0&&u.y<7&&!s.holes.includes(u.x+','+u.y)));}});

test('a chain stops against a braced robot: the push is allowed and moves as far as possible',()=>{let s=sparse();put(s,0,2,4);put(s,1,5,5);put(s,2,0,5);put(s,7,2,3);put(s,6,2,1,{braced:true});put(s,4,4,0);
 const a=legal(s).find(a=>a.type==='push'&&a.id==='0-ram'&&a.x===2&&a.y===3);assert(a);const n=apply(s,a);assert.deepEqual([n.units[7].x,n.units[7].y],[2,2]);assert.deepEqual([n.units[6].x,n.units[6].y],[2,1]);});

test('7×7 T formation: ram, anchor, magnet in a row, jumper behind the anchor on the back edge; mirrored for pink',()=>{const s=initial();const pos=id=>{const u=s.units.find(u=>u.id===id);return [u.x,u.y];};
 assert.deepEqual(pos('0-ram'),[2,5]);assert.deepEqual(pos('0-anchor'),[3,5]);assert.deepEqual(pos('0-magnet'),[4,5]);assert.deepEqual(pos('0-jumper'),[3,6]);
 assert.deepEqual(pos('1-ram'),[4,1]);assert.deepEqual(pos('1-anchor'),[3,1]);assert.deepEqual(pos('1-magnet'),[2,1]);assert.deepEqual(pos('1-jumper'),[3,0]);});

test('jumper steps diagonally but jumps only straight',()=>{let s=sparse();put(s,3,3,3);put(s,0,6,6);put(s,4,0,0);put(s,5,6,0);put(s,6,0,6);
 const j=legal(s).filter(a=>a.id==='0-jumper');assert(j.some(a=>a.type==='move'&&a.x===4&&a.y===4));
 assert.deepEqual(j.filter(a=>a.type==='jump').map(a=>[a.x,a.y]).sort(),[[1,3],[3,1],[3,5],[5,3]]);
 assert(!legal(s).some(a=>a.id!=='0-jumper'&&a.type==='move'&&a.x!==s.units.find(u=>u.id===a.id).x&&a.y!==s.units.find(u=>u.id===a.id).y));});
