import {test} from 'node:test';import assert from 'node:assert/strict';
import{initial,legal,apply,bot,LEVELS,N,CENTER,RING,centerCount}from'../src/engine.js';

test('default board is 5×5 with a 5-cell cross center',()=>{assert.equal(N,5);assert.deepEqual([...CENTER].sort(),['1,2','2,1','2,2','2,3','3,2']);assert.equal(RING.length,16);});

test('T formation on 5×5: blue front row on y=3, jumper on the back edge; pink mirrored',()=>{const s=initial();const pos=id=>{const u=s.units.find(u=>u.id===id);return [u.x,u.y];};
 assert.deepEqual(pos('0-ram'),[1,3]);assert.deepEqual(pos('0-anchor'),[2,3]);assert.deepEqual(pos('0-magnet'),[3,3]);assert.deepEqual(pos('0-jumper'),[2,4]);
 assert.deepEqual(pos('1-ram'),[3,1]);assert.deepEqual(pos('1-anchor'),[2,1]);assert.deepEqual(pos('1-magnet'),[1,1]);assert.deepEqual(pos('1-jumper'),[2,0]);
 assert.equal(centerCount(s,0),1);assert.equal(centerCount(s,1),1);});

test('bots finish a full game with legal actions only',()=>{let s=initial();for(let i=0;i<400&&s.winner===null&&!s.draw;i++){const n=apply(s,bot(s,'normal'));assert(n);s=n;
 const u=s.units.filter(u=>u.alive);assert(u.every(u=>u.x>=0&&u.x<5&&u.y>=0&&u.y<5&&!s.holes.includes(u.x+','+u.y)));}assert(s.winner!==null||s.draw);});
